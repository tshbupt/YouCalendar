$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.Speech

$vf04Root = (Resolve-Path -LiteralPath (Join-Path $PSScriptRoot '../..')).Path
$vf04Target = Join-Path $vf04Root 'output/vf04-tencent-audio'
if (Test-Path -LiteralPath $vf04Target) {
    throw 'Synthetic evaluation directory already exists.'
}
$vf04Cases = Get-Content -LiteralPath (Join-Path $PSScriptRoot 'cases.json') -Raw | ConvertFrom-Json
New-Item -ItemType Directory -Path $vf04Target | Out-Null
$vf04Voice = [System.Speech.Synthesis.SpeechSynthesizer]::new()
$vf04Format = [System.Speech.AudioFormat.SpeechAudioFormatInfo]::new(
    16000, [System.Speech.AudioFormat.AudioBitsPerSample]::Sixteen,
    [System.Speech.AudioFormat.AudioChannel]::Mono
)
try {
    $vf04Voice.SelectVoice('Microsoft Huihui Desktop')
    $vf04Voice.Rate = 0
    foreach ($vf04Case in $vf04Cases) {
        $vf04Path = Join-Path $vf04Target ($vf04Case.id + '.wav')
        $vf04Voice.SetOutputToWaveFile($vf04Path, $vf04Format)
        $vf04Voice.Speak($vf04Case.script)
        $vf04Voice.SetOutputToNull()
    }
} finally {
    $vf04Voice.Dispose()
}
Get-ChildItem -LiteralPath $vf04Target -Filter '*.wav' | Select-Object Name,Length
