"""Evaluate the six fixed synthetic WAVs through Tencent Cloud and the audio route."""

import argparse
import asyncio
from contextlib import closing
import json
import os
from pathlib import Path
import sqlite3
from time import monotonic
import unicodedata

import httpx
from pydantic import TypeAdapter

from server.api import create_app
from server.contracts.feedback import (
    AudioFeedbackContext, FeedbackDraft, FeedbackEvent, TextFeedbackRequest, UnmatchedFeedback,
    check_complete_event_sequence,
)
from server.providers.deepseek_feedback import Completion, build_draft
from server.speech.tencent import ACTION, ENDPOINT, Recognition, TencentSpeechError, TencentSpeechRecognizer
from server.speech.upload import MAX_WAV_BYTES, wav_has_signal


ROOT = Path(__file__).resolve().parents[2]
AUDIO_DIR = ROOT / "output" / "vf04-tencent-audio"
LEDGER_PATH = ROOT / "data" / "vf04-tencent-budget.sqlite"
MAX_CALLS = 6
BUDGET_MICROS = 1_000_000
PER_CALL_MICROS = 3200  # Highest published per-call price, checked 2026-11-11.
EVENT = TypeAdapter(FeedbackEvent)


def reserve_case(path: Path, case_id: str) -> bool:
    path.parent.mkdir(parents=True, exist_ok=True)
    with closing(sqlite3.connect(path)) as db, db:
        db.execute("BEGIN IMMEDIATE")
        db.execute("CREATE TABLE IF NOT EXISTS attempts (case_id TEXT PRIMARY KEY, bound_micros INTEGER NOT NULL)")
        if db.execute("SELECT 1 FROM attempts WHERE case_id=?", (case_id,)).fetchone():
            return False
        count, reserved = db.execute("SELECT COUNT(*), COALESCE(SUM(bound_micros), 0) FROM attempts").fetchone()
        if count >= MAX_CALLS or reserved + PER_CALL_MICROS > BUDGET_MICROS:
            return False
        db.execute("INSERT INTO attempts VALUES (?, ?)", (case_id, PER_CALL_MICROS))
        return True


def load_cases():
    cases = json.loads(Path(__file__).with_name("cases.json").read_text(encoding="utf-8"))
    if len(cases) != MAX_CALLS or len({case["id"] for case in cases}) != MAX_CALLS:
        raise ValueError("expected six distinct fixed cases")
    return cases


def load_metadata(case: dict) -> AudioFeedbackContext:
    base = json.loads((ROOT / "tests/fixtures/feedback/text-request.json").read_text(encoding="utf-8"))["context"]
    attempt_id = f"vf04_{case['id']}"
    base["ref"].update(attempt_id=attempt_id, submission_id=attempt_id, study_date="2026-11-11")
    if case["task_id"] == "comms":
        base["tasks"].append({
            "task_id": "comms", "task_revision": 1, "title": "通信原理", "subject": "专业课",
            "planned_count": 10, "unit": "题",
            "progress": {"status": "pending", "completed_count": None, "reason": None},
        })
    return AudioFeedbackContext.model_validate({"context": base})


def normalized(text: str) -> str:
    text = unicodedata.normalize("NFKC", text)
    text = "".join(
        char for index, char in enumerate(text)
        if not char.isspace() and (
            unicodedata.category(char)[0] != "P"
            or (0 < index < len(text) - 1 and text[index - 1].isdecimal() and text[index + 1].isdecimal())
        )
    )
    for spoken, digits in (("十四", "14"), ("十二", "12"), ("四", "4"), ("三", "3")):
        text = text.replace(f"{spoken}题", f"{digits}题")
    return text


class CaseOrganizer:
    """A fixed local extraction for a matched synthetic transcript."""

    def __init__(self, case: dict):
        self.case = case

    async def organize(self, request: TextFeedbackRequest) -> str:
        case = self.case
        if normalized(request.text) != normalized(case["text"]):
            return FeedbackDraft(
                ref=request.context.ref, draft_revision=1, state="needs_user_input", changes=[],
                unmatched=[UnmatchedFeedback(evidence=request.text[:1000], candidate_task_ids=[])],
                date_needs_confirmation=False, summary=None,
            ).model_dump_json()
        alias = next(f"t{i}" for i, task in enumerate(request.context.tasks, 1) if task.task_id == case["task_id"])
        raw = {"changes": [{
            "task_id": alias, "evidence": request.text, "status": case["status"], "reason": case["reason"],
            "quantity": {"meaning": case["meaning"], "value": case["value"], "unit": "题"}
            if case["meaning"] is not None else None,
        }], "unmatched": [], "date_needs_confirmation": False, "summary": None}
        return build_draft(request, Completion(json.dumps(raw, ensure_ascii=False), None)).model_dump_json()


class MeasuredRecognizer:
    def __init__(self, upstream: TencentSpeechRecognizer):
        self.upstream = upstream
        self.result: Recognition | None = None
        self.error: str | None = None
        self.elapsed_ms: int | None = None

    async def recognize(self, audio: bytes) -> str:
        start = monotonic()
        try:
            self.result = await self.upstream.transcribe(audio)
            return self.result.text
        except TencentSpeechError as exc:
            self.error = exc.code
            raise
        finally:
            self.elapsed_ms = round((monotonic() - start) * 1000)


def check_draft(case: dict, draft: dict | None) -> bool:
    if draft is None or draft["state"] != case["state"] or len(draft["changes"]) != 1:
        return False
    change, = draft["changes"]
    candidate = change["candidate"]
    return candidate is not None and (
        change["task_id"], candidate["status"], candidate["completed_count"], candidate["reason"],
        change["remaining_count"], change["issues"],
    ) == (case["task_id"], case["status"], case["completed"], case["reason"], case["remaining"], case["issues"])


async def evaluate(case: dict, audio: bytes, recognizer: MeasuredRecognizer) -> dict:
    context = load_metadata(case)
    app = create_app(feedback_token="synthetic-audio-local", speech_recognizer=recognizer,
                     feedback_organizer=CaseOrganizer(case))
    async with httpx.AsyncClient(transport=httpx.ASGITransport(app=app), base_url="http://test") as client:
        response = await client.post("/v1/feedback/audio", headers={"Authorization": "Bearer synthetic-audio-local"},
                                     files={"metadata": (None, context.model_dump_json(), "application/json"),
                                            "audio": ("synthetic.wav", audio, "audio/wav")})
    if response.status_code != 200:
        return {"http_status": response.status_code, "asr_pass": False, "draft_pass": False, "terminal": "rejected"}
    events = [EVENT.validate_json(line[6:]) for line in response.text.splitlines() if line.startswith("data: ")]
    check_complete_event_sequence(context, events)
    terminal = events[-1].model_dump(mode="json")
    transcript = recognizer.result.text if recognizer.result else None
    return {
        "asr_pass": transcript is not None and normalized(transcript) == normalized(case["text"]),
        "draft_pass": check_draft(case, terminal.get("draft")),
        "transcript": transcript, "asr_ms": recognizer.elapsed_ms, "provider_error": recognizer.error,
        "request_id": recognizer.result.request_id if recognizer.result else None,
        "terminal": terminal.get("code", terminal["type"]),
        "draft_state": terminal.get("draft", {}).get("state"),
    }


async def live(clips, secret_id: str, secret_key: str) -> bool:
    passed = True
    async with httpx.AsyncClient(timeout=10, trust_env=False, limits=httpx.Limits(max_connections=1)) as client:
        upstream = TencentSpeechRecognizer(client, secret_id, secret_key)
        for case, audio in clips:
            if not reserve_case(LEDGER_PATH, case["id"]):
                print(json.dumps({"case": case["id"], "status": "already_attempted_or_limit"}))
                return False
            result = await evaluate(case, audio, MeasuredRecognizer(upstream))
            print(json.dumps({"case": case["id"], "cost_bound_micros": PER_CALL_MICROS, **result}, ensure_ascii=False))
            passed = passed and result["asr_pass"] and result["draft_pass"]
            if result["terminal"] not in ("result", "unusable_audio"):
                return False
    return passed


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--live", action="store_true", help="Send the six locally synthesized WAVs")
    args = parser.parse_args()
    clips = []
    for case in load_cases():
        load_metadata(case)
        path = AUDIO_DIR / f"{case['id']}.wav"
        if path.stat().st_size > MAX_WAV_BYTES:
            raise ValueError("synthetic WAV exceeds audio limit")
        audio = path.read_bytes()
        if not wav_has_signal(audio):
            raise ValueError("synthetic WAV is silent")
        clips.append((case, audio))
    print(json.dumps({"cases": len(clips), "endpoint": ENDPOINT, "action": ACTION, "live": args.live,
                      "budget_micros": BUDGET_MICROS, "max_trial_cost_micros": MAX_CALLS * PER_CALL_MICROS}))
    if not args.live:
        return 0
    secret_id = os.environ.get("TENCENTCLOUD_SECRET_ID", "").strip()
    secret_key = os.environ.get("TENCENTCLOUD_SECRET_KEY", "").strip()
    if not secret_id or not secret_key:
        print("Missing Tencent Cloud environment credentials.")
        return 2
    return 0 if asyncio.run(live(clips, secret_id, secret_key)) else 1


if __name__ == "__main__":
    raise SystemExit(main())
