"""Run the fixed synthetic VF-03 evaluation with a durable 3 CNY ceiling."""

import argparse
import asyncio
from contextlib import closing
from datetime import datetime, timedelta, timezone
import json
import os
from pathlib import Path
import sqlite3
from time import monotonic

import httpx

from server.contracts.feedback import FeedbackDraft, TextFeedbackRequest
from server.providers.deepseek_feedback import (
    CONTEXT_CAP, DOCUMENTED_MODEL_VERSION, MAX_OUTPUT_TOKENS, MODEL, DeepSeekFeedbackOrganizer,
    Usage, build_draft,
)
from server.providers.feedback import FeedbackProviderError


ROOT = Path(__file__).resolve().parents[2]
LEDGER_PATH = ROOT / "data" / "feedback-vf03-budget.sqlite"
BALANCE_URL = "https://api.deepseek.com/user/balance"
# Micro-yuan. Use peak, uncached prices for the published Flash rate snapshot.
INPUT_RATE = 2
OUTPUT_RATE = 8
BUDGET = 3_000_000
RESERVE = CONTEXT_CAP * INPUT_RATE + MAX_OUTPUT_TOKENS * OUTPUT_RATE
PRICE_CHECKED_ON = "2026-11-10"
EVAL_REVISION = 2


class BudgetLedger:
    def __init__(self, path: Path):
        self.path = path
        path.parent.mkdir(parents=True, exist_ok=True)
        with closing(sqlite3.connect(path)) as db, db:
            db.execute("""CREATE TABLE IF NOT EXISTS attempts (
                case_id TEXT PRIMARY KEY, bound_micros INTEGER NOT NULL,
                settled INTEGER NOT NULL DEFAULT 0
            )""")

    def reserve(self, case_id: str) -> str:
        with closing(sqlite3.connect(self.path)) as db, db:
            db.execute("BEGIN IMMEDIATE")
            if db.execute("SELECT 1 FROM attempts WHERE case_id=?", (case_id,)).fetchone():
                return "already_attempted"
            total = db.execute("SELECT COALESCE(SUM(bound_micros), 0) FROM attempts").fetchone()[0]
            if total + RESERVE > BUDGET:
                return "budget_exhausted"
            db.execute("INSERT INTO attempts(case_id, bound_micros) VALUES (?, ?)", (case_id, RESERVE))
            return "reserved"

    def settle(self, case_id: str, usage: Usage) -> int:
        if (
            not 0 < usage.input_tokens <= CONTEXT_CAP
            or not 0 <= usage.output_tokens <= MAX_OUTPUT_TOKENS
            or usage.input_tokens + usage.output_tokens > CONTEXT_CAP
        ):
            raise ValueError("usage is outside the reserved bounds")
        bound = INPUT_RATE * usage.input_tokens + OUTPUT_RATE * usage.output_tokens
        with closing(sqlite3.connect(self.path)) as db, db:
            result = db.execute(
                "UPDATE attempts SET bound_micros=?, settled=1 WHERE case_id=? AND settled=0",
                (bound, case_id),
            )
            if result.rowcount != 1:
                raise ValueError("attempt does not have an unsettled reservation")
        return bound


def load_cases():
    cases = json.loads(Path(__file__).with_name("cases.json").read_text(encoding="utf-8"))
    if len(cases) != 12 or len({case["id"] for case in cases}) != len(cases):
        raise ValueError("VF-03 needs twelve distinct evaluation cases")
    base = json.loads((ROOT / "tests/fixtures/feedback/text-request.json").read_text(encoding="utf-8"))
    result = []
    for case in cases:
        payload = {
            "text": case["text"], "context": {**base["context"], "ref": {
                **base["context"]["ref"],
                "submission_id": f"vf03_{case['id']}", "attempt_id": f"vf03_{case['id']}_1",
            }},
        }
        result.append((case["id"], TextFeedbackRequest.model_validate(payload), case["expected"]))
    return result


def score_draft(draft: FeedbackDraft, expected: dict) -> dict:
    changes = [{
        "task_id": change.task_id,
        "status": change.candidate.status if change.candidate else None,
        "count": change.candidate.completed_count if change.candidate else None,
        "remaining": change.remaining_count,
        "issues": sorted(change.issues),
        "has_reason": bool(change.candidate and change.candidate.reason),
        "reported_meaning": change.reported_quantity.meaning if change.reported_quantity else None,
        "reported_value": change.reported_quantity.value if change.reported_quantity else None,
    } for change in draft.changes]
    actual = {
        "state": draft.state,
        "changes": changes,
        "unmatched": sorted(sorted(item.candidate_task_ids) for item in draft.unmatched),
        "date_pending": draft.date_needs_confirmation,
    }
    matches = all(actual[field] == expected[field] for field in ("state", "unmatched", "date_pending"))
    matches = matches and len(changes) == len(expected["changes"]) and all(
        all(actual_change[key] == value for key, value in desired.items())
        for actual_change, desired in zip(changes, expected["changes"])
    )
    return {"verdict": "pass" if matches else "mismatch", "reviewable_mismatch": (
        not matches and draft.state == "ready_for_confirmation"
    ), "observed": actual}


async def run_cases(cases, organizer: DeepSeekFeedbackOrganizer, ledger: BudgetLedger) -> bool:
    passed = True
    for case_id, request, expected in cases:
        attempt_key = f"v{EVAL_REVISION}:{case_id}"
        status = ledger.reserve(attempt_key)
        if status != "reserved":
            print(json.dumps({"case": case_id, "status": status}))
            passed = False
            if status == "budget_exhausted":
                break
            continue
        started = monotonic()
        try:
            async with asyncio.timeout(15):
                completion = await organizer.complete(request)
        except (FeedbackProviderError, TimeoutError):
            print(json.dumps({"case": case_id, "status": "usage_unknown", "reserved_micros": RESERVE}))
            return False
        if completion.usage is None:
            print(json.dumps({"case": case_id, "status": "usage_unknown", "reserved_micros": RESERVE}))
            return False
        bound = ledger.settle(attempt_key, completion.usage)
        try:
            result = score_draft(build_draft(request, completion), expected)
        except ValueError:
            result = {"verdict": "invalid_output"}
        print(json.dumps({
            "case": case_id, "elapsed_ms": round((monotonic() - started) * 1000),
            "input_tokens": completion.usage.input_tokens, "output_tokens": completion.usage.output_tokens,
            "cost_bound_micros": bound, **result,
        }, ensure_ascii=False))
        passed = passed and result["verdict"] == "pass"
    return passed


async def live(cases, api_key: str) -> bool:
    async with httpx.AsyncClient(
        timeout=10, trust_env=False, limits=httpx.Limits(max_connections=1),
    ) as client:
        try:
            response = await client.get(BALANCE_URL, headers={"Authorization": f"Bearer {api_key}"})
            response.raise_for_status()
            balance = response.json()
            currencies = {item["currency"] for item in balance["balance_infos"]}
            if balance["is_available"] is not True or currencies != {"CNY"}:
                raise ValueError("unavailable CNY balance")
        except (httpx.HTTPError, ValueError, KeyError, TypeError):
            print("Live evaluation blocked: active CNY account could not be verified.")
            return False
        return await run_cases(cases, DeepSeekFeedbackOrganizer(client, api_key), BudgetLedger(LEDGER_PATH))


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--live", action="store_true", help="Call DeepSeek with the fixed synthetic cases")
    args = parser.parse_args()
    cases = load_cases()
    print(json.dumps({
        "cases": len(cases), "model": MODEL, "documented_version": DOCUMENTED_MODEL_VERSION,
        "budget_micros": BUDGET, "max_reservation_per_request_micros": RESERVE, "live": args.live,
        "evaluation_revision": EVAL_REVISION,
    }))
    if not args.live:
        return 0
    api_key = os.environ.get("DEEPSEEK_API_KEY", "").strip()
    if not api_key:
        print("Live evaluation blocked: DEEPSEEK_API_KEY is not configured.")
        return 2
    if datetime.now(timezone(timedelta(hours=8))).date().isoformat() != PRICE_CHECKED_ON:
        print("Live evaluation blocked: verify current official pricing before updating the rate snapshot.")
        return 2
    return 0 if asyncio.run(live(cases, api_key)) else 1


if __name__ == "__main__":
    raise SystemExit(main())
