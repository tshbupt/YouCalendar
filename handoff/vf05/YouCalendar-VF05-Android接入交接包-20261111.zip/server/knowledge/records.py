"""Portable evidence contract; no student records or model calls belong here."""

from __future__ import annotations

from dataclasses import asdict, dataclass, field
import hashlib
import json
from typing import Any


SCHEMA_VERSION = 1


def canonical_json(value: Any) -> str:
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"))


@dataclass(frozen=True)
class Evidence:
    evidence_id: str
    source_id: str
    title: str
    text: str
    source_url: str
    locator: dict[str, Any]
    published_date: str | None = None
    source_hash: str = ""
    source_type: str = "forum_discussion"
    review_status: str = "draft"
    college: str | None = None
    subject: str | None = None
    stage: str | None = None
    exam_year: int | None = None
    year_scope: str = "unknown"
    review: dict[str, Any] = field(default_factory=dict)

    @property
    def content_hash(self) -> str:
        """Only source content controls whether an earlier review is reusable."""
        value = self.to_dict()
        for key in ("review_status", "review", "college", "subject", "stage", "exam_year", "year_scope"):
            value.pop(key)
        return hashlib.sha256(canonical_json(value).encode("utf-8")).hexdigest()

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)

    @classmethod
    def from_dict(cls, value: dict[str, Any]) -> Evidence:
        allowed = set(cls.__dataclass_fields__)
        if set(value) - allowed:
            raise ValueError("unknown evidence fields")
        return cls(**value)


@dataclass(frozen=True)
class SearchQuery:
    text: str
    college: str | None = None
    subject: str | None = None
    stage: str | None = None
    exam_year: int | None = None
    limit: int = 5

    def validate(self) -> None:
        if not self.text.strip() or len(self.text) > 500:
            raise ValueError("query must contain 1 to 500 characters")
        if not 1 <= self.limit <= 20:
            raise ValueError("limit must be between 1 and 20")
        if self.exam_year is not None and not 2000 <= self.exam_year <= 2100:
            raise ValueError("exam_year is outside supported bounds")
        for value in (self.college, self.subject, self.stage):
            if value is not None and (not value.strip() or len(value) > 100):
                raise ValueError("invalid scope filter")
