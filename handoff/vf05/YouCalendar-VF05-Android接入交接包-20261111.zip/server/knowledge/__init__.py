"""Evidence authoring is separate from immutable runtime knowledge."""
