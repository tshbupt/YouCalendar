"""Read the accepted GEO forum archive without changing or executing its files."""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import date
import hashlib
import json
from pathlib import Path, PureWindowsPath
import re
from typing import Any
from urllib.parse import parse_qs, unquote, urlsplit

from .records import Evidence


ARCHIVED_STATUS = "已归档（PDF与完整截图验收通过）"
_BOARD = re.compile(r"[A-Za-z0-9_]+\Z")
_ARTICLE = re.compile(r"(?:^|/)article/([A-Za-z0-9_]+)/(\d+)(?:[/?#]|$)")


@dataclass
class ImportBatch:
    sources: dict[str, list[Evidence]] = field(default_factory=dict)
    active_source_ids: set[str] = field(default_factory=set)
    errors: list[dict[str, str]] = field(default_factory=list)
    manifest_valid: bool = True

    @property
    def counts(self) -> dict[str, int]:
        return {
            "active_sources": len(self.active_source_ids),
            "imported_sources": len(self.sources),
            "evidence": sum(map(len, self.sources.values())),
            "errors": len(self.errors),
        }


class _ArchiveError(ValueError):
    def __init__(self, code: str, message: str):
        self.code = code
        super().__init__(message)


def _fail(code: str, message: str) -> None:
    raise _ArchiveError(code, message)


def _read_json(path: Path) -> tuple[Any, bytes]:
    try:
        raw = path.read_bytes()
        return json.loads(raw.decode("utf-8-sig")), raw
    except FileNotFoundError:
        _fail("MISSING_FILE", "Required archive file is missing.")
    except (OSError, UnicodeError, json.JSONDecodeError):
        _fail("INVALID_JSON", "Archive JSON cannot be read or decoded.")


def _inside(path: Path, parent: Path) -> Path:
    path = path.resolve()
    if not path.is_relative_to(parent.resolve()):
        _fail("PATH_OUTSIDE_ROOT", "Archive reference leaves its permitted directory.")
    return path


def _archive_reference(root: Path, directory: str, reference: str, suffixes: set[str]) -> Path:
    """Relocate old-machine absolute paths without ever opening their targets."""
    permitted = _inside(root / directory, root)
    windows = PureWindowsPath(reference)
    local = Path(reference)
    absolute = local.is_absolute() or windows.is_absolute() or bool(windows.root)
    parts = windows.parts if "\\" in reference or windows.drive else local.parts
    if ".." in parts:
        _fail("PATH_OUTSIDE_ROOT", "Relative traversal is not an archive reference.")
    if absolute:
        # The copied archive is authoritative; an old drive/path is not read.
        name = windows.name if "\\" in reference or windows.drive else local.name
        candidate = root / directory / name
    else:
        if "\\" in reference:
            local = Path(*windows.parts)
        candidate = root / local if parts and parts[0] == directory else root / directory / local
    candidate = _inside(candidate, permitted)
    if candidate.suffix.lower() not in suffixes:
        _fail("INVALID_FILE_TYPE", "Archive reference has an unsupported extension.")
    return candidate


def _identity_from_url(value: Any) -> tuple[str, str] | None:
    if not isinstance(value, str):
        return None
    try:
        parsed = urlsplit(value)
    except ValueError:
        _fail("INVALID_SOURCE_URL", "Source URL is malformed.")
    if parsed.scheme not in {"http", "https"} or parsed.hostname != "bbs.byr.cn":
        return None
    for part in (parsed.path, parsed.fragment.lstrip("!")):
        found = _ARTICLE.search(unquote(part))
        if found:
            return found.group(1), found.group(2)
    return None


def _identity(value: dict[str, Any], *, require: bool = True) -> tuple[str, str] | None:
    url_identity = _identity_from_url(value.get("url"))
    if value.get("url") is not None and url_identity is None:
        _fail("INVALID_SOURCE_URL", "Source URL must identify a supported forum article.")
    board, article_id = value.get("board"), value.get("id")
    if board is not None and (not isinstance(board, str) or not _BOARD.fullmatch(board)):
        _fail("INVALID_SOURCE_ID", "Source board is invalid.")
    if article_id is not None and (isinstance(article_id, bool) or not str(article_id).isdigit()):
        _fail("INVALID_SOURCE_ID", "Source article identifier is invalid.")
    article_id = str(article_id) if article_id is not None else None
    if url_identity:
        if (board is not None and board != url_identity[0]) or (
            article_id is not None and article_id != url_identity[1]
        ):
            _fail("SOURCE_ID_CONFLICT", "Source identifiers disagree with its URL.")
        board, article_id = url_identity
    if board is not None and article_id is not None:
        return board, article_id
    if require:
        _fail("INVALID_SOURCE_ID", "Source requires a board and an article identifier.")
    return None


def _positive_page(value: Any) -> int:
    if isinstance(value, bool) or not str(value).isdigit() or not 1 <= int(value) <= 10_000:
        _fail("INVALID_PAGE", "Forum page numbers must be positive integers within archive bounds.")
    return int(value)


def _url_page(value: Any) -> int | None:
    if not isinstance(value, str):
        return None
    try:
        parsed = urlsplit(value)
    except ValueError:
        _fail("INVALID_SOURCE_URL", "Page URL is malformed.")
    values = parse_qs(parsed.query).get("p")
    if not values and "?" in parsed.fragment:
        values = parse_qs(parsed.fragment.split("?", 1)[1]).get("p")
    if values:
        if len(values) != 1:
            _fail("INVALID_PAGE", "Forum URL has ambiguous page numbers.")
        return _positive_page(values[0])
    return None


def _page_number(page: dict[str, Any], *, first: bool = False) -> int:
    explicit = _positive_page(page["page_no"]) if "page_no" in page else None
    from_url = _url_page(page.get("url"))
    if explicit and from_url and explicit != from_url:
        _fail("PAGE_CONFLICT", "Forum page number disagrees with its URL.")
    if explicit or from_url:
        return explicit or from_url  # type: ignore[return-value]
    if first:
        return 1
    _fail("MISSING_PAGE_NUMBER", "Additional extracted page lacks a page number.")


def _metadata_path(root: Path, item: dict[str, Any]) -> Path | None:
    reference = item.get("archive_manifest")
    if reference is None:
        return None
    if not isinstance(reference, str) or not reference.strip():
        _fail("INVALID_METADATA_REFERENCE", "Archive manifest reference is invalid.")
    return _archive_reference(root, "metadata", reference, {".json"})


def _paired_assets(root: Path, metadata: dict[str, Any], body_pages: set[int], article_id: str) -> dict[int, str]:
    stem = metadata.get("file_stem")
    if not isinstance(stem, str) or not stem or Path(stem).name != stem or "/" in stem or "\\" in stem:
        _fail("MISSING_FILE_STEM", "Metadata requires a safe archive file stem.")
    pdf_reference = metadata.get("pdf_file") or metadata.get("pdf_path") or f"{stem}.pdf"
    if not isinstance(pdf_reference, str):
        _fail("INVALID_PDF_REFERENCE", "Source PDF reference must be text.")
    pdf = _archive_reference(root, "pdf", pdf_reference, {".pdf"})
    if pdf.stem != stem:
        _fail("ASSET_ID_CONFLICT", "Source PDF does not match the source file stem.")
    if not pdf.is_file():
        _fail("MISSING_PDF", "Archived source PDF is missing.")
    captures = metadata.get("pages")
    if not isinstance(captures, list) or not captures:
        _fail("MISSING_CAPTURE", "Archived source requires original page images.")
    images: dict[int, str] = {}
    for capture in captures:
        if not isinstance(capture, dict):
            _fail("INVALID_CAPTURE", "Capture page must be an object.")
        number = _positive_page(capture.get("page_no"))
        if number in images:
            _fail("DUPLICATE_PAGE", "Capture page numbers are duplicated.")
        reference = capture.get("full_image")
        if not isinstance(reference, str) or not reference:
            _fail("MISSING_IMAGE", "Capture page lacks its original image reference.")
        candidate = _archive_reference(root, "images", reference, {".jpg", ".jpeg", ".png", ".webp", ".tif", ".tiff", ".bmp"})
        source_matches = candidate.stem.startswith(f"{stem}_") or re.search(rf"(?:^|_){re.escape(article_id)}(?:_|$)", candidate.stem)
        page_matches = re.search(rf"_p0*{number}(?:_|$)", candidate.stem)
        if not source_matches or not page_matches:
            _fail("ASSET_ID_CONFLICT", "Original page image does not match its source and forum page.")
        if not candidate.is_file():
            _fail("MISSING_IMAGE", "Archived original page image is missing.")
        if capture.get("capture_complete") is False:
            _fail("INCOMPLETE_CAPTURE", "A source page capture is marked incomplete.")
        images[number] = candidate.relative_to(root).as_posix()
    if set(images) != body_pages:
        _fail("PAGE_COVERAGE_MISMATCH", "Extracted text and original image pages do not match.")
    return images


def _source_evidence(root: Path, path: Path, item: dict[str, Any], identity: tuple[str, str]) -> list[Evidence]:
    metadata, raw = _read_json(path)
    if not isinstance(metadata, dict):
        _fail("INVALID_METADATA", "Source metadata must be an object.")
    metadata_identity = _identity(metadata, require=False)
    # Some older metadata has id + URL but no board. Never join on id alone.
    if metadata_identity != identity:
        _fail("SOURCE_ID_CONFLICT", "Manifest and metadata source identifiers disagree.")
    extracted = metadata.get("extracted")
    if not isinstance(extracted, dict):
        _fail("MISSING_BODY", "Source has no structured extracted posts.")
    pages = [extracted]
    additional = metadata.get("page_extracted", [])
    if not isinstance(additional, list):
        _fail("INVALID_PAGES", "Additional extracted pages must be an array.")
    pages.extend(additional)
    posts_by_page: dict[int, list[dict[str, Any]]] = {}
    for index, page in enumerate(pages):
        if not isinstance(page, dict):
            _fail("INVALID_PAGE", "Extracted page must be an object.")
        # Older exports repeat the exact first-page extraction in this array.
        # Its canonical URL and identical posts establish that it is the same
        # page, rather than inferring page numbers from the array position.
        if (
            index > 0 and "page_no" not in page and _url_page(page.get("url")) is None
            and page.get("url") == extracted.get("url")
            and page.get("url") is not None
            and page.get("posts") == extracted.get("posts")
            and _page_number(extracted, first=True) == 1
        ):
            continue
        number = _page_number(page, first=index == 0)
        page_identity = _identity(page, require=False)
        if page_identity is not None and page_identity != identity:
            _fail("SOURCE_ID_CONFLICT", "Extracted page belongs to a different source.")
        if number in posts_by_page:
            _fail("DUPLICATE_PAGE", "Extracted forum page numbers are duplicated.")
        posts = page.get("posts")
        if not isinstance(posts, list) or not posts:
            _fail("MISSING_BODY", "A forum page has no extracted posts; pagination links are not body text.")
        posts_by_page[number] = posts
    expected = metadata.get("expected_forum_pages")
    count = _positive_page(expected) if expected is not None else max(posts_by_page)
    if set(posts_by_page) != set(range(1, count + 1)):
        _fail("MISSING_BODY_PAGE", "Extracted forum text does not cover every expected page.")
    images = _paired_assets(root, metadata, set(posts_by_page), identity[1])
    published = metadata.get("published_date") or item.get("published")
    if published is not None:
        try:
            published = date.fromisoformat(published).isoformat()
        except (TypeError, ValueError):
            _fail("INVALID_PUBLICATION_DATE", "Publication date must be an ISO calendar date.")
    source_id = f"forum:{identity[0]}:{identity[1]}"
    source_url = item.get("url") or metadata.get("url")
    title = metadata.get("title") or item.get("title") or source_id
    if not isinstance(title, str) or not isinstance(source_url, str):
        _fail("INVALID_METADATA", "Source title and URL must be text.")
    result: list[Evidence] = []
    source_hash = hashlib.sha256(raw).hexdigest()
    for page, posts in sorted(posts_by_page.items()):
        for post_index, post in enumerate(posts, start=1):
            if not isinstance(post, dict) or not isinstance(post.get("text"), str):
                _fail("INVALID_POST", "Extracted post must contain text.")
            text = re.sub(r"\[FROM:\s*[0-9A-Fa-f:.*]+\s*\]\s*\Z", "", post["text"]).strip()
            if not text:
                _fail("EMPTY_POST", "Extracted post text is empty.")
            result.append(Evidence(
                evidence_id=f"{source_id}:p{page}:post{post_index}",
                source_id=source_id,
                title=title,
                text=text,
                source_url=source_url,
                locator={
                    "level": "forum_page",
                    "forum_page": page,
                    "post_index": post_index,
                    "metadata_file": path.relative_to(root).as_posix(),
                    "image_file": images[page],
                },
                published_date=published,
                source_hash=source_hash,
            ))
    return result


def load_geo_archive(archive_root: Path) -> ImportBatch:
    """Import accepted sources atomically; retain active IDs even on source errors.

    Errors contain identifiers and diagnostics, never a copied source body. Source
    scripts, ZIP snapshots, pending, excluded, and QA directories are not inputs.
    """
    root = archive_root.resolve()
    batch = ImportBatch()
    try:
        manifest_path = _inside(root / "采集任务清单.json", root)
        manifest, _ = _read_json(manifest_path)
        if not isinstance(manifest, list):
            _fail("INVALID_MANIFEST", "Collection manifest must be an array.")
    except _ArchiveError as exc:
        batch.manifest_valid = False
        batch.errors.append({"source_id": "manifest", "code": exc.code, "message": str(exc)})
        return batch

    selected: dict[str, tuple[tuple[str, str], list[dict[str, Any]]]] = {}
    for index, item in enumerate(manifest):
        if not isinstance(item, dict):
            batch.manifest_valid = False
            batch.errors.append({"source_id": f"manifest:{index}", "code": "INVALID_MANIFEST_ITEM", "message": "Collection item must be an object."})
            continue
        if item.get("status") != ARCHIVED_STATUS:
            continue
        try:
            identity = _identity(item)
            assert identity is not None
            source_id = f"forum:{identity[0]}:{identity[1]}"
            batch.active_source_ids.add(source_id)
            if source_id not in selected:
                selected[source_id] = identity, []
            selected[source_id][1].append(item)
        except _ArchiveError as exc:
            error_id = f"manifest:{index}"
            try:
                candidate = _identity({"board": item.get("board"), "id": item.get("id")}, require=False)
                if candidate is not None:
                    error_id = f"forum:{candidate[0]}:{candidate[1]}"
                    batch.active_source_ids.add(error_id)
            except _ArchiveError:
                pass
            batch.errors.append({"source_id": error_id, "code": exc.code, "message": str(exc)})

    fallback: dict[tuple[str, str], list[Path]] | None = None
    for source_id, (identity, items) in selected.items():
        try:
            candidates: set[Path] = set()
            for item in items:
                explicit = _metadata_path(root, item)
                if explicit is not None:
                    candidates.add(explicit)
                    continue
                if fallback is None:
                    fallback = {}
                    metadata_dir = _inside(root / "metadata", root)
                    for path in sorted(metadata_dir.glob("*.json")):
                        try:
                            path = _inside(path, metadata_dir)
                            value, _ = _read_json(path)
                            if not isinstance(value, dict):
                                _fail("INVALID_METADATA", "Source metadata must be an object.")
                            key = _identity(value, require=False)
                            if key is not None:
                                fallback.setdefault(key, []).append(path)
                        except _ArchiveError as exc:
                            batch.errors.append({"source_id": f"metadata:{path.name}", "code": exc.code, "message": str(exc)})
                candidates.update(fallback.get(identity, []))
            if not candidates:
                _fail("MISSING_METADATA", "No metadata matches the archived source identity.")
            if len(candidates) != 1:
                _fail("AMBIGUOUS_METADATA", "Multiple metadata files claim the same source identity.")
            path = next(iter(candidates))
            batch.sources[source_id] = _source_evidence(root, path, items[0], identity)
        except _ArchiveError as exc:
            batch.errors.append({"source_id": source_id, "code": exc.code, "message": str(exc)})
    return batch
