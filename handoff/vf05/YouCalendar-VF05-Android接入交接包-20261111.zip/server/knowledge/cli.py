"""Offline operator commands. Nothing here calls a model or deploys a service."""

from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
import sys

from .records import Evidence, SearchQuery
from .store import AuthoringStore, KnowledgeRuntime


def _print(value: object) -> None:
    print(json.dumps(value, ensure_ascii=False, indent=2))


def _demo(workspace: Path, version: str) -> dict:
    store = AuthoringStore(workspace / "authoring.sqlite")
    text = "【合成演示，非真实备考建议】复习任务完成后记录具体完成数量，未完成部分保留到下一次规划。"
    evidence = Evidence(
        evidence_id="demo:progress:p1:post1", source_id="demo:progress",
        title="合成演示：复习进度记录", text=text,
        source_url="https://example.invalid/synthetic-demo",
        source_hash=hashlib.sha256(text.encode("utf-8")).hexdigest(),
        locator={"level": "article", "synthetic": True}, source_type="synthetic_demo"
    )
    store.upsert_source(evidence.source_id, [evidence])
    store.approve(evidence.evidence_id, college="演示院系", subject="演示科目", stage="演示阶段",
                  exam_year=None, any_year=True, reviewer="synthetic-demo-builder",
                  note="只批准合成演示数据，不构成真实资料审核")
    release = store.publish(workspace / "releases", version)
    result = KnowledgeRuntime(release).search(SearchQuery("复习进度", subject="演示科目"))
    return {"synthetic_demo_only": True, "release_dir": str(release),
            "stats": store.stats(), "search": result}


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)
    demo = sub.add_parser("demo", help="publish and query explicitly synthetic demo knowledge")
    demo.add_argument("--workspace", type=Path, default=Path("data/demo"))
    demo.add_argument("--version", default="demo-v1")
    ingest = sub.add_parser("import-geo", help="import approved archive captures as UNREVIEWED authoring evidence")
    ingest.add_argument("--source-root", type=Path, required=True)
    ingest.add_argument("--database", type=Path, default=Path("data/authoring.sqlite"))
    for command in ("stats", "list", "approve", "publish"):
        cmd = sub.add_parser(command)
        cmd.add_argument("--database", type=Path, default=Path("data/authoring.sqlite"))
        if command == "list":
            cmd.add_argument("--status", choices=["draft", "approved", "disabled"], default="draft")
            cmd.add_argument("--limit", type=int, default=10)
        elif command == "approve":
            cmd.add_argument("--evidence-id", required=True)
            cmd.add_argument("--college", required=True)
            cmd.add_argument("--subject", required=True)
            cmd.add_argument("--stage", required=True)
            years = cmd.add_mutually_exclusive_group(required=True)
            years.add_argument("--year", type=int)
            years.add_argument("--any-year", action="store_true")
            cmd.add_argument("--reviewer", required=True)
            cmd.add_argument("--note", required=True)
        elif command == "publish":
            cmd.add_argument("--releases-dir", type=Path, default=Path("data/releases"))
            cmd.add_argument("--version", required=True)
    search = sub.add_parser("search", help="query a validated immutable release")
    search.add_argument("--release", type=Path, required=True)
    search.add_argument("--query", required=True)
    search.add_argument("--college")
    search.add_argument("--subject")
    search.add_argument("--stage")
    search.add_argument("--year", type=int)
    search.add_argument("--limit", type=int, default=5)
    args = parser.parse_args(argv)
    try:
        if args.command == "demo":
            _print(_demo(args.workspace, args.version))
        elif args.command == "search":
            _print(KnowledgeRuntime(args.release).search(SearchQuery(
                args.query, args.college, args.subject, args.stage, args.year, args.limit)))
        elif args.command == "import-geo":
            from .importers import load_geo_archive
            batch = load_geo_archive(args.source_root)
            if not batch.manifest_valid:
                _print({"imported_source_count": 0, "errors": batch.errors,
                        "existing_database_unchanged": True,
                        "notice": "采集清单无效，已停止；未创建或修改作者数据库。"})
                return 2
            if not batch.active_source_ids:
                _print({"imported_source_count": 0, "errors": batch.errors,
                        "existing_database_unchanged": True,
                        "notice": "清单没有已归档来源，已停止；不自动撤回现有内容。"})
                return 2
            store = AuthoringStore(args.database)
            changed = unchanged = removed = 0
            for source_id, records in batch.sources.items():
                result = store.upsert_source(source_id, records)
                changed += result["changed"]
                unchanged += result["unchanged"]
                removed += result["removed"]
            for problem in batch.errors:
                if problem.get("source_id"):
                    store.quarantine_source(problem["source_id"])
            withdrawn = store.sync_active_sources(batch.active_source_ids)
            _print({"imported_source_count": len(batch.sources), "changed": changed,
                    "unchanged": unchanged, "removed": removed, "withdrawn_evidence": withdrawn,
                    "errors": batch.errors, "stats": store.stats(),
                    "notice": "全部真实资料作为待审核证据导入；未调用模型、未自动发布。"})
            if batch.errors:
                return 2  # Valid sources retained, errors explicitly require operator review.
        else:
            if not args.database.is_file():
                raise FileNotFoundError("authoring database is missing")
            store = AuthoringStore(args.database)
            if args.command == "stats":
                _print(store.stats())
            elif args.command == "list":
                _print([item.to_dict() for item in store.list_records(status=args.status, limit=args.limit)])
            elif args.command == "approve":
                item = store.approve(args.evidence_id, college=args.college, subject=args.subject,
                                     stage=args.stage, exam_year=args.year, any_year=args.any_year,
                                     reviewer=args.reviewer, note=args.note)
                _print({"evidence_id": item.evidence_id, "review_status": item.review_status})
            elif args.command == "publish":
                release = store.publish(args.releases_dir, args.version)
                _print({"release_dir": str(release), "knowledge_version": args.version})
        return 0
    except (ValueError, OSError, json.JSONDecodeError) as error:
        print(f"操作未完成：{type(error).__name__}。请核对输入、审核状态、版本和文件完整性。", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
