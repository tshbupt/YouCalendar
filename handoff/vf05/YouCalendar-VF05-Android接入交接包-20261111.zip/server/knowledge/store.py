"""Authoring database, reviewed release export, and immutable CPU retrieval.

The only production read surface is KnowledgeRuntime. It cannot import, approve,
publish, or save a user query. AuthoringStore is an offline operator tool.
"""

from __future__ import annotations

from dataclasses import replace
from datetime import datetime, timezone
import hashlib
from importlib.metadata import version as package_version
import json
import logging
from pathlib import Path
import re
import sqlite3
import unicodedata
from urllib.parse import urlparse

import jieba

from .records import Evidence, SCHEMA_VERSION, SearchQuery, canonical_json


jieba.setLogLevel(logging.WARNING)
_DICTIONARY_PATH = Path(jieba.__file__).resolve().with_name("dict.txt")
_DICTIONARY_SHA = hashlib.sha256(_DICTIONARY_PATH.read_bytes()).hexdigest()
_TOKENIZER = jieba.Tokenizer(dictionary=str(_DICTIONARY_PATH))
# Reuse only a dictionary cache named for the actual source dictionary bytes.
_TOKENIZER.cache_file = f"youcalendar-jieba-{_DICTIONARY_SHA}.cache"
_VERSION_RE = re.compile(r"[A-Za-z0-9][A-Za-z0-9._-]{0,63}\Z")


def _now() -> str:
    return datetime.now(timezone.utc).isoformat()


def _tokens(text: str) -> list[str]:
    normalized = unicodedata.normalize("NFKC", text).lower()
    return [
        word.strip() for word in _TOKENIZER.cut_for_search(normalized, HMM=False)
        if word.strip() and any(char.isalnum() for char in word)
    ]


def _tokenizer_config() -> dict:
    if hashlib.sha256(_DICTIONARY_PATH.read_bytes()).hexdigest() != _DICTIONARY_SHA:
        raise ValueError("dictionary changed after process startup; restart before indexing")
    return {"name": "jieba", "version": package_version("jieba"),
            "dictionary_sha256": _DICTIONARY_SHA,
            "mode": "search", "hmm": False, "normalization": "NFKC-lower"}


def _validate_evidence(record: Evidence, *, for_release: bool = False) -> None:
    for value in (record.evidence_id, record.source_id, record.title, record.text):
        if not isinstance(value, str) or not value.strip():
            raise ValueError("evidence identity, title and text are required")
    if len(record.text) > 100_000 or len(record.evidence_id) > 300:
        raise ValueError("evidence exceeds input bounds")
    url = urlparse(record.source_url)
    if url.scheme not in {"http", "https"} or not url.netloc:
        raise ValueError("a traceable HTTP source URL is required")
    if not isinstance(record.locator, dict) or record.locator.get("level") not in {
        "article", "forum_page", "pdf_page", "image_region"
    }:
        raise ValueError("a truthful source locator is required")
    if not re.fullmatch(r"[0-9a-f]{64}", record.source_hash):
        raise ValueError("source SHA-256 is required")
    if record.review_status not in {"draft", "approved", "disabled"}:
        raise ValueError("unknown review status")
    if for_release:
        if record.review_status != "approved":
            raise ValueError("only approved evidence can be published")
        for field in (record.college, record.subject, record.stage):
            if not isinstance(field, str) or not field.strip() or len(field) > 100:
                raise ValueError("review must specify college, subject and stage; '*' is explicit generality")
        if record.year_scope == "specific":
            if type(record.exam_year) is not int or not 2000 <= record.exam_year <= 2100:
                raise ValueError("specific-year evidence requires an exam year")
        elif record.year_scope == "general":
            if record.exam_year is not None:
                raise ValueError("general-year evidence cannot have an exam year")
        else:
            raise ValueError("unknown exam-year applicability cannot be published")
        if not record.review.get("reviewer") or not record.review.get("note"):
            raise ValueError("human review attribution and note are required")


class AuthoringStore:
    def __init__(self, path: Path | str):
        self.path = Path(path).resolve()
        self.path.parent.mkdir(parents=True, exist_ok=True)
        with self._connection() as connection:
            connection.execute("""CREATE TABLE IF NOT EXISTS evidence (
                evidence_id TEXT PRIMARY KEY, source_id TEXT NOT NULL,
                content_hash TEXT NOT NULL, review_status TEXT NOT NULL,
                payload TEXT NOT NULL)""")
            connection.execute("CREATE INDEX IF NOT EXISTS source_lookup ON evidence(source_id)")

    def _connection(self) -> sqlite3.Connection:
        return sqlite3.connect(self.path)

    def upsert_source(self, source_id: str, records: list[Evidence]) -> dict:
        if not records or any(item.source_id != source_id for item in records):
            raise ValueError("source replacement requires a nonempty, consistent evidence set")
        if len({item.evidence_id for item in records}) != len(records):
            raise ValueError("duplicate evidence IDs in source")
        for item in records:
            _validate_evidence(item)
            if item.review_status != "draft":
                raise ValueError("imports must enter as drafts")
        changed = unchanged = 0
        with self._connection() as connection:
            connection.execute("BEGIN IMMEDIATE")
            previous = {row[0]: (row[1], row[2]) for row in connection.execute(
                "SELECT evidence_id, content_hash, payload FROM evidence WHERE source_id=?", (source_id,)
            )}
            for item in records:
                owner = connection.execute("SELECT source_id FROM evidence WHERE evidence_id=?", (item.evidence_id,)).fetchone()
                if owner and owner[0] != source_id:
                    raise ValueError("evidence ID belongs to another source")
                prior = previous.get(item.evidence_id)
                if prior and prior[0] == item.content_hash and json.loads(prior[1])["review_status"] != "disabled":
                    unchanged += 1
                    continue  # Retain explicit review only for identical source content.
                changed += 1
                draft = replace(item, review_status="draft", review={})
                connection.execute("""INSERT INTO evidence VALUES (?, ?, ?, ?, ?)
                    ON CONFLICT(evidence_id) DO UPDATE SET source_id=excluded.source_id,
                    content_hash=excluded.content_hash, review_status=excluded.review_status,
                    payload=excluded.payload""", (
                        draft.evidence_id, source_id, draft.content_hash, "draft", canonical_json(draft.to_dict())
                    ))
            incoming = {item.evidence_id for item in records}
            for stale in previous.keys() - incoming:
                connection.execute("DELETE FROM evidence WHERE evidence_id=? AND source_id=?", (stale, source_id))
        return {"changed": changed, "unchanged": unchanged, "removed": len(previous.keys() - incoming)}

    def quarantine_source(self, source_id: str) -> None:
        with self._connection() as connection:
            for (payload,) in connection.execute("SELECT payload FROM evidence WHERE source_id=?", (source_id,)).fetchall():
                item = replace(Evidence.from_dict(json.loads(payload)), review_status="draft", review={})
                connection.execute("UPDATE evidence SET review_status='draft', payload=? WHERE evidence_id=?",
                                   (canonical_json(item.to_dict()), item.evidence_id))

    def sync_active_sources(self, active_source_ids: set[str], *, namespace: str = "forum:") -> int:
        """Exclude removed/withdrawn archive sources from the next release."""
        disabled = 0
        with self._connection() as connection:
            for source_id, payload in connection.execute("SELECT source_id, payload FROM evidence").fetchall():
                if not source_id.startswith(namespace) or source_id in active_source_ids:
                    continue
                item = replace(Evidence.from_dict(json.loads(payload)), review_status="disabled", review={})
                connection.execute("UPDATE evidence SET review_status='disabled', payload=? WHERE evidence_id=?",
                                   (canonical_json(item.to_dict()), item.evidence_id))
                disabled += 1
        return disabled

    def get(self, evidence_id: str) -> Evidence | None:
        with self._connection() as connection:
            row = connection.execute("SELECT payload FROM evidence WHERE evidence_id=?", (evidence_id,)).fetchone()
        return Evidence.from_dict(json.loads(row[0])) if row else None

    def list_records(self, *, status: str | None = None, limit: int = 20) -> list[Evidence]:
        if not 1 <= limit <= 10_000:
            raise ValueError("invalid record limit")
        with self._connection() as connection:
            if status:
                rows = connection.execute("SELECT payload FROM evidence WHERE review_status=? ORDER BY evidence_id LIMIT ?", (status, limit))
            else:
                rows = connection.execute("SELECT payload FROM evidence ORDER BY evidence_id LIMIT ?", (limit,))
            return [Evidence.from_dict(json.loads(row[0])) for row in rows]

    def approve(self, evidence_id: str, *, college: str, subject: str, stage: str,
                exam_year: int | None, any_year: bool, reviewer: str, note: str) -> Evidence:
        if any_year == (exam_year is not None):
            raise ValueError("choose exactly one of a specific exam year and explicit any-year applicability")
        with self._connection() as connection:
            # A review and a concurrent source import must not overwrite one another.
            connection.execute("BEGIN IMMEDIATE")
            row = connection.execute("SELECT payload FROM evidence WHERE evidence_id=?", (evidence_id,)).fetchone()
            if row is None:
                raise ValueError("evidence not found")
            prior = Evidence.from_dict(json.loads(row[0]))
            if prior.review_status == "disabled":
                raise ValueError("withdrawn evidence must be re-imported before review")
            item = replace(prior, college=college, subject=subject, stage=stage,
                           exam_year=exam_year, year_scope="general" if any_year else "specific",
                           review_status="approved", review={"reviewer": reviewer.strip(), "note": note.strip(), "at": _now()})
            _validate_evidence(item, for_release=True)
            connection.execute("UPDATE evidence SET review_status='approved', payload=? WHERE evidence_id=?",
                               (canonical_json(item.to_dict()), evidence_id))
        return item

    def stats(self) -> dict:
        with self._connection() as connection:
            statuses = dict(connection.execute("SELECT review_status, count(*) FROM evidence GROUP BY review_status"))
            sources = connection.execute("SELECT count(DISTINCT source_id) FROM evidence").fetchone()[0]
        return {"source_count": sources, "evidence_count": sum(statuses.values()), "review_status": statuses}

    def publish(self, releases_dir: Path | str, knowledge_version: str) -> Path:
        if not _VERSION_RE.fullmatch(knowledge_version):
            raise ValueError("invalid knowledge version")
        with self._connection() as connection:
            records = [Evidence.from_dict(json.loads(row[0])) for row in connection.execute(
                "SELECT payload FROM evidence WHERE review_status='approved' ORDER BY evidence_id"
            )]
        if not records:
            raise ValueError("nothing approved; unreviewed source text cannot be published")
        for record in records:
            _validate_evidence(record, for_release=True)
        tokenizer = _tokenizer_config()
        target = Path(releases_dir).resolve() / knowledge_version
        if self.path.is_relative_to(target):
            raise ValueError("release cannot contain the authoring database")
        target.mkdir(parents=True, exist_ok=False)  # Never overwrite a published version.
        with (target / "evidence.jsonl").open("w", encoding="utf-8", newline="\n") as output:
            for record in records:
                output.write(canonical_json(record.to_dict()) + "\n")
        database = target / "search.sqlite"
        with sqlite3.connect(database) as connection:
            connection.execute("""CREATE TABLE evidence (
                evidence_id TEXT PRIMARY KEY, college TEXT NOT NULL, subject TEXT NOT NULL,
                stage TEXT NOT NULL, exam_year INTEGER, year_scope TEXT NOT NULL, payload TEXT NOT NULL)""")
            connection.execute("CREATE VIRTUAL TABLE evidence_fts USING fts5(evidence_id UNINDEXED, title_tokens, body_tokens)")
            for record in records:
                connection.execute("INSERT INTO evidence VALUES (?, ?, ?, ?, ?, ?, ?)", (
                    record.evidence_id, record.college, record.subject, record.stage,
                    record.exam_year, record.year_scope, canonical_json(record.to_dict())
                ))
                connection.execute("INSERT INTO evidence_fts VALUES (?, ?, ?)", (
                    record.evidence_id, " ".join(_tokens(record.title)), " ".join(_tokens(record.text))
                ))
            connection.execute("INSERT INTO evidence_fts(evidence_fts) VALUES ('optimize')")
        hashes = {name: hashlib.sha256((target / name).read_bytes()).hexdigest()
                  for name in ("evidence.jsonl", "search.sqlite")}
        manifest = {"schema_version": SCHEMA_VERSION, "knowledge_version": knowledge_version,
                    "created_at": _now(), "evidence_count": len(records),
                    "source_count": len({item.source_id for item in records}),
                    "tokenizer": tokenizer, "files": hashes}
        # Readiness marker is written last; a partial build cannot be served.
        (target / "manifest.json").write_text(canonical_json(manifest) + "\n", encoding="utf-8")
        return target


class KnowledgeRuntime:
    def __init__(self, release_dir: Path | str):
        self.release_dir = Path(release_dir).resolve()
        manifest = json.loads((self.release_dir / "manifest.json").read_text(encoding="utf-8"))
        if manifest.get("schema_version") != SCHEMA_VERSION:
            raise ValueError("unsupported release schema")
        if not _VERSION_RE.fullmatch(str(manifest.get("knowledge_version", ""))):
            raise ValueError("invalid release version")
        if manifest.get("tokenizer") != _tokenizer_config():
            raise ValueError("release tokenizer differs from runtime; rebuild or use locked dependencies")
        if set(manifest.get("files", {})) != {"evidence.jsonl", "search.sqlite"}:
            raise ValueError("unexpected release contents")
        for name, expected in manifest["files"].items():
            path = self.release_dir / name
            if path.is_symlink() or not path.is_file() or path.resolve().parent != self.release_dir:
                raise ValueError("release files must be local regular files")
            if hashlib.sha256(path.read_bytes()).hexdigest() != expected:
                raise ValueError("release hash mismatch")
        self.knowledge_version = manifest["knowledge_version"]
        self.database = self.release_dir / "search.sqlite"
        with self._connection() as connection:
            rows = connection.execute("SELECT payload FROM evidence").fetchall()
            if len(rows) != manifest.get("evidence_count"):
                raise ValueError("release evidence count mismatch")
            for row in rows:
                _validate_evidence(Evidence.from_dict(json.loads(row[0])), for_release=True)

    def _connection(self) -> sqlite3.Connection:
        return sqlite3.connect(self.database.as_uri() + "?mode=ro&immutable=1", uri=True)

    def search(self, query: SearchQuery) -> dict:
        query.validate()
        terms = list(dict.fromkeys(_tokens(query.text)))
        response = {"schema_version": SCHEMA_VERSION, "knowledge_version": self.knowledge_version, "results": []}
        if not terms:
            return response
        match = " OR ".join('"' + word.replace('"', '""') + '"' for word in terms)
        clauses = ["evidence_fts MATCH ?"]
        params: list = [match]
        for column, value in (("college", query.college), ("subject", query.subject), ("stage", query.stage)):
            if value is not None:
                clauses.append(f"(e.{column}=? OR e.{column}='*')")
                params.append(value)
        if query.exam_year is not None:
            clauses.append("(e.exam_year=? OR e.year_scope='general')")
            params.append(query.exam_year)
        params.append(query.limit)
        sql = """SELECT e.payload, bm25(evidence_fts, 0.0, 2.0, 1.0) AS rank
                 FROM evidence_fts JOIN evidence e ON e.evidence_id=evidence_fts.evidence_id
                 WHERE """ + " AND ".join(clauses) + " ORDER BY rank, e.evidence_id LIMIT ?"
        with self._connection() as connection:
            for payload, rank in connection.execute(sql, params):
                result = json.loads(payload)
                result["score"] = -rank
                response["results"].append(result)
        return response

    def get_evidence(self, evidence_id: str) -> dict | None:
        with self._connection() as connection:
            row = connection.execute("SELECT payload FROM evidence WHERE evidence_id=?", (evidence_id,)).fetchone()
        return json.loads(row[0]) if row else None
