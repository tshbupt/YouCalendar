"""Stateless and bounded text feedback admission."""

from collections.abc import AsyncGenerator
from contextlib import aclosing
from typing import Annotated

from fastapi import APIRouter, Depends, Request
from fastapi.responses import Response
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer
from pydantic import ValidationError
from starlette.requests import ClientDisconnect

from ..contracts.feedback import StageEvent, TextFeedbackRequest
from ..providers.feedback import FeedbackOrganizer
from .stream import (
    DEFAULT_PROCESSING_TIMEOUT, FeedbackInputError, FeedbackStream, access_error,
    bounded_body, http_error, organize_events, sse,
)


MAX_REQUEST_BYTES = 1_048_576


async def _events(
    payload: TextFeedbackRequest, organizer: FeedbackOrganizer, timeout: float,
) -> AsyncGenerator[bytes, None]:
    attempt = payload.context.ref.attempt_id
    yield sse(StageEvent(type="stage", attempt_id=attempt, seq=1, stage="received"))
    async with aclosing(organize_events(payload, organizer, timeout, first_seq=2)) as events:
        async for event in events:
            yield event


def text_feedback_router(
    token: str | None,
    organizer: FeedbackOrganizer | None,
    timeout: float = DEFAULT_PROCESSING_TIMEOUT,
) -> APIRouter:
    router = APIRouter()
    bearer = HTTPBearer(auto_error=False)

    @router.post("/v1/feedback/text", response_class=FeedbackStream)
    async def feedback_text(
        request: Request,
        credentials: Annotated[HTTPAuthorizationCredentials | None, Depends(bearer)],
    ) -> Response:
        failure = access_error(token, credentials, available=organizer is not None)
        if failure is not None:
            return failure
        assert organizer is not None
        media_type = request.headers.get("content-type", "").split(";", 1)[0].strip().lower()
        if media_type != "application/json":
            return http_error(415, "unsupported_media_type")

        body = bytearray()
        try:
            async for chunk in bounded_body(request, MAX_REQUEST_BYTES):
                body.extend(chunk)
            payload = TextFeedbackRequest.model_validate_json(body)
        except FeedbackInputError as exc:
            return http_error(exc.status, exc.code)
        except (ClientDisconnect, ValidationError):
            return http_error(400, "invalid_request")

        return FeedbackStream(
            _events(payload, organizer, timeout), headers={"Cache-Control": "no-store"},
        )

    return router
