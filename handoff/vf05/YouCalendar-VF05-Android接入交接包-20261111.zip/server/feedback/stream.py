"""Shared feedback admission, SSE transport, and draft processing."""

import asyncio
from collections.abc import AsyncGenerator
from contextlib import aclosing
import secrets

from anyio import create_task_group
from fastapi import Request
from fastapi.responses import JSONResponse, StreamingResponse
from fastapi.security import HTTPAuthorizationCredentials
from starlette.types import Receive, Scope, Send

from ..contracts.feedback import (
    ErrorEvent, FeedbackDraft, FeedbackEvent, HttpError, HttpErrorCode, ResultEvent,
    StageEvent, TextFeedbackRequest, check_text_draft,
)
from ..providers.feedback import FeedbackOrganizer, FeedbackProviderError


MAX_DRAFT_BYTES = 2_097_152
DEFAULT_PROCESSING_TIMEOUT = 15.0


class FeedbackStream(StreamingResponse):
    """Cancel pending work when the client closes the HTTP connection."""

    media_type = "text/event-stream"

    async def __call__(self, scope: Scope, receive: Receive, send: Send) -> None:
        async with aclosing(self.body_iterator):
            async with create_task_group() as tasks:
                async def stop_on_disconnect() -> None:
                    await self.listen_for_disconnect(receive)
                    tasks.cancel_scope.cancel()

                tasks.start_soon(stop_on_disconnect)
                try:
                    await self.stream_response(send)
                except OSError:
                    # Some ASGI servers signal a closed socket from send().
                    pass
                finally:
                    tasks.cancel_scope.cancel()


class FeedbackInputError(Exception):
    def __init__(self, status: int, code: HttpErrorCode):
        super().__init__(code)
        self.status = status
        self.code = code


def http_error(status: int, code: HttpErrorCode) -> JSONResponse:
    headers = {"Cache-Control": "no-store"}
    if status == 401:
        headers["WWW-Authenticate"] = "Bearer"
    return JSONResponse(
        HttpError(code=code).model_dump(exclude_none=True), status_code=status, headers=headers,
    )


def access_error(
    token: str | None, credentials: HTTPAuthorizationCredentials | None, *, available: bool,
) -> JSONResponse | None:
    if not token or not token.strip():
        return http_error(503, "service_unavailable")
    if credentials is None or not secrets.compare_digest(
        credentials.credentials.encode("utf-8"), token.encode("utf-8"),
    ):
        return http_error(401, "unauthorized")
    if not available:
        return http_error(503, "service_unavailable")
    return None


async def bounded_body(request: Request, max_bytes: int) -> AsyncGenerator[bytes, None]:
    try:
        declared_length = int(request.headers.get("content-length", "0"))
    except ValueError:
        raise FeedbackInputError(400, "invalid_request") from None
    if declared_length < 0:
        raise FeedbackInputError(400, "invalid_request")
    if declared_length > max_bytes:
        raise FeedbackInputError(413, "payload_too_large")
    seen = 0
    async for chunk in request.stream():
        seen += len(chunk)
        if seen > max_bytes:
            raise FeedbackInputError(413, "payload_too_large")
        if chunk:
            yield chunk


def sse(event: FeedbackEvent) -> bytes:
    return f"data: {event.model_dump_json()}\n\n".encode("utf-8")


async def organize_events(
    payload: TextFeedbackRequest, organizer: FeedbackOrganizer, timeout: float, *, first_seq: int,
) -> AsyncGenerator[bytes, None]:
    attempt = payload.context.ref.attempt_id
    yield sse(StageEvent(type="stage", attempt_id=attempt, seq=first_seq, stage="structuring"))
    error_seq = first_seq + 1
    try:
        async with asyncio.timeout(timeout):
            raw = await organizer.organize(payload)
    except TimeoutError:
        yield sse(ErrorEvent(type="error", attempt_id=attempt, seq=error_seq, code="processing_timeout"))
        return
    except FeedbackProviderError:
        yield sse(ErrorEvent(type="error", attempt_id=attempt, seq=error_seq, code="provider_failed"))
        return
    except Exception:
        yield sse(ErrorEvent(type="error", attempt_id=attempt, seq=error_seq, code="internal_error"))
        return

    yield sse(StageEvent(type="stage", attempt_id=attempt, seq=error_seq, stage="validating"))
    result_seq = error_seq + 1
    try:
        if not isinstance(raw, str) or len(raw.encode("utf-8")) > MAX_DRAFT_BYTES:
            raise ValueError("invalid draft size or type")
        draft = FeedbackDraft.model_validate_json(raw)
        check_text_draft(draft, payload)
    except ValueError:
        yield sse(ErrorEvent(type="error", attempt_id=attempt, seq=result_seq, code="invalid_output"))
        return
    yield sse(ResultEvent(type="result", attempt_id=attempt, seq=result_seq, draft=draft))
