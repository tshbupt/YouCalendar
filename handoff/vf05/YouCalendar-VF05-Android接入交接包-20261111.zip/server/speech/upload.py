"""Bounded, memory-only multipart input and PCM WAV validation."""

from io import BytesIO
import logging
import re
import struct
import wave

from fastapi import Request
from python_multipart import MultipartParser
from python_multipart.exceptions import MultipartParseError
from python_multipart.multipart import parse_options_header

from ..contracts.feedback import AudioFeedbackContext
from ..feedback.stream import FeedbackInputError, bounded_body


MAX_WAV_BYTES = 2 * 1024 * 1024
MAX_METADATA_BYTES = 1024 * 1024
MAX_UPLOAD_BYTES = MAX_WAV_BYTES + MAX_METADATA_BYTES + 8 * 1024
SAMPLE_RATE = 16_000
MAX_SECONDS = 60
PART_LIMITS = {b"audio": MAX_WAV_BYTES, b"metadata": MAX_METADATA_BYTES}


class AudioParts:
    def __init__(self):
        self.parts: dict[bytes, bytearray] = {}
        self.ended = False

    def on_part_begin(self) -> None:
        if len(self.parts) == len(PART_LIMITS):
            raise FeedbackInputError(400, "invalid_request")
        self.headers: dict[bytes, bytes] = {}
        self.field = bytearray()
        self.value = bytearray()

    def on_header_field(self, data: bytes, start: int, end: int) -> None:
        self.field.extend(data[start:end])

    def on_header_value(self, data: bytes, start: int, end: int) -> None:
        self.value.extend(data[start:end])

    def on_header_end(self) -> None:
        key = bytes(self.field).lower()
        if key in self.headers or key == b"content-transfer-encoding":
            raise FeedbackInputError(400, "invalid_request")
        self.headers[key] = bytes(self.value)
        self.field.clear()
        self.value.clear()

    def on_headers_finished(self) -> None:
        disposition, options = parse_options_header(self.headers.get(b"content-disposition"))
        name = options.get(b"name", b"")
        if disposition.lower() != b"form-data" or name not in PART_LIMITS or name in self.parts:
            raise FeedbackInputError(400, "invalid_request")
        media, _ = parse_options_header(self.headers.get(b"content-type"))
        allowed = (b"audio/wav", b"audio/x-wav") if name == b"audio" else (b"application/json",)
        if media.lower() not in allowed:
            raise FeedbackInputError(415, "unsupported_media_type")
        self.current_name = name
        self.parts[name] = bytearray()

    def on_part_data(self, data: bytes, start: int, end: int) -> None:
        part = self.parts[self.current_name]
        if len(part) + end - start > PART_LIMITS[self.current_name]:
            raise FeedbackInputError(413, "payload_too_large")
        part.extend(data[start:end])

    def on_end(self) -> None:
        self.ended = True


async def read_audio_upload(request: Request) -> tuple[AudioFeedbackContext, bytes]:
    media, options = parse_options_header(request.headers.get("content-type"))
    if media.lower() != b"multipart/form-data":
        raise FeedbackInputError(415, "unsupported_media_type")
    boundary = options.get(b"boundary", b"")
    if not re.fullmatch(rb"[A-Za-z0-9'()+_,./:=? -]{1,70}", boundary) or boundary.endswith(b" "):
        raise FeedbackInputError(400, "invalid_request")

    upload = AudioParts()
    callbacks = {name: getattr(upload, name) for name in (
        "on_part_begin", "on_header_field", "on_header_value", "on_header_end",
        "on_headers_finished", "on_part_data", "on_end",
    )}
    parser = MultipartParser(boundary, callbacks, max_header_count=4, max_header_size=2048)
    # Parser warnings can quote malformed body bytes. Return only the contract error code.
    parser.logger = logging.Logger(__name__)
    parser.logger.disabled = True
    try:
        async for chunk in bounded_body(request, MAX_UPLOAD_BYTES):
            parser.write(chunk)
        parser.finalize()
    except MultipartParseError:
        raise FeedbackInputError(400, "invalid_request") from None
    if not upload.ended or upload.parts.keys() != PART_LIMITS.keys():
        raise FeedbackInputError(400, "invalid_request")
    metadata = AudioFeedbackContext.model_validate_json(upload.parts[b"metadata"])
    return metadata, bytes(upload.parts[b"audio"])


def wav_has_signal(audio: bytes) -> bool:
    """Check the WAV header and samples, then detect deterministic zero-valued silence."""
    if len(audio) < 12 or audio[:4] != b"RIFF" or audio[8:12] != b"WAVE":
        raise FeedbackInputError(400, "invalid_request")
    if struct.unpack_from("<I", audio, 4)[0] + 8 != len(audio):
        raise FeedbackInputError(400, "invalid_request")
    try:
        with wave.open(BytesIO(audio), "rb") as recording:
            if (recording.getnchannels(), recording.getsampwidth(), recording.getframerate()) != (1, 2, SAMPLE_RATE):
                raise FeedbackInputError(415, "unsupported_media_type")
            frames = recording.getnframes()
            if frames > SAMPLE_RATE * MAX_SECONDS:
                raise FeedbackInputError(413, "payload_too_large")
            samples = recording.readframes(frames + 1)
    except (EOFError, wave.Error, RuntimeError, struct.error):
        raise FeedbackInputError(400, "invalid_request") from None
    if len(samples) != frames * 2:
        raise FeedbackInputError(400, "invalid_request")
    return samples.count(b"\x00") != len(samples)
