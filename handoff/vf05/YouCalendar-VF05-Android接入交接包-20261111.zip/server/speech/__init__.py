"""Speech input and recognition boundaries for feedback."""
