"""Recognizers return the transcript used by the text feedback pipeline."""

from typing import Protocol


class SpeechProviderError(Exception):
    """Recognition failed at the provider boundary."""


class UnusableAudio(Exception):
    """Audio contains no recognizable content for this recognizer."""


class SpeechRecognizer(Protocol):
    async def recognize(self, wav: bytes) -> str:
        """Return text for the accepted WAV and propagate cancellation."""
        ...
