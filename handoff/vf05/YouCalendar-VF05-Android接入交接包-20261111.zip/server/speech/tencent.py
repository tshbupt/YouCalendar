"""Tencent Cloud SentenceRecognition adapter for mainland short-audio requests."""

import base64
from dataclasses import dataclass
from datetime import datetime, timezone
import hashlib
import hmac
import json
import re
import time

import httpx

from .recognizer import SpeechProviderError, UnusableAudio


HOST = "asr.ap-shanghai.tencentcloudapi.com"
ENDPOINT = f"https://{HOST}/"
ACTION = "SentenceRecognition"
VERSION = "2019-06-14"
CONTENT_TYPE = "application/json; charset=utf-8"
MAX_ENCODED_AUDIO = 3_000_000
MAX_RESPONSE = 128 * 1024


class TencentSpeechError(SpeechProviderError):
    def __init__(self, code: str):
        self.code = code
        super().__init__(code)


@dataclass(frozen=True)
class Recognition:
    text: str
    request_id: str | None


def _authorization(
    secret_id: str, secret_key: str, *, host: str, service: str, action: str,
    timestamp: int, body: bytes,
) -> str:
    date = datetime.fromtimestamp(timestamp, tz=timezone.utc).strftime("%Y-%m-%d")
    scope = f"{date}/{service}/tc3_request"
    signed = "content-type;host;x-tc-action"
    canonical = (
        f"POST\n/\n\ncontent-type:{CONTENT_TYPE}\nhost:{host}\n"
        f"x-tc-action:{action.lower()}\n\n{signed}\n{hashlib.sha256(body).hexdigest()}"
    )
    algorithm = "TC3-HMAC-SHA256"
    to_sign = f"{algorithm}\n{timestamp}\n{scope}\n{hashlib.sha256(canonical.encode()).hexdigest()}"
    date_key = hmac.digest(f"TC3{secret_key}".encode(), date.encode(), "sha256")
    service_key = hmac.digest(date_key, service.encode(), "sha256")
    signing_key = hmac.digest(service_key, b"tc3_request", "sha256")
    signature = hmac.digest(signing_key, to_sign.encode(), "sha256").hex()
    return f"{algorithm} Credential={secret_id}/{scope}, SignedHeaders={signed}, Signature={signature}"


def _decode_response(raw: bytes | bytearray) -> Recognition:
    try:
        response = json.loads(raw)["Response"]
        if not isinstance(response, dict):
            raise ValueError
    except (ValueError, TypeError, KeyError, RecursionError):
        raise TencentSpeechError("invalid_response") from None
    if "Error" in response:
        error = response["Error"]
        code = error.get("Code") if isinstance(error, dict) else None
        raise TencentSpeechError(code if isinstance(code, str) and re.fullmatch(r"[A-Za-z0-9_.]{1,100}", code)
                                 else "provider_error")
    transcript = response.get("Result")
    if not isinstance(transcript, str) or len(transcript) > 8000:
        raise TencentSpeechError("invalid_transcript")
    if not transcript.strip():
        raise UnusableAudio("Tencent Cloud returned no transcript")
    request_id = response.get("RequestId")
    if not isinstance(request_id, str) or not re.fullmatch(r"[A-Za-z0-9-]{1,80}", request_id):
        request_id = None
    return Recognition(transcript, request_id)


class TencentSpeechRecognizer:
    def __init__(self, client: httpx.AsyncClient, secret_id: str, secret_key: str, token: str | None = None):
        self._client = client
        self._secret_id = secret_id
        self._secret_key = secret_key
        self._token = token

    async def transcribe(self, wav: bytes) -> Recognition:
        if not wav or 4 * ((len(wav) + 2) // 3) > MAX_ENCODED_AUDIO:
            raise TencentSpeechError("audio_size")
        payload = json.dumps({
            "EngSerViceType": "16k_zh", "SourceType": 1, "VoiceFormat": "wav",
            "Data": base64.b64encode(wav).decode("ascii"), "DataLen": len(wav),
            "ConvertNumMode": 1,
        }, separators=(",", ":")).encode("utf-8")
        timestamp = int(time.time())
        headers = {
            "Host": HOST, "Content-Type": CONTENT_TYPE, "X-TC-Action": ACTION,
            "X-TC-Version": VERSION, "X-TC-Timestamp": str(timestamp), "Accept-Encoding": "identity",
            "Authorization": _authorization(
                self._secret_id, self._secret_key, host=HOST, service="asr", action=ACTION,
                timestamp=timestamp, body=payload,
            ),
        }
        if self._token:
            headers["X-TC-Token"] = self._token
        try:
            async with self._client.stream(
                "POST", ENDPOINT, content=payload, headers=headers, follow_redirects=False,
            ) as response:
                if response.status_code != 200:
                    raise TencentSpeechError(f"http_{response.status_code}")
                raw = bytearray()
                async for chunk in response.aiter_bytes():
                    if len(raw) + len(chunk) > MAX_RESPONSE:
                        raise TencentSpeechError("response_too_large")
                    raw.extend(chunk)
        except httpx.TimeoutException:
            raise TimeoutError("Tencent Cloud ASR timed out") from None
        except httpx.HTTPError:
            raise TencentSpeechError("transport_error") from None
        return _decode_response(raw)

    async def recognize(self, wav: bytes) -> str:
        return (await self.transcribe(wav)).text
