"""Audio feedback route that feeds the transcript to the shared text organizer."""

import asyncio
from collections.abc import AsyncGenerator
from contextlib import aclosing
from typing import Annotated

from fastapi import APIRouter, Depends, Request
from fastapi.responses import Response
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer
from pydantic import ValidationError
from starlette.requests import ClientDisconnect

from ..contracts.feedback import AudioFeedbackContext, ErrorEvent, StageEvent, TextFeedbackRequest
from ..feedback.stream import (
    FeedbackInputError, FeedbackStream, access_error, http_error, organize_events, sse,
)
from ..providers.feedback import FeedbackOrganizer
from .recognizer import SpeechProviderError, SpeechRecognizer, UnusableAudio
from .upload import read_audio_upload, wav_has_signal


async def _events(
    metadata: AudioFeedbackContext, audio: bytes, has_signal: bool,
    recognizer: SpeechRecognizer, organizer: FeedbackOrganizer, timeout: float,
) -> AsyncGenerator[bytes, None]:
    attempt = metadata.context.ref.attempt_id
    yield sse(StageEvent(type="stage", attempt_id=attempt, seq=1, stage="received"))
    yield sse(StageEvent(type="stage", attempt_id=attempt, seq=2, stage="recognizing"))
    try:
        if not has_signal:
            raise UnusableAudio()
        async with asyncio.timeout(timeout):
            transcript = await recognizer.recognize(audio)
        if isinstance(transcript, str) and not transcript.strip():
            raise UnusableAudio()
        text = TextFeedbackRequest(context=metadata.context, text=transcript)
    except UnusableAudio:
        yield sse(ErrorEvent(type="error", attempt_id=attempt, seq=3, code="unusable_audio"))
        return
    except TimeoutError:
        yield sse(ErrorEvent(type="error", attempt_id=attempt, seq=3, code="processing_timeout"))
        return
    except (SpeechProviderError, ValidationError):
        yield sse(ErrorEvent(type="error", attempt_id=attempt, seq=3, code="asr_failed"))
        return
    except Exception:
        yield sse(ErrorEvent(type="error", attempt_id=attempt, seq=3, code="internal_error"))
        return
    finally:
        del audio

    async with aclosing(organize_events(text, organizer, timeout, first_seq=3)) as events:
        async for event in events:
            yield event


def audio_feedback_router(
    token: str | None, organizer: FeedbackOrganizer | None,
    recognizer: SpeechRecognizer | None, timeout: float,
) -> APIRouter:
    router = APIRouter()
    bearer = HTTPBearer(auto_error=False)

    @router.post("/v1/feedback/audio", response_class=FeedbackStream)
    async def feedback_audio(
        request: Request,
        credentials: Annotated[HTTPAuthorizationCredentials | None, Depends(bearer)],
    ) -> Response:
        failure = access_error(token, credentials, available=organizer is not None and recognizer is not None)
        if failure is not None:
            return failure
        assert organizer is not None and recognizer is not None
        try:
            async with asyncio.timeout(timeout):
                metadata, audio = await read_audio_upload(request)
            has_signal = wav_has_signal(audio)
        except FeedbackInputError as exc:
            return http_error(exc.status, exc.code)
        except (TimeoutError, ClientDisconnect, ValidationError):
            return http_error(400, "invalid_request")

        return FeedbackStream(
            _events(metadata, audio, has_signal, recognizer, organizer, timeout),
            headers={"Cache-Control": "no-store"},
        )

    return router
