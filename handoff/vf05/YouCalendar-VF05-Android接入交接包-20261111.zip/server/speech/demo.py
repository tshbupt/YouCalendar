"""Local speech demo with a deterministic synthetic WAV signal."""

import argparse
import asyncio
from io import BytesIO
from pathlib import Path
import wave

from .recognizer import UnusableAudio


def demo_wav() -> bytes:
    target = BytesIO()
    with wave.open(target, "wb") as recording:
        recording.setparams((1, 2, 16_000, 0, "NONE", "not compressed"))
        recording.writeframes((b"\xa0\x0f" * 20 + b"\x60\xf0" * 20) * 100)
    return target.getvalue()


class DemoSpeechRecognizer:
    def __init__(self):
        self._fixture = demo_wav()

    async def recognize(self, wav: bytes) -> str:
        await asyncio.sleep(0.3)
        if wav != self._fixture:
            raise UnusableAudio("audio does not match the synthetic demo signal")
        return "上午高数一共做了12题。"


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("output", type=Path)
    args = parser.parse_args()
    with args.output.open("xb") as destination:
        destination.write(demo_wav())
