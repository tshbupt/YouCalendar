"""Document routes that parse bounded request bodies outside FastAPI."""

from typing import Any

from fastapi import FastAPI

from .export_feedback_schema import feedback_schema


def document_feedback_routes(app: FastAPI) -> None:
    base_openapi = app.openapi

    def openapi() -> dict[str, Any]:
        if app.openapi_schema is not None:
            return app.openapi_schema

        schema = base_openapi()
        ref_template = "#/components/schemas/{model}"
        definitions = feedback_schema(ref_template=ref_template)["$defs"]
        text_request = definitions.pop("text_request")
        audio_context = definitions.pop("audio_context")
        http_error = definitions.pop("http_error")
        definitions["FeedbackEvent"] = definitions.pop("sse_event")
        schema["components"]["schemas"].update(definitions)

        text_content = {"application/json": {"schema": text_request}}
        audio_content = {
            "multipart/form-data": {
                "schema": {
                    "type": "object",
                    "additionalProperties": False,
                    "required": ["metadata", "audio"],
                    "properties": {
                        "metadata": audio_context,
                        "audio": {
                            "type": "string",
                            "format": "binary",
                            "description": "16 kHz, 16-bit, mono PCM WAV, up to 60 seconds.",
                        },
                    },
                },
                "encoding": {
                    "metadata": {"contentType": "application/json"},
                    "audio": {"contentType": "audio/wav, audio/x-wav"},
                },
            },
        }
        errors = {
            "400": "Invalid request.",
            "401": "Missing or invalid feedback bearer token.",
            "413": "Request exceeds size or duration limits.",
            "415": "Unsupported media type or audio parameters.",
            "503": "Feedback service unavailable.",
        }

        for route, content in {"text": text_content, "audio": audio_content}.items():
            operation = schema["paths"][f"/v1/feedback/{route}"]["post"]
            operation["requestBody"] = {"required": True, "content": content}
            responses = operation["responses"]
            success = responses["200"]
            success["description"] = (
                "UTF-8 SSE. Each data frame contains one FeedbackEvent JSON object. "
                "A result or error event ends the stream."
            )
            success["content"]["text/event-stream"]["x-sse-event-schema"] = {
                "$ref": ref_template.format(model="FeedbackEvent"),
            }
            for status, description in errors.items():
                responses[status] = {
                    "description": description,
                    "content": {"application/json": {"schema": http_error}},
                }

        return schema

    app.openapi = openapi
