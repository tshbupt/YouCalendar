"""Wire payloads and deterministic contract checks for feedback v1."""

from __future__ import annotations

from datetime import date
from typing import Annotated, Literal

from pydantic import BaseModel, ConfigDict, Field, StringConstraints, field_validator, model_validator


Identifier = Annotated[str, StringConstraints(pattern=r"^[A-Za-z0-9_-]{1,128}$")]
V1 = Annotated[int, Field(ge=1, le=1)]
Revision = Annotated[int, Field(ge=1, le=9_007_199_254_740_991)]
Count = Annotated[int, Field(ge=0, le=1_000_000)]
PositiveCount = Annotated[int, Field(ge=1, le=1_000_000)]
Label = Annotated[str, StringConstraints(pattern=r"\S", max_length=120)]
Note = Annotated[str, StringConstraints(pattern=r"\S", max_length=1000)]
UtcOffset = Annotated[
    str, StringConstraints(pattern=r"^[+-](?:(?:0[0-9]|1[0-3]):[0-5][0-9]|14:00)$")
]


class WireModel(BaseModel):
    model_config = ConfigDict(strict=True, extra="forbid", hide_input_in_errors=True)


class RequestRef(WireModel):
    schema_version: V1
    submission_id: Identifier
    attempt_id: Identifier
    study_date: Annotated[
        str, Field(pattern=r"^[0-9]{4}-[0-9]{2}-[0-9]{2}$", json_schema_extra={"format": "date"})
    ]
    utc_offset: UtcOffset
    snapshot_revision: Revision

    @field_validator("study_date")
    @classmethod
    def check_study_date(cls, value: str) -> str:
        date.fromisoformat(value)
        return value


class Progress(WireModel):
    status: Literal["pending", "completed", "partial", "not_completed"]
    completed_count: Count | None
    reason: Note | None

    def check_for_total(self, planned_count: int | None) -> None:
        """Check a saved snapshot or a resolved proposal against the task total."""
        if self.status == "pending":
            if self.completed_count is not None or self.reason is not None:
                raise ValueError("pending progress has no count or reason")
            return
        if self.status == "not_completed" and self.reason is None:
            raise ValueError("not_completed progress requires a reason")
        if planned_count is None:
            if self.completed_count is not None:
                raise ValueError("unquantified progress has no completed_count")
            return
        count = self.completed_count
        if self.status == "completed" and count != planned_count:
            raise ValueError("completed count must equal planned_count")
        if self.status == "partial" and (count is None or not 0 < count < planned_count):
            raise ValueError("partial count must be between zero and planned_count")
        if self.status == "not_completed" and count != 0:
            raise ValueError("not_completed count must be zero")


class TaskSnapshot(WireModel):
    task_id: Identifier
    task_revision: Revision
    title: Label
    subject: Label | None = None
    slot_label: Label | None = None
    planned_count: PositiveCount | None
    unit: Label | None
    progress: Progress

    @model_validator(mode="after")
    def check_snapshot(self) -> TaskSnapshot:
        if (self.planned_count is None) != (self.unit is None):
            raise ValueError("planned_count and unit must be supplied together")
        self.progress.check_for_total(self.planned_count)
        return self


class FeedbackContext(WireModel):
    ref: RequestRef
    tasks: Annotated[list[TaskSnapshot], Field(max_length=100)]

    @model_validator(mode="after")
    def check_unique_tasks(self) -> FeedbackContext:
        if len({task.task_id for task in self.tasks}) != len(self.tasks):
            raise ValueError("task IDs must be unique within a snapshot")
        return self


class TextFeedbackRequest(WireModel):
    context: FeedbackContext
    text: Annotated[str, StringConstraints(pattern=r"\S", max_length=8000)]


class AudioFeedbackContext(WireModel):
    """JSON metadata from the context part of an audio multipart request."""

    context: FeedbackContext


class QuantityObservation(WireModel):
    meaning: Literal["total", "increment", "unclear"]
    value: Count | None
    unit: Label | None


TaskIssue = Literal[
    "status_unclear",
    "missing_quantity",
    "quantity_meaning_unclear",
    "unit_mismatch",
    "count_out_of_range",
    "missing_reason",
    "status_count_conflict",
]


class TaskFeedback(WireModel):
    task_id: Identifier
    task_revision: Revision
    evidence: Note
    before: Progress
    candidate: Progress | None
    reported_quantity: QuantityObservation | None
    remaining_count: Count | None
    issues: Annotated[list[TaskIssue], Field(max_length=7)]

    @model_validator(mode="after")
    def check_resolution(self) -> TaskFeedback:
        if self.candidate is not None and self.candidate.status == "pending":
            raise ValueError("a proposal cannot replace saved progress with pending")
        if self.issues:
            if self.remaining_count is not None or (
                self.candidate is not None and self.candidate.completed_count is not None
            ):
                raise ValueError("a blocked proposal has no normalized counts")
        elif self.candidate is None:
            raise ValueError("a proposal without issues requires a candidate")
        return self


class UnmatchedFeedback(WireModel):
    evidence: Note
    candidate_task_ids: Annotated[list[Identifier], Field(max_length=100)]

    @model_validator(mode="after")
    def check_candidates(self) -> UnmatchedFeedback:
        if len(self.candidate_task_ids) == 1:
            raise ValueError("unmatched feedback needs zero or multiple candidate tasks")
        if len(set(self.candidate_task_ids)) != len(self.candidate_task_ids):
            raise ValueError("candidate task IDs must be unique")
        return self


class FeedbackDraft(WireModel):
    ref: RequestRef
    draft_revision: V1
    state: Literal["ready_for_confirmation", "needs_user_input"]
    changes: Annotated[list[TaskFeedback], Field(max_length=100)]
    unmatched: Annotated[list[UnmatchedFeedback], Field(max_length=100)]
    date_needs_confirmation: bool
    summary: Note | None

    @model_validator(mode="after")
    def check_draft(self) -> FeedbackDraft:
        if not (self.changes or self.unmatched or self.summary or self.date_needs_confirmation):
            raise ValueError("empty feedback draft")
        if len({change.task_id for change in self.changes}) != len(self.changes):
            raise ValueError("duplicate task proposals")
        blocked = self.unmatched or self.date_needs_confirmation or any(
            change.issues for change in self.changes
        )
        expected = "needs_user_input" if blocked else "ready_for_confirmation"
        if self.state != expected:
            raise ValueError("draft state disagrees with unresolved issues")
        return self


def check_draft_against_context(draft: FeedbackDraft, context: FeedbackContext) -> None:
    """Check the model-independent invariants that require the original request."""
    if draft.ref != context.ref:
        raise ValueError("draft reference does not match request context")
    tasks = {task.task_id: task for task in context.tasks}
    for unmatched in draft.unmatched:
        if any(task_id not in tasks for task_id in unmatched.candidate_task_ids):
            raise ValueError("unmatched candidate is outside the request snapshot")
    for change in draft.changes:
        task = tasks.get(change.task_id)
        if task is None or task.task_revision != change.task_revision:
            raise ValueError("task reference is outside the request snapshot")
        if change.before != task.progress:
            raise ValueError("before progress does not match request snapshot")
        if change.issues:
            continue
        candidate = change.candidate
        if candidate is None:
            raise ValueError("resolved proposal requires a candidate")
        candidate.check_for_total(task.planned_count)
        observation = change.reported_quantity
        if task.planned_count is not None and candidate.status == "partial" and observation is None:
            raise ValueError("quantified partial progress requires an observed quantity")
        if observation is not None:
            if (
                observation.meaning == "unclear"
                or observation.value is None
                or task.unit is None
                or observation.unit != task.unit
            ):
                raise ValueError("resolved proposal has an unusable quantity observation")
            expected_count = observation.value
            if observation.meaning == "increment":
                expected_count += task.progress.completed_count or 0
            if candidate.completed_count != expected_count:
                raise ValueError("candidate count disagrees with the observed quantity")
        remaining = None
        if task.planned_count is not None and candidate.completed_count is not None:
            remaining = task.planned_count - candidate.completed_count
        if change.remaining_count != remaining:
            raise ValueError("remaining_count disagrees with the normalized progress")


def check_text_draft(draft: FeedbackDraft, request: TextFeedbackRequest) -> None:
    check_draft_against_context(draft, request.context)
    entries = [*draft.changes, *draft.unmatched]
    if any(entry.evidence not in request.text for entry in entries):
        raise ValueError("evidence must be a verbatim fragment of the input text")


HttpErrorCode = Literal[
    "invalid_request",
    "unauthorized",
    "payload_too_large",
    "unsupported_media_type",
    "rate_limited",
    "budget_exhausted",
    "service_unavailable",
]


class HttpError(WireModel):
    code: HttpErrorCode
    attempt_id: Identifier | None = None


class EventBase(WireModel):
    attempt_id: Identifier
    seq: Revision


class StageEvent(EventBase):
    type: Literal["stage"]
    stage: Literal["received", "recognizing", "structuring", "validating"]


class ResultEvent(EventBase):
    type: Literal["result"]
    draft: FeedbackDraft


class ErrorEvent(EventBase):
    type: Literal["error"]
    code: Literal[
        "unusable_audio",
        "asr_failed",
        "provider_failed",
        "invalid_output",
        "processing_timeout",
        "internal_error",
    ]


FeedbackEvent = Annotated[StageEvent | ResultEvent | ErrorEvent, Field(discriminator="type")]


def check_complete_event_sequence(
    request: TextFeedbackRequest | AudioFeedbackContext,
    events: list[FeedbackEvent],
) -> None:
    """Validate a finite sequence of decoded events without handling transport."""
    stages = ["received", "structuring", "validating"]
    if isinstance(request, AudioFeedbackContext):
        stages.insert(1, "recognizing")
    stage_count = 0
    for seq, event in enumerate(events, 1):
        if event.seq != seq or event.attempt_id != request.context.ref.attempt_id:
            raise ValueError("invalid event sequence number or attempt ID")
        if isinstance(event, StageEvent):
            if stage_count >= len(stages) or event.stage != stages[stage_count]:
                raise ValueError("unexpected processing stage")
            stage_count += 1
            continue
        if seq != len(events) or stage_count == 0:
            raise ValueError("terminal event must follow stages and end the sequence")
        if isinstance(event, ResultEvent):
            if stage_count != len(stages):
                raise ValueError("result arrived before all processing stages")
            if isinstance(request, TextFeedbackRequest):
                check_text_draft(event.draft, request)
            else:
                check_draft_against_context(event.draft, request.context)
        return
    raise ValueError("event sequence ended without a result or error")
