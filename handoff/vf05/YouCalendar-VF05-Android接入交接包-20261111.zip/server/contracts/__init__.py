"""Versioned wire contracts shared with clients."""
