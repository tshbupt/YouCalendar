"""Export the feedback v1 payload schemas to stdout."""

import json

from pydantic import TypeAdapter
from pydantic.json_schema import DEFAULT_REF_TEMPLATE

from .feedback import AudioFeedbackContext, FeedbackEvent, HttpError, TextFeedbackRequest


def feedback_schema(*, ref_template: str = DEFAULT_REF_TEMPLATE) -> dict:
    payloads = {
        "text_request": TextFeedbackRequest,
        "audio_context": AudioFeedbackContext,
        "http_error": HttpError,
        "sse_event": FeedbackEvent,
    }
    roots, bundle = TypeAdapter.json_schemas(
        [(name, "validation", TypeAdapter(payload)) for name, payload in payloads.items()],
        title="YouCalendar feedback v1 wire payloads",
        ref_template=ref_template,
    )
    bundle["$defs"].update({name: roots[(name, "validation")] for name in payloads})
    return {"$schema": "https://json-schema.org/draft/2020-12/schema", **bundle}


if __name__ == "__main__":
    print(json.dumps(feedback_schema(), ensure_ascii=False, indent=2))
