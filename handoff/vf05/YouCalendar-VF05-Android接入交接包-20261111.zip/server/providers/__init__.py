"""Adapters for YouCalendar processing providers."""
