"""Async organizer boundary and a fixed, local demonstration adapter."""

import asyncio
import json
from typing import Protocol

from ..contracts.feedback import TextFeedbackRequest


class FeedbackProviderError(Exception):
    """Expected organizer failure, with details kept off the wire."""


class FeedbackOrganizer(Protocol):
    async def organize(self, request: TextFeedbackRequest) -> str:
        """Return one draft JSON object. Propagate cancellation to pending work."""


class DemoFeedbackOrganizer:
    """Recognize only the fixed phrases and task in the synthetic demo."""

    async def organize(self, request: TextFeedbackRequest) -> str:
        await asyncio.sleep(0.3)
        evidence = request.text.strip()
        task = next((task for task in request.context.tasks if task.task_id == "math_am"), None)
        draft = {
            "ref": request.context.ref.model_dump(mode="json"),
            "draft_revision": 1,
            "state": "needs_user_input",
            "changes": [],
            "unmatched": [],
            "date_needs_confirmation": False,
            "summary": None,
        }
        cases = {
            "上午高数一共做了12题。": ("total", 12, 12),
            "上午高数又做了4题。": ("increment", 4, 12),
            "上午高数做了12题。": ("unclear", 12, None),
            "上午高数打卡写错了，一共只做了6题。": ("total", 6, 6),
        }
        if (
            evidence not in cases or task is None or task.planned_count != 20
            or task.unit != "题" or task.progress.completed_count != 8
        ):
            draft["unmatched"] = [{"evidence": evidence[:1000], "candidate_task_ids": []}]
            return json.dumps(draft, ensure_ascii=False)

        meaning, reported, completed = cases[evidence]
        candidate = None
        if completed is not None:
            candidate = {"status": "partial", "completed_count": completed, "reason": None}
            draft["state"] = "ready_for_confirmation"
        draft["changes"] = [{
            "task_id": task.task_id,
            "task_revision": task.task_revision,
            "evidence": evidence,
            "before": task.progress.model_dump(mode="json"),
            "candidate": candidate,
            "reported_quantity": {"meaning": meaning, "value": reported, "unit": task.unit},
            "remaining_count": 20 - completed if completed is not None else None,
            "issues": ["quantity_meaning_unclear"] if completed is None else [],
        }]
        return json.dumps(draft, ensure_ascii=False)
