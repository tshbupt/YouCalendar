"""Read-only knowledge and stateless feedback API. Run with ``--no-access-log``."""

import os
from pathlib import Path
import secrets
from typing import Annotated, Any

from fastapi import Depends, FastAPI, HTTPException, Path as PathParameter
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer
from pydantic import BaseModel, ConfigDict, Field, StringConstraints

from .contracts.feedback_openapi import document_feedback_routes
from .feedback.text import DEFAULT_PROCESSING_TIMEOUT, text_feedback_router
from .knowledge.records import SearchQuery
from .knowledge.store import KnowledgeRuntime
from .providers.feedback import DemoFeedbackOrganizer, FeedbackOrganizer
from .speech.demo import DemoSpeechRecognizer
from .speech.recognizer import SpeechRecognizer
from .speech.route import audio_feedback_router


QueryText = Annotated[
    str, StringConstraints(strip_whitespace=True, min_length=1, max_length=500)
]
ScopeText = Annotated[
    str, StringConstraints(strip_whitespace=True, min_length=1, max_length=100)
]


class KnowledgeSearchRequest(BaseModel):
    model_config = ConfigDict(extra="forbid", strict=True)

    q: QueryText
    college: ScopeText | None = None
    subject: ScopeText | None = None
    stage: ScopeText | None = None
    exam_year: Annotated[int, Field(ge=2000, le=2100)] | None = None
    limit: Annotated[int, Field(ge=1, le=20)] = 5


def create_app(
    release_dir: Path | None = None,
    api_token: str | None = None,
    *,
    feedback_token: str | None = None,
    feedback_organizer: FeedbackOrganizer | None = None,
    feedback_timeout: float = DEFAULT_PROCESSING_TIMEOUT,
    speech_recognizer: SpeechRecognizer | None = None,
) -> FastAPI:
    """Load one immutable release; omitted arguments use environment settings.

    Missing or invalid configuration leaves the process available for health
    checks, but never enables anonymous knowledge retrieval.
    """
    if release_dir is None:
        configured_dir = os.environ.get("KNOWLEDGE_RELEASE_DIR", "").strip()
        release_dir = Path(configured_dir) if configured_dir else None
    token = os.environ.get("KNOWLEDGE_API_TOKEN") if api_token is None else api_token
    token = token if token and token.strip() else None

    runtime: KnowledgeRuntime | None = None
    if release_dir is not None:
        try:
            runtime = KnowledgeRuntime(Path(release_dir))
        except Exception:
            # Never expose the release path, SQL, or exception message to clients.
            runtime = None

    app = FastAPI(title="YouCalendar Knowledge API", version="0.1.0")
    if feedback_token is None:
        feedback_token = os.environ.get("FEEDBACK_API_TOKEN")
    if os.environ.get("FEEDBACK_MODE") == "demo":
        if feedback_organizer is None:
            feedback_organizer = DemoFeedbackOrganizer()
        if speech_recognizer is None:
            speech_recognizer = DemoSpeechRecognizer()
    app.include_router(text_feedback_router(feedback_token, feedback_organizer, feedback_timeout))
    app.include_router(audio_feedback_router(feedback_token, feedback_organizer, speech_recognizer, feedback_timeout))
    bearer = HTTPBearer(auto_error=False)

    def require_runtime(
        credentials: Annotated[
            HTTPAuthorizationCredentials | None, Depends(bearer)
        ],
    ) -> KnowledgeRuntime:
        if token is None:
            raise HTTPException(status_code=503, detail="Knowledge API is not configured")
        if credentials is None or not secrets.compare_digest(
            credentials.credentials.encode("utf-8"), token.encode("utf-8")
        ):
            raise HTTPException(
                status_code=401,
                detail="Invalid or missing bearer token",
                headers={"WWW-Authenticate": "Bearer"},
            )
        if runtime is None:
            raise HTTPException(status_code=503, detail="Knowledge release unavailable")
        return runtime

    @app.get("/health")
    def health() -> dict[str, str | None]:
        return {
            "status": "ready" if runtime is not None and token is not None else "unconfigured",
            "knowledge_version": runtime.knowledge_version if runtime is not None else None,
        }

    @app.post("/v1/knowledge/search")
    def search(
        request: KnowledgeSearchRequest,
        knowledge: Annotated[KnowledgeRuntime, Depends(require_runtime)],
    ) -> dict[str, Any]:
        query = SearchQuery(
            text=request.q,
            college=request.college,
            subject=request.subject,
            stage=request.stage,
            exam_year=request.exam_year,
            limit=request.limit,
        )
        try:
            query.validate()
            return knowledge.search(query)
        except Exception:
            raise HTTPException(
                status_code=503, detail="Knowledge retrieval unavailable"
            ) from None

    @app.get("/v1/knowledge/evidence/{evidence_id}")
    def evidence(
        evidence_id: Annotated[str, PathParameter(min_length=1, max_length=300)],
        knowledge: Annotated[KnowledgeRuntime, Depends(require_runtime)],
    ) -> dict[str, Any]:
        try:
            record = knowledge.get_evidence(evidence_id)
        except Exception:
            raise HTTPException(
                status_code=503, detail="Knowledge retrieval unavailable"
            ) from None
        if record is None:
            raise HTTPException(status_code=404, detail="Evidence not found")
        return record

    document_feedback_routes(app)
    return app


app = create_app()
