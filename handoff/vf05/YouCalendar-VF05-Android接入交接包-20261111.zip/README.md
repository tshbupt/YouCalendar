# YouCalendar 备考知识库与反馈服务

当前已有一个 Windows/CPU 可运行的最小版本：**GEO 分页正文导入 → 待审核证据 → 人工批准 → 版本化知识包 → 只读检索 HTTP 接口**。它是正式产品的知识基础切片，真实规划模型与 Android App 的接入仍待实现。

本机可独立演示文字和音频反馈，使用合成样例查看分阶段响应与结构化草稿。接手 Android Demo 时，从 [VF-05 接入与验收指南](docs/verification/vf05-android-handoff.md) 开始。 [接口契约](docs/contracts/feedback-v1.md) · [OpenAPI](docs/contracts/youcalendar.openapi.json)

## 先看哪些文件

- [本轮星标核验与复用结论](docs/research/创业工具星标-本轮核验与复用.md)：22 个星标的定位，以及 Docling、两个 Wiki 项目的实际接入条件。
- [构建、使用与维护方案](docs/designs/知识库两阶段方案-创业工具星标选型.md)：原有方案；文中“本轮仅调研”是当时快照，当前开发结果以下面的运行说明和验证记录为准。
- [CPU 轻量方案](docs/designs/考研备考知识库搭建方案-CPU轻量版.md)：资料、证据、策略、模板及 KB0～KB5。
- [首版开发验证记录](docs/verification/knowledge-mvp-20261026.md)：实际跑过什么，以及未完成什么。

## 运行条件与安装

本轮在 Windows 11、Python 3.12.14 验证。`requirements.lock.txt` 固定服务、构建和测试依赖。反馈演示只需要依赖安装与本机 HTTP，无需准备知识包或配置云服务密钥。

本机已建立 `.venv`。换电脑时，在项目根目录使用准备好的 Python 3.12 创建环境：

```powershell
py -3.12 -m venv .venv
& '.\.venv\Scripts\python.exe' -m pip install -r requirements.lock.txt
& '.\.venv\Scripts\python.exe' -m pip install --no-deps --no-build-isolation -e .
& '.\.venv\Scripts\python.exe' -m pip check
& '.\.venv\Scripts\python.exe' -X utf8 -m pytest -q
```

若 `py -3.12` 找不到已安装的 Python 3.12，用 `& 'C:\实际安装路径\python.exe' -m venv .venv` 创建环境，再执行后四条命令。

其他 Python/系统组合尚未验证。原始资料、作者数据库、发布包和令牌不应上传到公开代码仓库，已在 `.gitignore` 排除本地 `data/` 和环境配置。

## 启动文字反馈演示

在项目根目录的 PowerShell 窗口启动服务。为演示设置一个独立令牌，仅监听本机。

```powershell
$env:FEEDBACK_MODE = 'demo'
$env:FEEDBACK_API_TOKEN = '<自行设置的本地演示令牌>'
& '.\.venv\Scripts\python.exe' -m uvicorn server.api:app --host 127.0.0.1 --port 8000 --no-access-log
```

在第二个 PowerShell 窗口进入同一个项目目录，填入同一个令牌并发送合成样例。

```powershell
$feedbackDemoToken = '<与启动窗口相同的本地演示令牌>'
curl.exe --no-buffer --fail-with-body -H "Authorization: Bearer $feedbackDemoToken" -H 'Content-Type: application/json' --data-binary '@tests/fixtures/feedback/text-request.json' 'http://127.0.0.1:8000/v1/feedback/text'
```

样例依次输出 `received`、`structuring`、`validating` 和 `result`，候选累计完成 12 题，剩余 8 题。模拟器只识别合成样例中的固定句子和任务，其他内容返回待匹配。演示使用内存和合成文本，无供应商费用。

服务运行后，可通过 `GET /openapi.json` 查看两条反馈路由的请求、HTTP 错误及 SSE 事件结构。curl 和 Android 客户端通过 `POST` 读取流式响应。[接口契约](docs/contracts/feedback-v1.md)

文字反馈使用单独的令牌和启用开关，默认返回 503，启用后无须准备知识库。`/health` 继续显示知识服务状态。文字请求体上限为 1 MiB，模拟整理阶段超时为 15 秒。处理中的错误通过终止事件报告，客户端关闭连接时取消正在等待的整理。

VF-03 的 DeepSeek 适配器已完成固定合成集实测。修复后 12 条样例均通过。配置、结果和费用核算见 [VF-03 验证记录](docs/verification/vf03-deepseek-feedback.md)。

## 运行语音反馈本机演示

按上节启动 `FEEDBACK_MODE=demo` 服务，并在第二个 PowerShell 窗口使用相同的 `$feedbackDemoToken`。项目锁定依赖包含 `python-multipart`，首次使用新接口前可按安装说明同步依赖。

```powershell
New-Item -ItemType Directory -Path 'output' -Force | Out-Null
if (-not (Test-Path -LiteralPath 'output/vf04-demo.wav')) {
    & '.\.venv\Scripts\python.exe' -m server.speech.demo 'output/vf04-demo.wav'
}
curl.exe --no-buffer --fail-with-body -H "Authorization: Bearer $feedbackDemoToken" -F 'metadata=<tests/fixtures/feedback/audio-context.json;type=application/json' -F 'audio=@output/vf04-demo.wav;type=audio/wav' 'http://127.0.0.1:8000/v1/feedback/audio'
```

这个 WAV 是程序生成的测试信号。模拟识别器对该固定信号返回预设文本，接口依次输出 `received`、`recognizing`、`structuring`、`validating` 和 `result`，结果是累计 12 题、剩余 8 题。上传由服务端在内存中限额处理。 [音频本机验证和云端候选核验](docs/verification/vf04-local-audio.md)

腾讯云适配器已用六条本机合成语音完成实测。试验结果、费用和当前接入边界见 [腾讯云实测记录](docs/verification/vf04-tencent-asr.md)。

## 先跑知识库合成演示

```powershell
.\.venv\Scripts\python.exe -X utf8 -m server.knowledge.cli demo --workspace data/demo --version demo-v1
.\.venv\Scripts\python.exe -X utf8 -m server.knowledge.cli search --release data/demo/releases/demo-v1 --query 复习 --subject 演示科目
```

演示数据明确标为合成，自动批准仅限该条合成内容，不代表真实备考资料已经审核。已发布版本不会覆盖；重复演示请改用新的版本名。

## 导入已有 GEO 资料

`--source-root` 指向含 `采集任务清单.json`、`metadata/`、`pdf/`、`images/` 的归档目录，而不是最外层 GEO 文件夹：

```powershell
.\.venv\Scripts\python.exe -X utf8 -m server.knowledge.cli import-geo --source-root 'D:\GEO调研\北邮人论坛_通信考研归档' --database data/authoring.sqlite
.\.venv\Scripts\python.exe -X utf8 -m server.knowledge.cli stats --database data/authoring.sqlite
.\.venv\Scripts\python.exe -X utf8 -m server.knowledge.cli list --database data/authoring.sqlite --status draft --limit 3
```

导入器只选择清单中已归档验收通过的来源；复用 `extracted.posts` 与 `page_extracted`，不重跑 OCR。不导入 ZIP、QA 图、候选和排除目录，不执行源目录脚本，不修改原文件。

来源以版面＋主题 ID 标识，证据定位到论坛页与发言序号，不伪造 bbox。旧电脑绝对路径只用于取得文件名，再在当前归档白名单子目录内安全定位；无法证明身份、缺页、缺件、冲突页或坏 JSON 会隔离。采集清单损坏/没有已归档来源时不会撤回现有数据库。

真实原文全部进入 `draft`。相同资料再次导入不重复添加；来源变化后原审核失效，移出有效清单的论坛来源在下一版中停用。现有发布版本不会被修改。

## 人工审核与发布

先阅读证据及原页，核定内容、适用范围和年份，再由操作人员执行审批。发帖日期不能当成考试年度。以下是命令模板，不应不经核对批量执行：

```powershell
.\.venv\Scripts\python.exe -X utf8 -m server.knowledge.cli approve --database data/authoring.sqlite --evidence-id '<已核对的证据ID>' --college '<适用学院>' --subject '<适用科目>' --stage '<适用阶段>' --year 2027 --reviewer '<审核人>' --note '<原文、适用条件和使用范围审核说明>'
.\.venv\Scripts\python.exe -X utf8 -m server.knowledge.cli publish --database data/authoring.sqlite --releases-dir data/releases --version kb-20261026-v1
```

`2027` 仅示范参数写法，应替换为实际核定年度。明确属于一般方法时可用 `--any-year` 代替 `--year`；学院、科目、阶段的 `*` 是审核人明确选择的通用范围，未知值不会自动当通用。

没有已审核证据时禁止发布。发布包包括 `manifest.json`、`evidence.jsonl` 和 `search.sqlite`；记录 schema、知识版本、内容哈希、jieba 版本与实际字典哈希。运行端验证完整性后，以只读 SQLite 打开。哈希用于内容一致性核验，不等于外部来源真实或发布者已获信任。

## 启动只读接口

先在当前 PowerShell 设置合成演示版本和自行选择的本地测试令牌，再启动：

```powershell
$env:KNOWLEDGE_RELEASE_DIR = (Resolve-Path 'data/demo/releases/demo-v1').Path
$env:KNOWLEDGE_API_TOKEN = '<自行设置的本地测试令牌>'
.\.venv\Scripts\python.exe -m uvicorn server.api:app --host 127.0.0.1 --port 8000 --no-access-log
```

接口：

| 路径 | 用途 |
|---|---|
| `GET /health` | 就绪状态和知识版本，不返回源目录 |
| `POST /v1/knowledge/search` | 中文关键词检索，支持学院/科目/阶段/考试年度和条数过滤 |
| `GET /v1/knowledge/evidence/{evidence_id}` | 按 ID 读取当前版本的证据及来源 |

在另一个终端使用相同的本地测试令牌：

```powershell
$taskHeaders = @{ Authorization = 'Bearer <与启动终端相同的本地测试令牌>' }
$taskBody = @{ q = '复习'; subject = '演示科目'; limit = 5 } | ConvertTo-Json
Invoke-RestMethod -Uri 'http://127.0.0.1:8000/v1/knowledge/search' -Method Post -Headers $taskHeaders -ContentType 'application/json; charset=utf-8' -Body ([Text.Encoding]::UTF8.GetBytes($taskBody))
```

没有令牌或有效知识包时拒绝检索，错误响应不显示本机路径。知识检索运行时固定一个发布版本，不写查询历史。Uvicorn 按上例关闭访问日志。未来云端代理、限流、监控与部署仍须单独核验，当前服务只在本机运行。

## 哪些集中构建，哪些一直运行

| 工作 | 执行频率 | 当前状态 |
|---|---|---|
| 来源登记、正文/OCR、知识编译、人审 | 首批集中做；新资料或纠错后增量做 | GEO 正文导入、人审闸门已实现；OCR/编译模型未接入 |
| 文档索引、知识包 | 每个知识版本构建一次；新版本再发布 | SQLite 中文索引、哈希与版本包已实现 |
| 过滤、检索、来源返回 | 每次需要知识时执行 | 本地只读 HTTP 接口已实现 |
| 查询向量化、重排（若以后采用） | 每次查询仍可能执行，不属于纯一次性成本 | 未采用 |
| 计划生成、引用/数量/时间校验 | 每次生成计划时执行，学生确认后才保存 | 尚未接入，本轮未调用模型 |
| 年度更新、纠错、停用、回滚与评测 | 长期维护，按事件或版本执行 | 导入变化重审、撤回排除、版本包和启动时选版已有基础；自动切版/完整维护界面未实现 |

## 星标项目怎样复用

- Docling 属于构建端解析候选；已有正文足够的资料不必重复解析，缺失扫描页后续再接它的 CPU API。
- nvk/llm-wiki 适合作者环境的来源、schema、人审与修订协议；不需要把整个 Agent 或研究工作流部署给每次学生请求。
- SamurAI 的 query 脚本会记录问题，未直接接入线上；需要中立知识导出和只读接口。
- 当前运行代码复用 FastAPI、SQLite FTS5、jieba；只补现有项目没有提供的领域审核/发布/检索衔接，没有复制上游源码或声称已安装 Docling/Wiki。

下一步应先审核少量真实证据，再提炼策略卡和任务模板，之后接模型生成和硬约束校验。不得把这版原文检索当成备考知识质量或完整规划能力已通过。
