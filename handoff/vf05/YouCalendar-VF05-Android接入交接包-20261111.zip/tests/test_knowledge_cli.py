import json

from server.knowledge.cli import main
from server.knowledge.records import Evidence
from server.knowledge.store import AuthoringStore


def test_demo_is_labeled_and_retrieval_is_reproducible(tmp_path, capsys):
    assert main(["demo", "--workspace", str(tmp_path / "demo"), "--version", "v1"]) == 0
    output = json.loads(capsys.readouterr().out)
    assert output["synthetic_demo_only"] is True
    assert output["search"]["results"][0]["source_type"] == "synthetic_demo"
    assert main(["search", "--release", output["release_dir"], "--query", "复习"]) == 0
    assert json.loads(capsys.readouterr().out)["results"]


def test_damaged_manifest_cannot_create_or_retract_database(tmp_path, capsys):
    archive = tmp_path / "archive"
    archive.mkdir()
    (archive / "采集任务清单.json").write_text("damaged", encoding="utf-8")
    database = tmp_path / "author.sqlite"
    assert main(["import-geo", "--source-root", str(archive), "--database", str(database)]) == 2
    assert not database.exists()
    capsys.readouterr()
    store = AuthoringStore(database)
    item = Evidence(evidence_id="forum:test:1:p1:post1", source_id="forum:test:1", title="示例", text="原文",
                    source_url="https://example.test/source", locator={"level": "article"}, source_hash="a" * 64)
    store.upsert_source(item.source_id, [item])
    before = database.read_bytes()
    assert main(["import-geo", "--source-root", str(archive), "--database", str(database)]) == 2
    assert database.read_bytes() == before
    assert json.loads(capsys.readouterr().out)["existing_database_unchanged"] is True


def test_empty_manifest_cannot_silently_retract_everything(tmp_path, capsys):
    (tmp_path / "采集任务清单.json").write_text("[]", encoding="utf-8")
    database = tmp_path / "author.sqlite"
    assert main(["import-geo", "--source-root", str(tmp_path), "--database", str(database)]) == 2
    assert not database.exists()
    assert json.loads(capsys.readouterr().out)["existing_database_unchanged"] is True


def test_stats_on_wrong_path_does_not_create_an_empty_database(tmp_path):
    database = tmp_path / "wrong.sqlite"
    assert main(["stats", "--database", str(database)]) == 1
    assert not database.exists()
