"""API adapter tests; fake-runtime tests do not claim document-to-API coverage."""

from __future__ import annotations

import logging
import hashlib
from pathlib import Path

from fastapi.testclient import TestClient
import pytest

from server import api
from server.knowledge.records import Evidence
from server.knowledge.store import AuthoringStore


TOKEN = "test-token-only"
HEADERS = {"Authorization": f"Bearer {TOKEN}"}
EVIDENCE = {
    "evidence_id": "ev_reviewed_example",
    "source_id": "source_example",
    "title": "复习顺序",
    "text": "基础阶段先完成课本例题，再复盘错题。",
    "source_url": "https://example.org/source",
    "locator": {"page": 2},
    "review_status": "approved",
}


class FakeRuntime:
    """A narrow adapter fixture, not a substitute for the SQLite runtime."""

    knowledge_version = "test-release-1"

    def __init__(self, release_dir: Path):
        self.release_dir = release_dir
        self.queries = []
        self.evidence_queries = []

    def search(self, query):
        self.queries.append(query)
        return {
            "schema_version": 1,
            "knowledge_version": self.knowledge_version,
            "results": [dict(EVIDENCE)],
        }

    def get_evidence(self, evidence_id):
        self.evidence_queries.append(evidence_id)
        return dict(EVIDENCE) if evidence_id == EVIDENCE["evidence_id"] else None


@pytest.fixture(autouse=True)
def no_inherited_configuration(monkeypatch):
    monkeypatch.delenv("KNOWLEDGE_RELEASE_DIR", raising=False)
    monkeypatch.delenv("KNOWLEDGE_API_TOKEN", raising=False)


@pytest.fixture
def ready_client(monkeypatch, tmp_path):
    runtimes = []

    def build_runtime(path):
        instance = FakeRuntime(path)
        runtimes.append(instance)
        return instance

    monkeypatch.setattr(api, "KnowledgeRuntime", build_runtime)
    with TestClient(api.create_app(tmp_path, TOKEN)) as client:
        yield client, runtimes[0]


def test_health_reports_version_without_path_or_authentication(ready_client, tmp_path):
    client, _ = ready_client
    response = client.get("/health")
    assert response.status_code == 200
    assert response.json() == {
        "status": "ready", "knowledge_version": "test-release-1"
    }
    assert str(tmp_path) not in response.text


@pytest.mark.parametrize("header", [None, "Bearer wrong", "Basic test-token-only", "Bearer", "Bearer 中文"])
def test_search_rejects_missing_or_invalid_token(ready_client, header):
    client, runtime = ready_client
    headers = {"Authorization": header} if header else {}
    # HTTP headers are Latin-1 encoded; bytes exercise non-ASCII credentials too.
    if header == "Bearer 中文":
        headers = {b"Authorization": "Bearer 中文".encode("utf-8")}
    response = client.post("/v1/knowledge/search", json={"q": "复习"}, headers=headers)
    assert response.status_code == 401
    assert response.headers["www-authenticate"] == "Bearer"
    assert runtime.queries == []


def test_evidence_endpoint_requires_authentication(ready_client):
    client, runtime = ready_client
    response = client.get(f"/v1/knowledge/evidence/{EVIDENCE['evidence_id']}")
    assert response.status_code == 401
    assert runtime.evidence_queries == []


@pytest.mark.parametrize("token", [None, "", "   "])
def test_no_configured_token_fails_closed(monkeypatch, tmp_path, token):
    monkeypatch.setattr(api, "KnowledgeRuntime", FakeRuntime)
    with TestClient(api.create_app(tmp_path, token)) as client:
        assert client.get("/health").json()["status"] == "unconfigured"
        response = client.post("/v1/knowledge/search", json={"q": "复习"}, headers=HEADERS)
        assert response.status_code == 503
        assert client.get("/v1/knowledge/evidence/ev_example", headers=HEADERS).status_code == 503


def test_environment_configuration(monkeypatch, tmp_path):
    monkeypatch.setenv("KNOWLEDGE_RELEASE_DIR", str(tmp_path))
    monkeypatch.setenv("KNOWLEDGE_API_TOKEN", TOKEN)
    monkeypatch.setattr(api, "KnowledgeRuntime", FakeRuntime)
    with TestClient(api.create_app()) as client:
        assert client.get("/health").json()["status"] == "ready"
        assert client.post("/v1/knowledge/search", json={"q": "复习"}, headers=HEADERS).status_code == 200


def test_explicit_empty_token_does_not_fall_back_to_environment(monkeypatch, tmp_path):
    monkeypatch.setenv("KNOWLEDGE_API_TOKEN", TOKEN)
    monkeypatch.setattr(api, "KnowledgeRuntime", FakeRuntime)
    with TestClient(api.create_app(tmp_path, "")) as client:
        assert client.post("/v1/knowledge/search", json={"q": "复习"}, headers=HEADERS).status_code == 503


def test_unconfigured_release_returns_generic_unavailability():
    with TestClient(api.create_app(api_token=TOKEN)) as client:
        assert client.get("/health").json() == {"status": "unconfigured", "knowledge_version": None}
        response = client.post("/v1/knowledge/search", json={"q": "复习"}, headers=HEADERS)
        assert response.status_code == 503


def test_invalid_release_hides_internal_details(monkeypatch, tmp_path):
    secret_message = f"invalid SQLite file {tmp_path / 'private.sqlite'}"

    def broken_runtime(path):
        raise ValueError(secret_message)

    monkeypatch.setattr(api, "KnowledgeRuntime", broken_runtime)
    with TestClient(api.create_app(tmp_path, TOKEN)) as client:
        assert client.get("/health").json() == {"status": "unconfigured", "knowledge_version": None}
        response = client.post("/v1/knowledge/search", json={"q": "复习"}, headers=HEADERS)
        assert response.status_code == 503
        assert secret_message not in response.text
        assert str(tmp_path) not in response.text


def test_search_maps_all_supported_filters(ready_client):
    client, runtime = ready_client
    response = client.post(
        "/v1/knowledge/search",
        json={"q": "  复习顺序  ", "college": "信通院", "subject": "通信原理", "stage": "基础", "exam_year": 2027, "limit": 3},
        headers=HEADERS,
    )
    assert response.status_code == 200
    assert response.json()["knowledge_version"] == "test-release-1"
    assert response.json()["results"][0] == EVIDENCE
    query = runtime.queries[0]
    assert (query.text, query.college, query.subject, query.stage, query.exam_year, query.limit) == (
        "复习顺序", "信通院", "通信原理", "基础", 2027, 3,
    )


@pytest.mark.parametrize("payload", [
    {}, {"q": ""}, {"q": "   "}, {"q": "x" * 501}, {"q": 123},
    {"q": "复习", "college": ""}, {"q": "复习", "subject": " "},
    {"q": "复习", "stage": "x" * 101},
    {"q": "复习", "exam_year": 1999}, {"q": "复习", "exam_year": 2101},
    {"q": "复习", "exam_year": "2027"}, {"q": "复习", "limit": True},
    {"q": "复习", "limit": 0}, {"q": "复习", "limit": 21},
    {"q": "复习", "student_record": "must not be accepted"},
])
def test_invalid_requests_do_not_reach_runtime(ready_client, payload):
    client, runtime = ready_client
    response = client.post("/v1/knowledge/search", json=payload, headers=HEADERS)
    assert response.status_code == 422
    assert runtime.queries == []


def test_evidence_lookup_and_missing_record(ready_client):
    client, runtime = ready_client
    response = client.get(f"/v1/knowledge/evidence/{EVIDENCE['evidence_id']}", headers=HEADERS)
    assert response.status_code == 200
    assert response.json() == EVIDENCE
    assert client.get("/v1/knowledge/evidence/missing", headers=HEADERS).status_code == 404
    assert runtime.evidence_queries == [EVIDENCE["evidence_id"], "missing"]


@pytest.mark.parametrize("endpoint", ["search", "evidence"])
def test_runtime_errors_are_sanitized(ready_client, monkeypatch, endpoint):
    client, runtime = ready_client
    secret_message = "private query and C:/private/data.sqlite"

    def fail(*args):
        raise RuntimeError(secret_message)

    if endpoint == "search":
        monkeypatch.setattr(runtime, "search", fail)
        response = client.post("/v1/knowledge/search", json={"q": "复习"}, headers=HEADERS)
    else:
        monkeypatch.setattr(runtime, "get_evidence", fail)
        response = client.get("/v1/knowledge/evidence/ev_example", headers=HEADERS)
    assert response.status_code == 503
    assert secret_message not in response.text


def test_no_mutation_or_file_endpoints(ready_client):
    client, _ = ready_client
    assert client.post("/v1/knowledge/upload", headers=HEADERS).status_code == 404
    assert client.put("/v1/knowledge/evidence/ev_example", json={}, headers=HEADERS).status_code == 405
    assert client.delete("/v1/knowledge/evidence/ev_example", headers=HEADERS).status_code == 405
    assert client.get("/files/private.sqlite", headers=HEADERS).status_code == 404


def test_search_does_not_write_files_or_log_query(ready_client, tmp_path, caplog):
    client, _ = ready_client
    private_query = "PRIVATE_STUDENT_INPUT_8f034"
    before = sorted(str(path.relative_to(tmp_path)) for path in tmp_path.rglob("*"))
    with caplog.at_level(logging.DEBUG):
        response = client.post("/v1/knowledge/search", json={"q": private_query}, headers=HEADERS)
    after = sorted(str(path.relative_to(tmp_path)) for path in tmp_path.rglob("*"))
    assert response.status_code == 200
    assert before == after
    assert private_query not in caplog.text
    assert TOKEN not in caplog.text


def test_actual_reviewed_release_to_http_api_is_read_only(tmp_path, caplog):
    """Real authoring, publication, SQLite retrieval and ASGI HTTP integration.

    These synthetic records exercise infrastructure; they are not approved
    guidance for real students or evidence of planning/model quality.
    """
    store = AuthoringStore(tmp_path / "author.sqlite")
    common = {
        "source_id": "synthetic_source",
        "title": "通信原理复习",
        "text": "基础阶段先完成通信原理课本例题，再整理错题。",
        "source_url": "https://example.test/source",
        "source_hash": "a" * 64,
        "locator": {"level": "article"},
    }
    store.upsert_source("synthetic_source", [
        Evidence(evidence_id="ev_approved_2027", **common),
        Evidence(evidence_id="ev_approved_2026", **common),
        Evidence(evidence_id="ev_unreviewed", **common),
    ])
    for evidence_id, year in [("ev_approved_2027", 2027), ("ev_approved_2026", 2026)]:
        store.approve(
            evidence_id, college="信通院", subject="通信原理", stage="基础",
            exam_year=year, any_year=False, reviewer="test", note="synthetic fixture",
        )
    release = store.publish(tmp_path / "releases", "test-v1")

    def release_hashes():
        return {
            str(path.relative_to(release)): hashlib.sha256(path.read_bytes()).hexdigest()
            for path in release.rglob("*") if path.is_file()
        }

    before = release_hashes()
    private_query = "PRIVATE_STUDENT_INPUT_66d50"
    with caplog.at_level(logging.DEBUG), TestClient(api.create_app(release, TOKEN)) as client:
        assert client.get("/health").json() == {"status": "ready", "knowledge_version": "test-v1"}
        response = client.post(
            "/v1/knowledge/search",
            json={"q": "通信原理", "college": "信通院", "subject": "通信原理", "stage": "基础", "exam_year": 2027},
            headers=HEADERS,
        )
        assert response.status_code == 200
        result = response.json()
        assert result["schema_version"] == 1
        assert result["knowledge_version"] == "test-v1"
        assert [record["evidence_id"] for record in result["results"]] == ["ev_approved_2027"]
        assert result["results"][0]["source_url"] == common["source_url"]
        assert result["results"][0]["locator"] == {"level": "article"}
        assert result["results"][0]["review_status"] == "approved"

        evidence = client.get("/v1/knowledge/evidence/ev_approved_2027", headers=HEADERS)
        assert evidence.status_code == 200
        assert evidence.json()["text"] == common["text"]
        assert client.get("/v1/knowledge/evidence/ev_unreviewed", headers=HEADERS).status_code == 404

        wrong_scope = client.post(
            "/v1/knowledge/search", json={"q": "通信原理", "subject": "数学"}, headers=HEADERS
        )
        assert wrong_scope.status_code == 200
        assert wrong_scope.json()["results"] == []
        assert client.post(
            "/v1/knowledge/search", json={"q": private_query}, headers=HEADERS
        ).status_code == 200

        # An arbitrary identifier is a bound database lookup, never a filename.
        assert client.get("/v1/knowledge/evidence/search.sqlite", headers=HEADERS).status_code == 404

    assert release_hashes() == before
    assert private_query not in caplog.text
    assert TOKEN not in caplog.text
    for path in release.rglob("*"):
        if path.is_file():
            assert private_query.encode("utf-8") not in path.read_bytes()
