from dataclasses import replace
import hashlib
from pathlib import Path

import pytest

from server.knowledge.records import Evidence, SearchQuery
from server.knowledge.store import AuthoringStore, KnowledgeRuntime


def record(source="forum:test:1", text="复习通信原理时记录已经完成的数量"):
    return Evidence(
        evidence_id=source + ":p1:post1", source_id=source, title="通信原理复习", text=text,
        source_url="https://example.test/source", locator={"level": "forum_page", "forum_page": 1},
        source_hash=hashlib.sha256(text.encode()).hexdigest(),
    )


def approve(store, item, **changes):
    args = dict(college="信通院", subject="通信原理", stage="基础", exam_year=2027,
                any_year=False, reviewer="test", note="synthetic review")
    args.update(changes)
    return store.approve(item.evidence_id, **args)


def test_draft_is_not_publishable_and_scope_is_not_inferred(tmp_path):
    store = AuthoringStore(tmp_path / "author.sqlite")
    item = record()
    store.upsert_source(item.source_id, [item])
    with pytest.raises(ValueError, match="nothing approved"):
        store.publish(tmp_path / "releases", "v1")
    assert store.get(item.evidence_id).exam_year is None
    with pytest.raises(ValueError):
        approve(store, item, subject="")
    assert store.get(item.evidence_id).review_status == "draft"


def test_identical_import_preserves_review_changed_content_revokes_it(tmp_path):
    store = AuthoringStore(tmp_path / "author.sqlite")
    item = record()
    store.upsert_source(item.source_id, [item])
    approve(store, item)
    assert store.upsert_source(item.source_id, [item])["unchanged"] == 1
    assert store.get(item.evidence_id).review_status == "approved"
    changed = record(text="复习通信原理时先检查新的资源版本")
    store.upsert_source(item.source_id, [changed])
    assert store.get(item.evidence_id).review_status == "draft"
    assert not store.get(item.evidence_id).review


def test_withdrawal_does_not_disable_other_source_types_and_reactivation_needs_review(tmp_path):
    store = AuthoringStore(tmp_path / "author.sqlite")
    item, expert = record(), record("expert:1")
    for value in (item, expert):
        store.upsert_source(value.source_id, [value])
        approve(store, value)
    store.sync_active_sources(set())
    assert store.get(item.evidence_id).review_status == "disabled"
    assert store.get(expert.evidence_id).review_status == "approved"
    store.upsert_source(item.source_id, [item])
    assert store.get(item.evidence_id).review_status == "draft"


def test_source_error_quarantines_previous_review(tmp_path):
    store = AuthoringStore(tmp_path / "author.sqlite")
    item = record()
    store.upsert_source(item.source_id, [item])
    approve(store, item)
    store.quarantine_source(item.source_id)
    assert store.get(item.evidence_id).review_status == "draft"


def test_release_filters_scope_and_year_and_queries_cannot_write(tmp_path):
    store = AuthoringStore(tmp_path / "author.sqlite")
    item = record()
    store.upsert_source(item.source_id, [item])
    approve(store, item)
    release = store.publish(tmp_path / "releases", "v1")
    before = {p.name: p.read_bytes() for p in release.iterdir()}
    runtime = KnowledgeRuntime(release)
    hit = runtime.search(SearchQuery("通信复习", college="信通院", subject="通信原理", stage="基础", exam_year=2027))
    assert hit["knowledge_version"] == "v1"
    assert hit["results"][0]["evidence_id"] == item.evidence_id
    for query in (SearchQuery("通信", college="电子院"), SearchQuery("通信", subject="英语"),
                  SearchQuery("通信", stage="冲刺"), SearchQuery("通信", exam_year=2028)):
        assert runtime.search(query)["results"] == []
    assert runtime.search(SearchQuery('" OR *; DROP TABLE evidence; --'))["knowledge_version"] == "v1"
    assert {p.name: p.read_bytes() for p in release.iterdir()} == before
    with runtime._connection() as connection:
        with pytest.raises(Exception, match="readonly"):
            connection.execute("DELETE FROM evidence")


def test_explicit_general_scope_and_year_can_be_retrieved(tmp_path):
    store = AuthoringStore(tmp_path / "author.sqlite")
    item = record()
    store.upsert_source(item.source_id, [item])
    approve(store, item, college="*", subject="*", stage="*", exam_year=None, any_year=True)
    runtime = KnowledgeRuntime(store.publish(tmp_path / "releases", "general-v1"))
    assert runtime.search(SearchQuery("复习", subject="英语", exam_year=2028))["results"]


def test_tampered_partial_or_duplicate_release_is_rejected(tmp_path):
    store = AuthoringStore(tmp_path / "author.sqlite")
    item = record()
    store.upsert_source(item.source_id, [item])
    approve(store, item)
    release = store.publish(tmp_path / "releases", "v1")
    with pytest.raises(FileExistsError):
        store.publish(tmp_path / "releases", "v1")
    with pytest.raises(ValueError):
        store.publish(tmp_path / "releases", "../escape")
    with (release / "evidence.jsonl").open("a", encoding="utf-8") as stream:
        stream.write("tampered")
    with pytest.raises(ValueError, match="hash"):
        KnowledgeRuntime(release)
    partial = tmp_path / "partial"
    partial.mkdir()
    with pytest.raises(FileNotFoundError):
        KnowledgeRuntime(partial)


def test_old_release_remains_pinned_after_source_change(tmp_path):
    store = AuthoringStore(tmp_path / "author.sqlite")
    item = record()
    store.upsert_source(item.source_id, [item])
    approve(store, item)
    runtime = KnowledgeRuntime(store.publish(tmp_path / "releases", "v1"))
    changed = record(text="新的复习方法改变了具体条件")
    store.upsert_source(item.source_id, [changed])
    assert runtime.get_evidence(item.evidence_id)["text"] == item.text
    with pytest.raises(ValueError, match="nothing approved"):
        store.publish(tmp_path / "releases", "v2")


def test_cross_source_identity_collision_cannot_overwrite_evidence(tmp_path):
    store = AuthoringStore(tmp_path / "author.sqlite")
    item = record()
    store.upsert_source(item.source_id, [item])
    impostor = replace(item, source_id="expert:other")
    with pytest.raises(ValueError, match="another source"):
        store.upsert_source(impostor.source_id, [impostor])
    assert store.get(item.evidence_id).source_id == item.source_id


def test_dictionary_fingerprint_is_part_of_runtime_compatibility(tmp_path, monkeypatch):
    import server.knowledge.store as module
    store = AuthoringStore(tmp_path / "author.sqlite")
    item = record()
    store.upsert_source(item.source_id, [item])
    approve(store, item)
    release = store.publish(tmp_path / "releases", "v1")
    original = module._tokenizer_config
    monkeypatch.setattr(module, "_tokenizer_config", lambda: {**original(), "dictionary_sha256": "f" * 64})
    with pytest.raises(ValueError, match="tokenizer"):
        KnowledgeRuntime(release)


def test_concurrent_source_imports_cannot_claim_the_same_evidence_id(tmp_path):
    from concurrent.futures import ThreadPoolExecutor
    from threading import Barrier
    store = AuthoringStore(tmp_path / "author.sqlite")
    original = record()
    competitor = replace(original, source_id="expert:competitor")
    ready = Barrier(2)

    def attempt(item):
        ready.wait(timeout=5)
        try:
            store.upsert_source(item.source_id, [item])
            return "accepted"
        except ValueError:
            return "rejected"

    with ThreadPoolExecutor(max_workers=2) as executor:
        results = list(executor.map(attempt, (original, competitor)))
    assert sorted(results) == ["accepted", "rejected"]
    assert store.get(original.evidence_id).source_id in {original.source_id, competitor.source_id}
    assert store.stats()["evidence_count"] == 1
