from __future__ import annotations

import copy
import hashlib
import json
from pathlib import Path

import pytest

from server.knowledge.importers import ARCHIVED_STATUS, load_geo_archive


def _write_json(path: Path, value: object) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, ensure_ascii=False), encoding="utf-8")


@pytest.fixture
def geo_archive(tmp_path: Path) -> tuple[Path, dict, dict]:
    root = tmp_path / "archive"
    for directory in ("metadata", "images", "pdf"):
        (root / directory).mkdir(parents=True)
    item = {
        "board": "AimGraduate", "id": "12345", "title": "合成备考资料",
        "url": "https://bbs.byr.cn/#!article/AimGraduate/12345",
        "published": "2024-03-12", "status": ARCHIVED_STATUS,
        "archive_manifest": "001_12345.json",
    }
    metadata = {
        "id": "12345", "url": item["url"], "title": item["title"],
        "published_date": "2024-03-12", "file_stem": "synthetic_12345",
        "expected_forum_pages": 2,
        "extracted": {
            "posts": [{"text": "每日20题，基础薄弱时先完成12题。\n[FROM: 127.0.0.*]"}],
            "pages": [{"url": "https://bbs.byr.cn/n/article/AimGraduate/12345?p=2", "text": "这只是分页链接"}],
        },
        "page_extracted": [{
            "page_no": 2,
            "url": "https://bbs.byr.cn/n/article/AimGraduate/12345?p=2",
            "posts": [{"text": "<script>never_execute()</script> 数量、条件应保留。"}, {"text": "另一个人的独立回复。"}],
        }],
        "pages": [
            {"page_no": 1, "capture_complete": True, "full_image": "images/synthetic_12345_p01_full.jpg"},
            {"page_no": 2, "capture_complete": True, "full_image": "images/synthetic_12345_p02_full.jpg"},
        ],
    }
    (root / "pdf" / "synthetic_12345.pdf").write_bytes(b"synthetic PDF fixture; not a PDF parser input")
    for number in (1, 2):
        (root / "images" / f"synthetic_12345_p{number:02}_full.jpg").write_bytes(b"synthetic image fixture")
    _save(root, item, metadata)
    return root, item, metadata


def _save(root: Path, item: dict, metadata: dict) -> None:
    _write_json(root / "采集任务清单.json", [item])
    _write_json(root / "metadata" / "001_12345.json", metadata)


def _codes(batch) -> set[str]:
    return {error["code"] for error in batch.errors}


def test_imports_posts_with_stable_locators_and_draft_only(geo_archive):
    root, _, _ = geo_archive
    batch = load_geo_archive(root)
    assert batch.errors == []
    assert batch.active_source_ids == {"forum:AimGraduate:12345"}
    records = batch.sources["forum:AimGraduate:12345"]
    assert len(records) == 3
    assert [record.evidence_id for record in records] == [
        "forum:AimGraduate:12345:p1:post1", "forum:AimGraduate:12345:p2:post1", "forum:AimGraduate:12345:p2:post2",
    ]
    assert "每日20题" in records[0].text and "先完成12题" in records[0].text
    assert "[FROM:" not in records[0].text
    assert records[1].text.startswith("<script>")  # Data remains data.
    assert records[1].locator == {
        "level": "forum_page", "forum_page": 2, "post_index": 1,
        "metadata_file": "metadata/001_12345.json", "image_file": "images/synthetic_12345_p02_full.jpg",
    }
    assert all(record.review_status == "draft" and record.exam_year is None for record in records)
    assert all(record.source_type == "forum_discussion" for record in records)
    assert records[0].published_date == "2024-03-12"
    assert records[0].source_hash == hashlib.sha256((root / "metadata" / "001_12345.json").read_bytes()).hexdigest()
    assert batch.counts == {"active_sources": 1, "imported_sources": 1, "evidence": 3, "errors": 0}


def test_same_source_duplicate_manifest_item_is_imported_once(geo_archive):
    root, item, _ = geo_archive
    _write_json(root / "采集任务清单.json", [item, copy.deepcopy(item)])
    assert load_geo_archive(root).counts["evidence"] == 3


def test_excluded_and_pending_sources_and_side_directories_are_not_imported(geo_archive):
    root, item, _ = geo_archive
    excluded = dict(item, id="999", url="https://bbs.byr.cn/n/article/AimGraduate/999", status="排除")
    pending = dict(item, id="998", url="https://bbs.byr.cn/n/article/AimGraduate/998", status="待采集")
    _write_json(root / "采集任务清单.json", [item, excluded, pending])
    for directory in ("qa", "excluded_metadata", "metadata_history"):
        _write_json(root / directory / "bad.json", {"posts": ["must not read"]})
    (root / "archive.zip").write_bytes(b"must not import")
    batch = load_geo_archive(root)
    assert batch.errors == []
    assert batch.active_source_ids == {"forum:AimGraduate:12345"}


def test_missing_manifest_reference_uses_identity_index(geo_archive):
    root, item, metadata = geo_archive
    item.pop("archive_manifest")
    _save(root, item, metadata)
    assert load_geo_archive(root).counts["evidence"] == 3


def test_ambiguous_metadata_and_conflicting_identity_are_quarantined(geo_archive):
    root, item, metadata = geo_archive
    item.pop("archive_manifest")
    _save(root, item, metadata)
    _write_json(root / "metadata" / "duplicate.json", metadata)
    batch = load_geo_archive(root)
    assert batch.sources == {}
    assert "AMBIGUOUS_METADATA" in _codes(batch)
    assert batch.active_source_ids == {"forum:AimGraduate:12345"}
    item["archive_manifest"] = "001_12345.json"
    metadata["id"] = "67890"
    metadata["url"] = "https://bbs.byr.cn/n/article/AimGraduate/67890"
    _save(root, item, metadata)
    assert "SOURCE_ID_CONFLICT" in _codes(load_geo_archive(root))


def test_old_machine_absolute_paths_relocate_only_to_archive_whitelist(geo_archive):
    root, item, metadata = geo_archive
    item["archive_manifest"] = r"C:\old\archive\metadata\001_12345.json"
    metadata["pages"][0]["full_image"] = r"E:\old\images\synthetic_12345_p01_full.jpg"
    metadata["pages"][1]["full_image"] = "/old/archive/images/synthetic_12345_p02_full.jpg"
    metadata["pdf_path"] = r"E:\old\pdf\synthetic_12345.pdf"
    _save(root, item, metadata)
    assert load_geo_archive(root).counts["evidence"] == 3


@pytest.mark.parametrize("reference", ["../outside.json", "metadata/../outside.json", "../../archive/metadata/001_12345.json"])
def test_relative_path_traversal_is_rejected(geo_archive, reference):
    root, item, metadata = geo_archive
    item["archive_manifest"] = reference
    _save(root, item, metadata)
    batch = load_geo_archive(root)
    assert batch.sources == {}
    assert "PATH_OUTSIDE_ROOT" in _codes(batch)
    assert batch.active_source_ids == {"forum:AimGraduate:12345"}


def test_image_source_and_page_must_match(geo_archive):
    root, item, metadata = geo_archive
    metadata["pages"][0]["full_image"] = "images/synthetic_12345_p02_full.jpg"
    _save(root, item, metadata)
    assert "ASSET_ID_CONFLICT" in _codes(load_geo_archive(root))


@pytest.mark.parametrize("mutation,code", [
    (lambda m: m["page_extracted"].clear(), "MISSING_BODY_PAGE"),
    (lambda m: m["page_extracted"][0].update(page_no=1, url="https://bbs.byr.cn/n/article/AimGraduate/12345"), "DUPLICATE_PAGE"),
    (lambda m: m["page_extracted"][0].update(page_no=0), "INVALID_PAGE"),
    (lambda m: m["page_extracted"][0].update(page_no=3), "PAGE_CONFLICT"),
    (lambda m: m["extracted"].pop("posts"), "MISSING_BODY"),
    (lambda m: m["extracted"]["posts"][0].update(text="   "), "EMPTY_POST"),
    (lambda m: m["pages"].pop(), "PAGE_COVERAGE_MISMATCH"),
])
def test_invalid_source_is_atomic_and_active_id_retained(geo_archive, mutation, code):
    root, item, metadata = geo_archive
    mutation(metadata)
    _save(root, item, metadata)
    batch = load_geo_archive(root)
    assert batch.sources == {}
    assert batch.active_source_ids == {"forum:AimGraduate:12345"}
    assert code in _codes(batch)
    assert "每日20题" not in json.dumps(batch.errors, ensure_ascii=False)


def test_additional_page_number_can_come_from_url(geo_archive):
    root, item, metadata = geo_archive
    metadata["page_extracted"][0].pop("page_no")
    _save(root, item, metadata)
    assert load_geo_archive(root).counts["evidence"] == 3


def test_old_archive_exact_first_page_duplicate_is_not_counted_twice(geo_archive):
    root, item, metadata = geo_archive
    metadata["extracted"]["url"] = item["url"]
    metadata["page_extracted"].insert(0, copy.deepcopy(metadata["extracted"]))
    _save(root, item, metadata)
    assert load_geo_archive(root).counts["evidence"] == 3


def test_unknown_page_without_page_number_is_not_guessed_by_array_order(geo_archive):
    root, item, metadata = geo_archive
    metadata["page_extracted"][0].pop("page_no")
    metadata["page_extracted"][0]["url"] = item["url"]
    _save(root, item, metadata)
    assert "MISSING_PAGE_NUMBER" in _codes(load_geo_archive(root))


def test_manifest_url_cannot_point_to_unrelated_host(geo_archive):
    root, item, metadata = geo_archive
    item["url"] = "https://unrelated.invalid/AimGraduate/12345"
    _save(root, item, metadata)
    batch = load_geo_archive(root)
    assert "INVALID_SOURCE_URL" in _codes(batch)
    assert batch.active_source_ids == {"forum:AimGraduate:12345"}
    assert batch.errors[0]["source_id"] == "forum:AimGraduate:12345"


def test_manifest_and_metadata_symlink_cannot_escape_archive(geo_archive, tmp_path):
    root, item, _ = geo_archive
    external = tmp_path / "outside.json"
    external.write_text("{}", encoding="utf-8")
    link = root / "metadata" / "escape.json"
    try:
        link.symlink_to(external)
    except OSError:
        pytest.skip("Creating symbolic links is unavailable in this test environment")
    item["archive_manifest"] = "escape.json"
    _write_json(root / "采集任务清单.json", [item])
    assert "PATH_OUTSIDE_ROOT" in _codes(load_geo_archive(root))


@pytest.mark.parametrize("missing", ["metadata/001_12345.json", "pdf/synthetic_12345.pdf", "images/synthetic_12345_p02_full.jpg"])
def test_missing_required_assets_are_reported(geo_archive, missing):
    root, _, _ = geo_archive
    (root / missing).unlink()
    batch = load_geo_archive(root)
    assert batch.sources == {}
    assert batch.errors


def test_corrupt_json_is_reported_without_body_leak(geo_archive):
    root, _, _ = geo_archive
    (root / "metadata" / "001_12345.json").write_text("{BROKEN 每日20题", encoding="utf-8")
    batch = load_geo_archive(root)
    assert "INVALID_JSON" in _codes(batch)
    assert "每日20题" not in json.dumps(batch.errors, ensure_ascii=False)


def test_import_does_not_write_to_source_archive(geo_archive):
    root, _, _ = geo_archive
    before = {p.relative_to(root): p.read_bytes() for p in root.rglob("*") if p.is_file()}
    load_geo_archive(root)
    after = {p.relative_to(root): p.read_bytes() for p in root.rglob("*") if p.is_file()}
    assert before == after


@pytest.mark.parametrize("manifest", [{"not": "an array"}, [None]])
def test_invalid_manifest_cannot_be_treated_as_an_empty_active_set(geo_archive, manifest):
    root, _, _ = geo_archive
    _write_json(root / "采集任务清单.json", manifest)
    batch = load_geo_archive(root)
    assert batch.manifest_valid is False
    assert batch.errors


def test_missing_and_corrupt_manifest_are_fatal_but_valid_empty_manifest_is_not(geo_archive):
    root, _, _ = geo_archive
    path = root / "采集任务清单.json"
    path.unlink()
    assert load_geo_archive(root).manifest_valid is False
    path.write_text("{not-json", encoding="utf-8")
    assert load_geo_archive(root).manifest_valid is False
    _write_json(path, [])
    batch = load_geo_archive(root)
    assert batch.manifest_valid is True
    assert batch.errors == [] and batch.active_source_ids == set()
