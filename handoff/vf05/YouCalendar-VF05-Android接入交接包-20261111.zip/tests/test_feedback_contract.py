"""Offline exchange fixtures for Android and the future HTTP adapter."""

from copy import deepcopy
import json
from pathlib import Path

from fastapi.openapi.models import OpenAPI
from pydantic import TypeAdapter, ValidationError
import pytest

from server.api import create_app
from server.contracts.export_feedback_schema import feedback_schema
from server.contracts.feedback import (
    AudioFeedbackContext,
    FeedbackEvent,
    HttpError,
    TextFeedbackRequest,
    check_complete_event_sequence,
)


FIXTURES = Path(__file__).with_name("fixtures") / "feedback"
EVENT = TypeAdapter(FeedbackEvent)


def fixture_json(name):
    return json.loads((FIXTURES / name).read_text(encoding="utf-8"))


def parse_request(payload, model=TextFeedbackRequest):
    return model.model_validate_json(json.dumps(payload, ensure_ascii=False))


def check_exchange(request, event_payloads):
    check_complete_event_sequence(request, [EVENT.validate_python(item) for item in event_payloads])


def test_exported_schema_matches_contract_models():
    path = FIXTURES.parents[2] / "docs" / "contracts" / "feedback-v1.schema.json"
    assert json.loads(path.read_text(encoding="utf-8")) == feedback_schema()


def test_exported_openapi_matches_served_schema(monkeypatch):
    monkeypatch.delenv("KNOWLEDGE_RELEASE_DIR", raising=False)
    path = FIXTURES.parents[2] / "docs" / "contracts" / "youcalendar.openapi.json"
    spec = create_app().openapi()
    OpenAPI.model_validate(spec)
    assert spec == json.loads(path.read_text(encoding="utf-8"))


def test_text_example_and_unmentioned_tasks():
    request = parse_request(fixture_json("text-request.json"))
    events = fixture_json("text-events.json")
    check_exchange(request, events)
    changes = events[-1]["draft"]["changes"]
    assert {change["task_id"] for change in changes} == {"math_am"}
    assert changes[0]["before"]["completed_count"] == 8
    assert changes[0]["candidate"]["completed_count"] == 12
    assert changes[0]["remaining_count"] == 8


@pytest.mark.parametrize("case", fixture_json("review-cases.json"), ids=lambda case: case["id"])
def test_review_examples(case):
    payload = fixture_json("text-request.json")
    payload["text"] = case["text"]
    events = fixture_json("text-events.json")
    events[-1]["draft"].update(case["draft"])
    check_exchange(parse_request(payload), events)


def test_http_and_stream_errors_use_separate_payloads():
    errors = fixture_json("error-cases.json")
    for entry in errors["http"]:
        HttpError.model_validate(entry["body"])
    text = parse_request(fixture_json("text-request.json"))
    audio = parse_request(fixture_json("audio-context.json"), AudioFeedbackContext)
    check_exchange(text, errors["text_timeout_events"])
    check_exchange(audio, errors["audio_unusable_events"])


def test_audio_result_reuses_draft_and_requires_recognition_stage():
    audio = parse_request(fixture_json("audio-context.json"), AudioFeedbackContext)
    events = fixture_json("audio-events.json")
    check_exchange(audio, events)

    del events[1]
    for seq, event in enumerate(events, 1):
        event["seq"] = seq
    with pytest.raises(ValueError, match="unexpected processing stage"):
        check_exchange(audio, events)


@pytest.mark.parametrize("invalid_progress", [
    {"status": "partial", "completed_count": 8, "reason": None, "unknown": "extra"},
    {"status": "partial", "completed_count": "8", "reason": None},
    {"status": "partial", "completed_count": True, "reason": None},
    {"status": "partial", "completed_count": 20, "reason": None},
    {"status": "not_completed", "completed_count": 0, "reason": None},
])
def test_rejects_invalid_snapshot_progress(invalid_progress):
    payload = fixture_json("text-request.json")
    payload["context"]["tasks"][0]["progress"] = invalid_progress
    with pytest.raises(ValidationError):
        parse_request(payload)


@pytest.mark.parametrize(("field", "value"), [("schema_version", True), ("study_date", "2026-02-30")])
def test_rejects_invalid_version_and_date(field, value):
    payload = fixture_json("text-request.json")
    payload["context"]["ref"][field] = value
    with pytest.raises(ValidationError):
        parse_request(payload)


@pytest.mark.parametrize(("updates", "reason"), [
    ({"task_id": "unknown"}, "outside the request snapshot"),
    ({"task_revision": 2}, "outside the request snapshot"),
    ({"before": {"status": "partial", "completed_count": 7, "reason": None}}, "before progress"),
    ({"reported_quantity": None}, "requires an observed quantity"),
    ({"reported_quantity": {"meaning": "unclear", "value": 12, "unit": "题"}}, "unusable quantity"),
    ({"reported_quantity": {"meaning": "total", "value": 12, "unit": "页"}}, "unusable quantity"),
    ({"reported_quantity": {"meaning": "increment", "value": 12, "unit": "题"}}, "observed quantity"),
    ({"candidate": {"status": "partial", "completed_count": 25, "reason": None}}, "partial count"),
    ({"remaining_count": 9}, "remaining_count"),
    ({"evidence": "不存在的原话"}, "verbatim fragment"),
    ({"issues": ["missing_quantity"]}, "blocked proposal has no normalized counts"),
])
def test_rejects_unsafe_result(updates, reason):
    request = parse_request(fixture_json("text-request.json"))
    events = fixture_json("text-events.json")
    events[-1]["draft"]["changes"][0].update(updates)
    with pytest.raises(ValueError, match=reason):
        check_exchange(request, events)


def test_rejects_wrong_draft_state_and_empty_result():
    request = parse_request(fixture_json("text-request.json"))
    events = fixture_json("text-events.json")
    draft = events[-1]["draft"]
    draft["state"] = "needs_user_input"
    with pytest.raises(ValidationError, match="disagrees with unresolved issues"):
        check_exchange(request, events)
    draft.update(state="ready_for_confirmation", changes=[])
    with pytest.raises(ValidationError, match="empty feedback draft"):
        check_exchange(request, events)


def test_rejects_truncation_late_result_and_duplicate_events():
    request = parse_request(fixture_json("text-request.json"))
    events = fixture_json("text-events.json")
    with pytest.raises(ValueError, match="without a result or error"):
        check_exchange(request, events[:-1])
    with pytest.raises(ValueError, match="end the sequence"):
        check_exchange(request, [*events, deepcopy(events[-1])])
    events[-1]["attempt_id"] = "older_attempt"
    with pytest.raises(ValueError, match="attempt ID"):
        check_exchange(request, events)
    events[-1]["attempt_id"] = request.context.ref.attempt_id
    events[-1]["draft"]["ref"]["snapshot_revision"] -= 1
    with pytest.raises(ValueError, match="does not match request context"):
        check_exchange(request, events)
