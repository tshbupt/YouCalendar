"""Exercise audio admission, recognition and shared draft validation."""

import asyncio
from io import BytesIO
import json
from pathlib import Path
import wave

import httpx
from fastapi.testclient import TestClient
from pydantic import TypeAdapter
import pytest

from server.api import create_app
from server.contracts.feedback import AudioFeedbackContext, FeedbackEvent, check_complete_event_sequence
from server.providers.feedback import DemoFeedbackOrganizer
from server.speech.demo import demo_wav
from server.speech.recognizer import SpeechProviderError
from server.speech.upload import MAX_METADATA_BYTES, MAX_UPLOAD_BYTES, MAX_WAV_BYTES


FIXTURES = Path(__file__).with_name("fixtures") / "feedback"
META = (FIXTURES / "audio-context.json").read_bytes()
PATH = "/v1/feedback/audio"
HEADERS = {"Authorization": "Bearer audio-test"}
DEMO_TEXT = "上午高数一共做了12题。"


def upload(audio=None, metadata=META, *, media_type="audio/wav"):
    return [
        ("metadata", (None, metadata, "application/json")),
        ("audio", ("demo.wav", demo_wav() if audio is None else audio, media_type)),
    ]


def wav(samples, *, rate=16_000, channels=1, width=2):
    buffer = BytesIO()
    with wave.open(buffer, "wb") as recording:
        recording.setparams((channels, width, rate, 0, "NONE", "not compressed"))
        recording.writeframes(samples)
    return buffer.getvalue()


def events_of(response):
    assert response.status_code == 200
    assert response.headers["content-type"].startswith("text/event-stream")
    assert response.headers["cache-control"] == "no-store"
    events = [json.loads(line[6:]) for line in response.text.splitlines() if line.startswith("data: ")]
    adapter = TypeAdapter(FeedbackEvent)
    check_complete_event_sequence(
        AudioFeedbackContext.model_validate_json(META), [adapter.validate_python(event) for event in events],
    )
    return events


class StubRecognizer:
    def __init__(self, transcript=DEMO_TEXT, delay=0):
        self.transcript = transcript
        self.delay = delay
        self.calls = 0
        self.cancelled = False

    async def recognize(self, wave_bytes):
        self.calls += 1
        try:
            await asyncio.sleep(self.delay)
        except asyncio.CancelledError:
            self.cancelled = True
            raise
        if isinstance(self.transcript, Exception):
            raise self.transcript
        return self.transcript


@pytest.fixture(autouse=True)
def local_config(monkeypatch):
    for name in ("FEEDBACK_MODE", "FEEDBACK_API_TOKEN", "KNOWLEDGE_RELEASE_DIR", "KNOWLEDGE_API_TOKEN"):
        monkeypatch.delenv(name, raising=False)


def test_demo_wav_reaches_one_validated_draft_without_spooling(monkeypatch):
    def forbid_spool(*args, **kwargs):
        raise AssertionError("audio must not use a temporary spool file")

    monkeypatch.setattr("starlette.formparsers.SpooledTemporaryFile", forbid_spool)
    monkeypatch.setenv("FEEDBACK_MODE", "demo")
    monkeypatch.setenv("FEEDBACK_API_TOKEN", "audio-test")
    with TestClient(create_app()) as client:
        assert client.get("/health").json()["status"] == "unconfigured"
        events = events_of(client.post(PATH, files=upload(), headers=HEADERS))
    assert [event.get("stage", event["type"]) for event in events] == [
        "received", "recognizing", "structuring", "validating", "result",
    ]
    change, = events[-1]["draft"]["changes"]
    assert change["evidence"] == DEMO_TEXT
    assert (change["candidate"]["completed_count"], change["remaining_count"]) == (12, 8)


def test_feedback_auth_is_required_before_parsing_and_both_adapters_are_required():
    recognizer = StubRecognizer()
    with TestClient(create_app(feedback_token="audio-test", feedback_organizer=DemoFeedbackOrganizer(),
                               speech_recognizer=recognizer, api_token="knowledge-only")) as client:
        denied = client.post(PATH, content=b"not a form", headers={"Authorization": "Bearer knowledge-only"})
    assert denied.status_code == 401 and denied.json() == {"code": "unauthorized"}
    assert denied.headers["www-authenticate"] == "Bearer"
    assert recognizer.calls == 0
    with TestClient(create_app(feedback_token="audio-test", feedback_organizer=DemoFeedbackOrganizer())) as client:
        assert client.post(PATH, files=upload(), headers=HEADERS).status_code == 503


@pytest.mark.parametrize(("form", "status", "code"), [
    (upload(audio=b"bad WAV"), 400, "invalid_request"),
    (upload(audio=demo_wav()[:-2]), 400, "invalid_request"),
    (upload(audio=wav(b"\x01\x00\x02")), 400, "invalid_request"),
    (upload(audio=wav(b"\x01\x00" * 20, rate=8_000)), 415, "unsupported_media_type"),
    (upload(audio=wav(b"\x01\x00" * 20, channels=2)), 415, "unsupported_media_type"),
    (upload(audio=wav(b"\x01" * 20, width=1)), 415, "unsupported_media_type"),
    (upload(audio=wav(b"\x01\x00" * (60 * 16_000 + 1))), 413, "payload_too_large"),
    (upload(audio=b"\x01" * (MAX_WAV_BYTES + 1)), 413, "payload_too_large"),
    (upload(metadata=b" " * (MAX_METADATA_BYTES + 1)), 413, "payload_too_large"),
    (upload(media_type="audio/mpeg"), 415, "unsupported_media_type"),
    (upload(metadata=b"VF04_invalid_metadata_sentinel"), 400, "invalid_request"),
    (upload()[:1], 400, "invalid_request"),
    (upload() + upload()[1:], 400, "invalid_request"),
], ids=[
    "bad-wav", "truncated-wav", "partial-sample", "sample-rate", "channels", "sample-width", "duration",
    "wav-bytes", "metadata-bytes", "media-type", "invalid-metadata", "missing-audio", "duplicate-audio",
])
def test_rejects_bad_upload_before_recognition(form, status, code, caplog):
    recognizer = StubRecognizer()
    app = create_app(feedback_token="audio-test", feedback_organizer=DemoFeedbackOrganizer(),
                     speech_recognizer=recognizer)
    with TestClient(app) as client:
        response = client.post(PATH, files=form, headers=HEADERS)
    assert (response.status_code, response.json()) == (status, {"code": code})
    assert recognizer.calls == 0
    assert "VF04_invalid_metadata_sentinel" not in caplog.text


def test_truncated_multipart_and_total_size_are_rejected():
    recognizer = StubRecognizer()
    app = create_app(feedback_token="audio-test", feedback_organizer=DemoFeedbackOrganizer(),
                     speech_recognizer=recognizer)
    prepared = httpx.Request("POST", "http://test/", files=upload())
    body = prepared.read()
    media = prepared.headers["content-type"]
    with TestClient(app) as client:
        response = client.post(PATH, content=body[:-10], headers={**HEADERS, "Content-Type": media})
        oversized = client.post(PATH, content=b"x", headers={
            **HEADERS, "Content-Type": media, "Content-Length": str(MAX_UPLOAD_BYTES + 1),
        })
    assert (response.status_code, response.json()) == (400, {"code": "invalid_request"})
    assert (oversized.status_code, oversized.json()) == (413, {"code": "payload_too_large"})
    assert recognizer.calls == 0


def test_silence_is_terminal_and_skips_recognizer():
    recognizer = StubRecognizer()
    app = create_app(feedback_token="audio-test", feedback_organizer=DemoFeedbackOrganizer(),
                     speech_recognizer=recognizer)
    with TestClient(app) as client:
        events = events_of(client.post(PATH, files=upload(audio=wav(b"\x00\x00" * 4000)), headers=HEADERS))
    assert [event.get("stage", event.get("code")) for event in events] == ["received", "recognizing", "unusable_audio"]
    assert recognizer.calls == 0


@pytest.mark.parametrize(("outcome", "delay", "code"), [
    (" \n ", 0, "unusable_audio"),
    ("字" * 8001, 0, "asr_failed"),
    (SpeechProviderError("VF04_provider_audio_sentinel"), 0, "asr_failed"),
    (DEMO_TEXT, 10, "processing_timeout"),
], ids=["blank", "oversize-transcript", "provider-error", "timeout"])
def test_recognition_failure_is_terminal_and_never_sends_a_draft(outcome, delay, code, caplog):
    recognizer = StubRecognizer(outcome, delay)
    app = create_app(feedback_token="audio-test", feedback_organizer=DemoFeedbackOrganizer(),
                     speech_recognizer=recognizer, feedback_timeout=0.05)
    with TestClient(app) as client:
        response = client.post(PATH, files=upload(), headers=HEADERS)
    events = events_of(response)
    assert [event.get("stage", event.get("code")) for event in events] == ["received", "recognizing", code]
    assert recognizer.calls == 1
    assert recognizer.cancelled is (delay > 0)
    assert "VF04_provider_audio_sentinel" not in response.text + caplog.text


def test_audio_draft_evidence_is_verified_against_actual_recognizer_text():
    class WrongEvidence:
        async def organize(self, request):
            result = await DemoFeedbackOrganizer().organize(request)
            draft = json.loads(result)
            draft["changes"][0]["evidence"] = "这句不在识别文本里。"
            return json.dumps(draft)

    app = create_app(feedback_token="audio-test", feedback_organizer=WrongEvidence(),
                     speech_recognizer=StubRecognizer())
    with TestClient(app) as client:
        events = events_of(client.post(PATH, files=upload(), headers=HEADERS))
    assert [event.get("stage", event.get("code")) for event in events] == [
        "received", "recognizing", "structuring", "validating", "invalid_output",
    ]
