"""Test the Tencent adapter and fixed audio evaluation without external calls."""

import asyncio
import base64
import json
import sqlite3

import httpx
import pytest

from evals.speech.run import MAX_CALLS, PER_CALL_MICROS, MeasuredRecognizer, evaluate, load_cases, reserve_case
from server.speech.demo import demo_wav
from server.speech.recognizer import UnusableAudio
from server.speech.tencent import ENDPOINT, TencentSpeechError, TencentSpeechRecognizer


@pytest.mark.parametrize("case", load_cases(), ids=lambda case: case["id"])
def test_synthetic_case_through_asr_adapter_and_audio_route(case):
    calls = []

    def upstream(request):
        calls.append(request.url)
        assert request.url == ENDPOINT and request.method == "POST"
        assert request.headers["x-tc-action"] == "SentenceRecognition"
        assert request.headers["x-tc-version"] == "2019-06-14"
        assert request.headers["authorization"].startswith("TC3-HMAC-SHA256 Credential=synthetic-id/")
        payload = json.loads(request.content)
        assert set(payload) == {"EngSerViceType", "SourceType", "VoiceFormat", "Data", "DataLen", "ConvertNumMode"}
        assert payload["EngSerViceType"] == "16k_zh" and payload["SourceType"] == 1
        assert payload["VoiceFormat"] == "wav" and payload["ConvertNumMode"] == 1
        assert base64.b64decode(payload["Data"], validate=True) == demo_wav()
        assert payload["DataLen"] == len(demo_wav())
        # The live API returned the professional-term sample with a Chinese numeral.
        transcript = case["script"] if case["id"] == "professional_term" else case["text"]
        return httpx.Response(200, json={"Response": {"Result": transcript, "RequestId": "synthetic-request"}})

    async def scenario():
        async with httpx.AsyncClient(transport=httpx.MockTransport(upstream)) as client:
            recognizer = MeasuredRecognizer(TencentSpeechRecognizer(client, "synthetic-id", "synthetic-key"))
            return await evaluate(case, demo_wav(), recognizer)

    result = asyncio.run(scenario())
    assert result["asr_pass"] and result["draft_pass"] and result["terminal"] == "result"
    assert calls == [ENDPOINT]


def test_transcription_mismatch_keeps_draft_pending():
    case = load_cases()[0]

    async def scenario():
        async with httpx.AsyncClient(transport=httpx.MockTransport(lambda _: httpx.Response(
            200, json={"Response": {"Result": "上午高数一共做了19题。"}},
        ))) as client:
            recognizer = MeasuredRecognizer(TencentSpeechRecognizer(client, "synthetic-id", "synthetic-key"))
            return await evaluate(case, demo_wav(), recognizer)

    result = asyncio.run(scenario())
    assert not result["asr_pass"] and not result["draft_pass"]
    assert result["draft_state"] == "needs_user_input"


@pytest.mark.parametrize(("status", "response", "error"), [
    (302, {}, "http_302"),
    (200, {"Response": {"Error": {"Code": "AuthFailure", "Message": "private provider details"}}}, "AuthFailure"),
    (200, {"Response": {"Result": None}}, "invalid_transcript"),
])
def test_failure_is_sanitized_and_request_is_not_retried(status, response, error):
    calls = []

    def upstream(request):
        calls.append(request.url)
        return httpx.Response(status, json=response, headers={"Location": "https://example.invalid/"})

    async def scenario():
        async with httpx.AsyncClient(transport=httpx.MockTransport(upstream), follow_redirects=True) as client:
            recognizer = TencentSpeechRecognizer(client, "synthetic-id", "synthetic-key")
            with pytest.raises(TencentSpeechError, match=f"^{error}$"):
                await recognizer.recognize(demo_wav())

    asyncio.run(scenario())
    assert calls == [ENDPOINT]


def test_empty_transcript_uses_unusable_audio_contract():
    async def scenario():
        async with httpx.AsyncClient(transport=httpx.MockTransport(lambda _: httpx.Response(
            200, json={"Response": {"Result": " "}},
        ))) as client:
            with pytest.raises(UnusableAudio):
                await TencentSpeechRecognizer(client, "synthetic-id", "synthetic-key").recognize(demo_wav())

    asyncio.run(scenario())


def test_budget_reserves_each_case_once_even_after_reopening(tmp_path):
    ledger = tmp_path / "budget.sqlite"
    for case in load_cases():
        assert reserve_case(ledger, case["id"])
        assert not reserve_case(ledger, case["id"])
    assert not reserve_case(ledger, "seventh")
    with sqlite3.connect(ledger) as db:
        assert db.execute("SELECT COUNT(*),SUM(bound_micros) FROM attempts").fetchone() == (MAX_CALLS, 6 * PER_CALL_MICROS)
