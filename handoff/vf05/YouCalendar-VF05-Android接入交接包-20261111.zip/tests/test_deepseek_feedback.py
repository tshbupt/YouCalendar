"""VF-03 adapter, semantic checks and paid-evaluation boundaries without network calls."""

import asyncio
import json
import sqlite3

import httpx
import pytest

from evals.feedback.run import BUDGET, EVAL_REVISION, RESERVE, BudgetLedger, load_cases, run_cases, score_draft
from server.api import create_app
from server.providers.deepseek_feedback import (
    CHAT_URL, MAX_OUTPUT_TOKENS, MODEL, Completion, DeepSeekFeedbackOrganizer, Usage, build_draft,
)
from server.providers.feedback import FeedbackProviderError


CASES = {case_id: (request, expected) for case_id, request, expected in load_cases()}
SYNTHETIC_USAGE = {"prompt_tokens": 500, "completion_tokens": 100}


def observation(request, *, task_id="t1", status="partial", meaning=None, value=None, unit="题", reason=None):
    return {
        "task_id": task_id, "evidence": request.text, "status": status, "reason": reason,
        "quantity": {"meaning": meaning, "value": value, "unit": unit} if meaning else None,
    }


def extraction(*, change=None, unmatched=None, date_pending=False):
    return {
        "changes": [change] if change else [], "unmatched": unmatched or [],
        "date_needs_confirmation": date_pending, "summary": None,
    }


def provider_response(content, *, finish_reason="stop", usage=SYNTHETIC_USAGE):
    return httpx.Response(200, json={
        "model": MODEL, "usage": usage,
        "choices": [{"finish_reason": finish_reason, "message": {"content": content}}],
    })


@pytest.mark.parametrize("case_id", CASES)
def test_gold_case_against_deterministic_normalization(case_id):
    request, expected = CASES[case_id]
    quantity_cases = {
        "explicit_total": ("total", 12, "题"),
        "explicit_increment": ("increment", 4, "题"),
        "unclear_quantity": ("unclear", 12, "题"),
        "wrong_unit": ("total", 12, "页"),
        "beyond_plan": ("total", 25, "题"),
        "correct_checkin": ("total", 6, "题"),
        "spoken_correction": ("total", 12, "题"),
    }
    if case_id in quantity_cases:
        meaning, value, unit = quantity_cases[case_id]
        raw = extraction(change=observation(request, meaning=meaning, value=value, unit=unit))
    elif case_id in ("missing_reason", "reason_and_omitted_tasks"):
        reason = "临时有事" if case_id == "reason_and_omitted_tasks" else None
        raw = extraction(change=observation(request, task_id="t3", status="not_completed", reason=reason))
    elif case_id == "unknown_task":
        raw = extraction(unmatched=[{"evidence": request.text, "candidate_task_ids": []}])
    elif case_id == "ambiguous_task":
        # A confident guess at the first of two same-name tasks must stay unmatched.
        raw = extraction(change=observation(request, status="completed"))
    else:
        raw = extraction(date_pending=True)
    draft = build_draft(request, Completion(json.dumps(raw), None))
    assert score_draft(draft, expected)["verdict"] == "pass"


def test_guessed_quantity_old_count_and_wrong_date_cannot_be_ready():
    request, expected = CASES["unclear_quantity"]
    raw = extraction(change=observation(request, meaning="total", value=12))
    draft = build_draft(request, Completion(json.dumps(raw), None))
    score = score_draft(draft, expected)
    assert score["verdict"] == "mismatch" and not score["reviewable_mismatch"]

    request, _ = CASES["spoken_correction"]
    raw = extraction(change=observation(request, meaning="total", value=14))
    draft = build_draft(request, Completion(json.dumps(raw), None))
    assert draft.state == "needs_user_input"
    assert draft.changes[0].remaining_count is None

    request, _ = CASES["different_date"]
    raw = extraction(change=observation(request, meaning="total", value=12))
    draft = build_draft(request, Completion(json.dumps(raw), None))
    assert draft.date_needs_confirmation and draft.state == "needs_user_input"
    assert draft.changes == []


@pytest.mark.parametrize(("case_id", "alias", "status", "meaning", "value", "reason"), [
    ("missing_reason", "t3", "not_completed", None, None, "没做"),
    ("correct_checkin", "t1", "partial", "total", 6, "打卡写错了"),
])
def test_status_or_correction_fragment_cannot_fill_in_a_reason(case_id, alias, status, meaning, value, reason):
    request, expected = CASES[case_id]
    raw = extraction(change=observation(request, task_id=alias, status=status, meaning=meaning, value=value, reason=reason))
    draft = build_draft(request, Completion(json.dumps(raw), None))
    assert draft.changes[0].candidate.reason is None
    assert score_draft(draft, expected)["verdict"] == "pass"


def test_same_fragment_is_only_reported_once_when_two_tasks_are_guessed():
    request, expected = CASES["ambiguous_task"]
    raw = extraction(change=observation(request, status="completed"))
    raw["changes"].append(observation(request, task_id="t2", status="completed"))
    draft = build_draft(request, Completion(json.dumps(raw), None))
    assert score_draft(draft, expected)["verdict"] == "pass"


def test_real_adapter_interface_reuses_existing_text_route():
    request, _ = CASES["explicit_increment"]
    request = request.model_copy(deep=True)
    request.context.tasks[0].progress.reason = "private previous reason sentinel"
    calls = []

    def upstream(http_request):
        calls.append(http_request)
        assert http_request.url == CHAT_URL and http_request.method == "POST"
        assert http_request.headers["authorization"] == "Bearer synthetic-key"
        payload = json.loads(http_request.content)
        assert payload["model"] == MODEL and payload["max_tokens"] == MAX_OUTPUT_TOKENS
        assert payload["thinking"] == {"type": "disabled"}
        assert payload["response_format"] == {"type": "json_object"}
        assert not payload["stream"] and "tools" not in payload
        data = json.loads(payload["messages"][1]["content"])
        assert data["text"] == request.text and data["tasks"][0]["task_id"] == "t1"
        assert "math_am" not in http_request.content.decode()
        assert "private previous reason sentinel" not in http_request.content.decode()
        assert "submission_id" not in data and "context" not in data
        content = json.dumps(extraction(change=observation(request, meaning="increment", value=4)))
        return provider_response(content)

    async def scenario():
        async with httpx.AsyncClient(transport=httpx.MockTransport(upstream)) as upstream_client:
            organizer = DeepSeekFeedbackOrganizer(upstream_client, "synthetic-key")
            app = create_app(feedback_token="local-test", feedback_organizer=organizer)
            async with httpx.AsyncClient(transport=httpx.ASGITransport(app=app), base_url="http://test") as client:
                response = await client.post("/v1/feedback/text", json=request.model_dump(mode="json"),
                                             headers={"Authorization": "Bearer local-test"})
        assert response.status_code == 200
        events = [json.loads(line[6:]) for line in response.text.splitlines() if line.startswith("data: ")]
        assert [event["type"] for event in events] == ["stage", "stage", "stage", "result"]
        change = events[-1]["draft"]["changes"][0]
        assert change["candidate"]["completed_count"] == 12 and change["remaining_count"] == 8
        assert change["before"]["completed_count"] == 8 and change["task_id"] == "math_am"

    asyncio.run(scenario())
    assert len(calls) == 1


@pytest.mark.parametrize("override", [{"task_id": "made_up"}, {"evidence": "上午高数一共做了19题。"}])
def test_rejects_fabricated_task_or_evidence(override):
    request, _ = CASES["explicit_total"]
    change = observation(request, meaning="total", value=12)
    with pytest.raises(ValueError):
        build_draft(request, Completion(json.dumps(extraction(change={**change, **override})), None))


@pytest.mark.parametrize(("content", "finish_reason"), [(" ", "stop"), ("{}", "length"), ("{", "stop")])
def test_truncated_blank_and_invalid_output_keeps_usage(content, finish_reason):
    request, _ = CASES["explicit_total"]

    async def scenario():
        async with httpx.AsyncClient(transport=httpx.MockTransport(
            lambda _: provider_response(content, finish_reason=finish_reason),
        )) as client:
            organizer = DeepSeekFeedbackOrganizer(client, "synthetic-key")
            completed = await organizer.complete(request)
            assert completed.usage == Usage(500, 100)
            with pytest.raises(ValueError):
                build_draft(request, completed)

    asyncio.run(scenario())


@pytest.mark.parametrize("status", [302, 401, 429, 503])
def test_upstream_failure_has_no_retry_or_redirect(status):
    request, _ = CASES["explicit_total"]
    calls = []

    def upstream(http_request):
        calls.append(http_request.url)
        return httpx.Response(status, headers={"Location": "https://example.invalid/"}, text="private body")

    async def scenario():
        async with httpx.AsyncClient(transport=httpx.MockTransport(upstream), follow_redirects=True) as client:
            organizer = DeepSeekFeedbackOrganizer(client, "synthetic-key")
            with pytest.raises(FeedbackProviderError, match=f"^DeepSeek HTTP {status}$"):
                await organizer.complete(request)

    asyncio.run(scenario())
    assert calls == [CHAT_URL]


def test_cancellation_reaches_pending_upstream():
    request, _ = CASES["explicit_total"]

    async def scenario():
        entered = asyncio.Event()
        closed = asyncio.Event()

        async def upstream(_):
            entered.set()
            try:
                await asyncio.Future()
            finally:
                closed.set()

        async with httpx.AsyncClient(transport=httpx.MockTransport(upstream)) as client:
            organizer = DeepSeekFeedbackOrganizer(client, "synthetic-key")
            task = asyncio.create_task(organizer.complete(request))
            await asyncio.wait_for(entered.wait(), 1)
            task.cancel()
            with pytest.raises(asyncio.CancelledError):
                await task
            assert closed.is_set()

    asyncio.run(scenario())


def test_unknown_charge_blocks_replay_and_preserves_budget_after_restart(tmp_path):
    path = tmp_path / "budget.sqlite"
    ledger = BudgetLedger(path)
    assert 0 < RESERVE < BUDGET < 2 * RESERVE
    assert ledger.reserve("first") == "reserved"
    restarted = BudgetLedger(path)
    assert restarted.reserve("first") == "already_attempted"
    assert restarted.reserve("next") == "budget_exhausted"
    assert restarted.settle("first", Usage(500, 100)) == 1800
    assert restarted.reserve("next") == "reserved"


def test_evaluation_stops_on_missing_usage_without_second_paid_request(tmp_path, capsys):
    requests = []

    def upstream(request):
        requests.append(request)
        return provider_response("{}", usage=None)

    path = tmp_path / "budget.sqlite"

    async def scenario():
        async with httpx.AsyncClient(transport=httpx.MockTransport(upstream)) as client:
            organizer = DeepSeekFeedbackOrganizer(client, "synthetic-key")
            assert not await run_cases(load_cases(), organizer, BudgetLedger(path))

    asyncio.run(scenario())
    assert len(requests) == 1 and "usage_unknown" in capsys.readouterr().out
    with sqlite3.connect(path) as db:
        assert db.execute("SELECT * FROM attempts").fetchall() == [(f"v{EVAL_REVISION}:explicit_total", RESERVE, 0)]
