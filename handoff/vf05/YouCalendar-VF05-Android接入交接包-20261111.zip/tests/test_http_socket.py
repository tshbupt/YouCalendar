"""Exercise a real localhost Uvicorn process, not an in-process ASGI client."""

import hashlib
import json
import os
from pathlib import Path
import secrets
import socket
import subprocess
import sys
import time
from urllib.error import HTTPError, URLError
from urllib.request import Request, urlopen


def test_real_http_service_authorization_scope_and_no_query_persistence(tmp_path):
    project = Path(__file__).resolve().parents[1]
    flags = getattr(subprocess, "CREATE_NO_WINDOW", 0)
    created = subprocess.run(
        [sys.executable, "-X", "utf8", "-m", "server.knowledge.cli", "demo",
         "--workspace", str(tmp_path / "demo"), "--version", "socket-v1"],
        cwd=project, capture_output=True, text=True, encoding="utf-8", check=True,
        creationflags=flags,
    )
    release = Path(json.loads(created.stdout)["release_dir"])
    before = {p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in release.iterdir()}
    with socket.socket() as reservation:
        reservation.bind(("127.0.0.1", 0))
        port = reservation.getsockname()[1]
    token = secrets.token_urlsafe(32)
    environment = dict(os.environ, KNOWLEDGE_RELEASE_DIR=str(release), KNOWLEDGE_API_TOKEN=token)
    process = subprocess.Popen(
        [sys.executable, "-m", "uvicorn", "server.api:app", "--host", "127.0.0.1",
         "--port", str(port), "--no-access-log", "--log-level", "warning"],
        cwd=project, env=environment, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
        creationflags=flags,
    )
    try:
        base = f"http://127.0.0.1:{port}"
        ready = False
        for _ in range(80):
            if process.poll() is not None:
                raise AssertionError("local HTTP process exited before readiness")
            try:
                with urlopen(base + "/health", timeout=0.5) as response:
                    ready = json.load(response)["status"] == "ready"
                if ready:
                    break
            except (URLError, TimeoutError):
                time.sleep(0.05)
        assert ready, "local HTTP service did not become ready"
        body = json.dumps({"q": "复习 查询隐私哨兵socket", "subject": "演示科目"}).encode("utf-8")
        headers = {"Content-Type": "application/json", "Authorization": f"Bearer {token}"}
        with urlopen(Request(base + "/v1/knowledge/search", body, headers), timeout=5) as response:
            result = json.load(response)
        assert result["knowledge_version"] == "socket-v1"
        assert result["results"][0]["source_type"] == "synthetic_demo"
        wrong = Request(base + "/v1/knowledge/search", body,
                        {"Content-Type": "application/json", "Authorization": "Bearer wrong"})
        try:
            urlopen(wrong, timeout=5)
        except HTTPError as error:
            assert error.code == 401
        else:
            raise AssertionError("wrong token unexpectedly accepted")
        after = {p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in release.iterdir()}
        assert before == after
    finally:
        process.terminate()
        try:
            stdout, stderr = process.communicate(timeout=5)
        except subprocess.TimeoutExpired:
            process.kill()
            stdout, stderr = process.communicate(timeout=5)
        assert "查询隐私哨兵socket".encode() not in stdout + stderr
