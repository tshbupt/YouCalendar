"""Test progress and cancellation over an actual localhost HTTP socket."""

import asyncio
import json
from pathlib import Path
import socket
import threading
import time

import httpx
import pytest
import uvicorn

from server.api import create_app
from server.feedback.text import MAX_REQUEST_BYTES
from server.providers.feedback import DemoFeedbackOrganizer
from server.speech.demo import demo_wav
from server.speech.upload import MAX_WAV_BYTES


FIXTURE = Path(__file__).with_name("fixtures") / "feedback" / "text-request.json"
HEADERS = {"Authorization": "Bearer local-feedback-test", "Content-Type": "application/json"}
PATH = "/v1/feedback/text"
AUDIO_PATH = "/v1/feedback/audio"
AUDIO_FIXTURE = FIXTURE.with_name("audio-context.json")
AUDIO_HEADERS = {"Authorization": HEADERS["Authorization"]}


class HeldCall:
    def __init__(self):
        self.entered = threading.Event()
        self.cancelled = threading.Event()

    async def wait(self):
        self.loop = asyncio.get_running_loop()
        self.release = asyncio.Event()
        self.entered.set()
        try:
            await self.release.wait()
        except asyncio.CancelledError:
            self.cancelled.set()
            raise

    def finish(self):
        self.loop.call_soon_threadsafe(self.release.set)


class HeldOrganizer(HeldCall):
    async def organize(self, request):
        await self.wait()
        return await DemoFeedbackOrganizer().organize(request)


class HeldRecognizer(HeldCall):
    async def recognize(self, audio):
        await self.wait()
        assert audio == demo_wav()
        return "上午高数一共做了12题。"


@pytest.fixture
def live_feedback(monkeypatch):
    monkeypatch.delenv("KNOWLEDGE_RELEASE_DIR", raising=False)
    organizer = HeldOrganizer()
    recognizer = HeldRecognizer()
    app = create_app(feedback_token="local-feedback-test", feedback_organizer=organizer,
                     speech_recognizer=recognizer)
    server = uvicorn.Server(uvicorn.Config(app, access_log=False, log_level="warning", lifespan="off"))
    with socket.socket() as listener:
        listener.bind(("127.0.0.1", 0))
        port = listener.getsockname()[1]
        thread = threading.Thread(target=server.run, kwargs={"sockets": [listener]}, daemon=True)
        thread.start()
        try:
            deadline = time.monotonic() + 5
            while thread.is_alive() and not server.started and time.monotonic() < deadline:
                time.sleep(0.01)
            assert server.started
            with httpx.Client(base_url=f"http://127.0.0.1:{port}", timeout=4, trust_env=False) as client:
                yield client, organizer, recognizer
        finally:
            for work in (organizer, recognizer):
                if work.entered.is_set() and thread.is_alive():
                    work.finish()
            server.should_exit = True
            thread.join(timeout=5)
            assert not thread.is_alive()


def _sse_payloads(response):
    assert response.status_code == 200
    assert response.headers["content-type"].startswith("text/event-stream")
    for line in response.iter_lines():
        if line.startswith("data: "):
            yield json.loads(line.removeprefix("data: "))


def test_socket_delivers_progress_while_organizer_is_still_waiting(live_feedback):
    client, organizer, _ = live_feedback
    with client.stream("POST", PATH, headers=HEADERS, content=FIXTURE.read_bytes()) as response:
        events = _sse_payloads(response)
        assert next(events)["stage"] == "received"
        assert next(events)["stage"] == "structuring"
        assert organizer.entered.wait(2)
        organizer.finish()
        assert next(events)["stage"] == "validating"
        result, = events
    change = result["draft"]["changes"][0]
    assert change["evidence"] == "上午高数一共做了12题。"
    assert change["candidate"]["completed_count"] == 12
    assert change["remaining_count"] == 8


def test_socket_disconnect_cancels_the_waiting_organizer(live_feedback):
    client, organizer, _ = live_feedback
    with client.stream("POST", PATH, headers=HEADERS, content=FIXTURE.read_bytes()) as response:
        events = _sse_payloads(response)
        assert next(events)["stage"] == "received"
        assert next(events)["stage"] == "structuring"
        assert organizer.entered.wait(2)
    assert organizer.cancelled.wait(2), "organizer still running after client disconnected"


def test_socket_caps_chunked_upload_without_a_content_length(live_feedback):
    client, organizer, _ = live_feedback

    def chunks():
        yield b" " * (MAX_REQUEST_BYTES // 2)
        yield b" " * (MAX_REQUEST_BYTES // 2)
        yield b" "

    response = client.post(PATH, headers=HEADERS, content=chunks())
    assert "content-length" not in response.request.headers
    assert response.status_code == 413 and response.json() == {"code": "payload_too_large"}
    assert not organizer.entered.is_set()


def _audio_parts():
    return {"metadata": (None, AUDIO_FIXTURE.read_bytes(), "application/json"),
            "audio": ("demo.wav", demo_wav(), "audio/wav")}


def test_socket_delivers_audio_stages_before_the_held_work_completes(live_feedback):
    client, organizer, recognizer = live_feedback
    with client.stream("POST", AUDIO_PATH, headers=AUDIO_HEADERS, files=_audio_parts()) as response:
        events = _sse_payloads(response)
        assert next(events)["stage"] == "received"
        assert next(events)["stage"] == "recognizing"
        assert recognizer.entered.wait(2) and not organizer.entered.is_set()
        recognizer.finish()
        assert next(events)["stage"] == "structuring"
        assert organizer.entered.wait(2)
        organizer.finish()
        assert next(events)["stage"] == "validating"
        result, = events
    assert result["seq"] == 5 and result["type"] == "result"
    assert result["draft"]["changes"][0]["candidate"]["completed_count"] == 12


def test_socket_disconnect_cancels_recognition_before_structuring(live_feedback):
    client, organizer, recognizer = live_feedback
    with client.stream("POST", AUDIO_PATH, headers=AUDIO_HEADERS, files=_audio_parts()) as response:
        events = _sse_payloads(response)
        assert next(events)["stage"] == "received"
        assert next(events)["stage"] == "recognizing"
        assert recognizer.entered.wait(2)
    assert recognizer.cancelled.wait(2)
    assert not organizer.entered.is_set()


def test_socket_rejects_oversized_audio_part_in_chunked_upload(live_feedback):
    client, _, recognizer = live_feedback

    def chunks():
        yield b'--vf04\r\nContent-Disposition: form-data; name="audio"; filename="long.wav"\r\n'
        yield b'Content-Type: audio/wav\r\n\r\n'
        yield b"\x01" * MAX_WAV_BYTES
        yield b"\x01\r\n--vf04--\r\n"

    response = client.post(AUDIO_PATH, headers={
        **AUDIO_HEADERS, "Content-Type": "multipart/form-data; boundary=vf04",
    }, content=chunks())
    assert "content-length" not in response.request.headers
    assert (response.status_code, response.json()) == (413, {"code": "payload_too_large"})
    assert not recognizer.entered.is_set()
