"""Text feedback acceptance checks using the VF-01 examples."""

import asyncio
import json
from pathlib import Path

from fastapi.testclient import TestClient
from pydantic import TypeAdapter
import pytest

from server.api import create_app
from server.contracts.feedback import FeedbackEvent, TextFeedbackRequest, check_complete_event_sequence
from server.feedback.text import MAX_REQUEST_BYTES
from server.providers.feedback import FeedbackProviderError


FIXTURES = Path(__file__).with_name("fixtures") / "feedback"
PATH = "/v1/feedback/text"
HEADERS = {"Authorization": "Bearer feedback-test"}
EVENT = TypeAdapter(FeedbackEvent)


def fixture_json(name):
    return json.loads((FIXTURES / name).read_text(encoding="utf-8"))


def read_events(response, request):
    assert response.status_code == 200
    assert response.headers["content-type"].startswith("text/event-stream")
    assert response.headers["cache-control"] == "no-store"
    frames = response.text.strip().split("\n\n")
    assert all(frame.startswith("data: ") for frame in frames)
    events = [json.loads(frame.removeprefix("data: ")) for frame in frames]
    check_complete_event_sequence(
        TextFeedbackRequest.model_validate(request), [EVENT.validate_python(event) for event in events]
    )
    return events


class ScriptedOrganizer:
    def __init__(self, outcome="{}", *, delay=0):
        self.outcome = outcome
        self.delay = delay
        self.calls = 0
        self.cancelled = False

    async def organize(self, request):
        self.calls += 1
        try:
            await asyncio.sleep(self.delay)
        except asyncio.CancelledError:
            self.cancelled = True
            raise
        if isinstance(self.outcome, Exception):
            raise self.outcome
        return self.outcome


@pytest.fixture(autouse=True)
def isolated_config(monkeypatch):
    for key in ("KNOWLEDGE_RELEASE_DIR", "KNOWLEDGE_API_TOKEN", "FEEDBACK_MODE", "FEEDBACK_API_TOKEN"):
        monkeypatch.delenv(key, raising=False)


@pytest.mark.parametrize("case_id", [None, "increment", "unclear_quantity_meaning", "correct_manual_progress"])
def test_demo_route_serves_fixed_scenarios_without_knowledge(monkeypatch, case_id):
    monkeypatch.setenv("FEEDBACK_MODE", "demo")
    monkeypatch.setenv("FEEDBACK_API_TOKEN", "feedback-test")
    request = fixture_json("text-request.json")
    expected = fixture_json("text-events.json")[-1]["draft"]
    if case_id is not None:
        case = next(case for case in fixture_json("review-cases.json") if case["id"] == case_id)
        request["text"] = case["text"]
        expected.update(case["draft"])
    # The evidence may include final punctuation, but must remain verbatim.
    for change in expected["changes"]:
        change["evidence"] = request["text"]
    with TestClient(create_app()) as client:
        assert client.get("/health").json()["status"] == "unconfigured"
        events = read_events(client.post(PATH, json=request, headers=HEADERS), request)
    assert events[-1]["draft"] == expected


def test_demo_leaves_other_inputs_unmatched(monkeypatch):
    monkeypatch.setenv("FEEDBACK_MODE", "demo")
    request = fixture_json("text-request.json")
    request["text"] = "做完了电路真题。"
    with TestClient(create_app(feedback_token="feedback-test")) as client:
        result = read_events(client.post(PATH, json=request, headers=HEADERS), request)[-1]
    assert result["draft"]["state"] == "needs_user_input"
    assert result["draft"]["changes"] == []
    assert result["draft"]["unmatched"] == [{"evidence": request["text"], "candidate_task_ids": []}]


def test_preflight_rejects_invalid_requests_before_provider(caplog):
    organizer = ScriptedOrganizer()
    app = create_app(api_token="knowledge-only", feedback_token="feedback-test", feedback_organizer=organizer)
    request = fixture_json("text-request.json")
    marker = "VF02合成隐私标记"
    with TestClient(app) as client:
        no_token = client.post(PATH, json=request)
        knowledge_token = client.post(PATH, json=request, headers={"Authorization": "Bearer knowledge-only"})
        wrong_type = client.post(PATH, content=marker.encode(), headers=HEADERS)
        too_large = client.post(PATH, content=b" " * (MAX_REQUEST_BYTES + 1), headers={
            **HEADERS, "Content-Type": "application/json",
        })
        malformed = client.post(PATH, content=marker.encode(), headers={
            **HEADERS, "Content-Type": "application/json",
        })
        invalid_fields = client.post(PATH, json={**request, "extra": marker}, headers=HEADERS)
    for response, status, code in [
        (no_token, 401, "unauthorized"), (knowledge_token, 401, "unauthorized"),
        (wrong_type, 415, "unsupported_media_type"), (too_large, 413, "payload_too_large"),
        (malformed, 400, "invalid_request"), (invalid_fields, 400, "invalid_request"),
    ]:
        assert (response.status_code, response.json()) == (status, {"code": code})
    assert no_token.headers["www-authenticate"] == "Bearer"
    assert organizer.calls == 0
    assert marker not in caplog.text


def test_disabled_service_requires_both_token_and_organizer():
    for app in (create_app(feedback_organizer=ScriptedOrganizer()), create_app(feedback_token="feedback-test")):
        with TestClient(app) as client:
            response = client.post(PATH, json=fixture_json("text-request.json"), headers=HEADERS)
        assert response.status_code == 503
        assert response.json() == {"code": "service_unavailable"}


@pytest.mark.parametrize(("outcome", "code"), [
    ("", "invalid_output"), ("{broken", "invalid_output"), ("{}", "invalid_output"),
    (FeedbackProviderError("VF02上游隐私标记"), "provider_failed"),
    (RuntimeError("VF02上游隐私标记"), "internal_error"),
])
def test_organizer_failures_have_one_safe_terminal_event(outcome, code, caplog):
    request = fixture_json("text-request.json")
    app = create_app(feedback_token="feedback-test", feedback_organizer=ScriptedOrganizer(outcome))
    with TestClient(app) as client:
        response = client.post(PATH, json=request, headers=HEADERS)
    events = read_events(response, request)
    assert events[-1]["type"] == "error" and events[-1]["code"] == code
    assert all(event["type"] == "stage" for event in events[:-1])
    assert "VF02上游隐私标记" not in response.text + caplog.text


def test_shape_valid_but_conflicting_output_is_rejected():
    request = fixture_json("text-request.json")
    draft = fixture_json("text-events.json")[-1]["draft"]
    draft["changes"][0]["remaining_count"] = 9
    app = create_app(feedback_token="feedback-test", feedback_organizer=ScriptedOrganizer(json.dumps(draft)))
    with TestClient(app) as client:
        events = read_events(client.post(PATH, json=request, headers=HEADERS), request)
    assert events[-1]["type"] == "error" and events[-1]["code"] == "invalid_output"


def test_processing_timeout_cancels_pending_work():
    request = fixture_json("text-request.json")
    organizer = ScriptedOrganizer(delay=30)
    app = create_app(feedback_token="feedback-test", feedback_organizer=organizer, feedback_timeout=0.05)
    with TestClient(app) as client:
        events = read_events(client.post(PATH, json=request, headers=HEADERS), request)
    assert [event.get("stage", event.get("code")) for event in events] == [
        "received", "structuring", "processing_timeout",
    ]
    assert organizer.calls == 1 and organizer.cancelled
