# YouCalendar 反馈接口 v1

VF-01 至 VF-05 · T4/T5/T8 · ET1/ET2/ET5

本契约用于 Android 和后端分别开发。输入是一次学习反馈和该学习日的相关任务快照，输出是可编辑的结构化草稿。用户确认后由 App 将反馈和历史保存在手机上。文字和音频路由已可在本机联调。 [Android 接入与验收指南](../verification/vf05-android-handoff.md)

## 请求与版本

| 路径 | 请求体 | 成功受理后 |
|---|---|---|
| `POST /v1/feedback/text` | `application/json`，包含 `context` 和非空 `text` | `200`，UTF-8 SSE，返回同一种反馈草稿 |
| `POST /v1/feedback/audio` | `multipart/form-data`，各一个 `metadata`（UTF-8 JSON）和 `audio`（二进制）部分。`metadata` 包含 `context` | `200`，UTF-8 SSE，在整理前报告识别阶段 |

两条路由使用反馈服务的 `Authorization: Bearer <token>`。供应商密钥只配置在服务端。音频字节单独传输，JSON Schema 只定义 `metadata`。代理及供应商 SDK 的正文留存在云端接入前核验。

VF-04 本机演示接收 16 kHz、16 位、单声道 PCM WAV，最长 60 秒。`metadata` 部分使用 `application/json`，上限 1 MiB。`audio` 部分使用 `audio/wav` 或 `audio/x-wav`，上限 2 MiB。完整 multipart 请求上限为 3 MiB 加 8 KiB。每部分各一个，元数据和音频以实际内容校验。

损坏或截断的表单及 WAV、元数据解析失败、上传超时返回 `400 invalid_request`。媒体类型或采样参数不符返回 `415 unsupported_media_type`。字节或时长超限返回 `413 payload_too_large`。全零样本和空识别文本在 `recognizing` 阶段以 `unusable_audio` 结束。默认上传、识别和整理各有 15 秒期限。 [本地验证](../verification/vf04-local-audio.md)

| 字段 | 含义 |
|---|---|
| `context.ref.schema_version` | 严格整数 `1`。不兼容的字段变更使用新版本 |
| `submission_id` | App 生成的一次逻辑提交 ID，同一次操作的重新请求保留该 ID |
| `attempt_id` | 每次实际发起请求生成的新 ID，用于隔离取消、重试和迟到结果 |
| `study_date`、`utc_offset` | App 选定的学习日 `YYYY-MM-DD` 与该日上下文的 UTC 偏移，例如 `+08:00`。日期以该快照为准，服务端遇到不同或无法判定的日期时设 `date_needs_confirmation` |
| `snapshot_revision`、`task_revision` | 手机生成并维护的版本号。相关任务集合、定义或进度变化时更新相应版本，以便收到结果和保存时发现快照过期 |
| `context.tasks` | 当前学习日与反馈相关的任务实例，每个 `task_id` 唯一。传标题、可选科目与时段标签、总量和单位、当前进度。允许空列表，用于仅整理总体复盘 |

任务 `planned_count` 和 `unit` 同时有值或同时为 `null`。计量使用非负整数与精确匹配的单位，例如 `题`。未量化任务的 `completed_count` 为 `null`。`text` 最多 8000 字符，每份任务快照最多 100 项。请求不需要账号实名、联系方式、全部历史或知识库资料。

## 草稿与确认规则

`result.draft.ref` 原样回显请求引用，`draft_revision` 初始为 `1`。草稿由 `changes`、`unmatched`、`date_needs_confirmation` 和 `summary` 组成。每项修改通过 `task_id`、`task_revision` 绑定原快照，`before` 是原打卡进度，`candidate` 是候选状态。`evidence` 使用反馈输入中的原句片段。音频整理时采用识别文本片段，App 直接呈现可编辑的结构化草稿。

| 场景 | 返回及确认规则 |
|---|---|
| 任务状态 | `pending` 表示待确认，候选不能把已存进度变成待确认。`completed` 表示完成，`partial` 表示部分完成，`not_completed` 表示该任务未做且须填写原因 |
| 有总量的任务 | 候选完成量是该任务的累计量。完成时等于总量，部分完成时严格介于零和总量之间，明确未做时为零。剩余量由总量减累计量 |
| 累计和新增 | `reported_quantity` 保留观察到的数量、单位与 `meaning`。`total` 直接用报告值，`increment` 在快照完成量上加报告值，待确认快照按零计算。部分完成且有总量时须有明确数量。明确全部完成或未做且任务唯一时，可由总量或零确定数量 |
| 数量歧义和不一致 | `unclear`、缺数量、单位不符、超总量或状态矛盾时填 `issues`。保留原数量片段，候选累计量和剩余量为 `null`，禁止据此写入进度 |
| 未完成缺原因 | 保留 `not_completed` 候选并添加 `missing_reason`，待用户补充。口语“没做完”可能指部分完成，需根据数量与语境判断 |
| 任务不唯一或未匹配 | 写入 `unmatched`。同名任务给出快照中可能的多个 ID，未知任务用空列表。由用户选择正确任务或明确舍弃该项 |
| 日期不确定 | `date_needs_confirmation` 为真时禁止应用。确认了不同学习日后，以对应日期的快照重新整理 |
| 已有打卡有变化 | App 显示 `before` 和 `candidate` 的差异，同页由用户确认。只有实际修改的任务加入保存事务，历史作为独立事件保留 |
| 未提及的任务 | 从 `changes` 省略，原有状态照常保留。未打卡的任务仍待确认 |

存在任何 `issues`、未匹配条目或日期待确认时，草稿为 `needs_user_input`。其余完整草稿为 `ready_for_confirmation`，由 App 展示并等待用户确认。两种状态均可编辑。编辑后，App 按原快照重新验证数量、状态、原因和差异，再按最新版本验证能否提交。只含总体复盘的草稿可以确认，完全空草稿视为非法输出。

服务端先校验结构和请求引用，再核对任务、版本、原打卡、量化规则、剩余量和文本证据。判断自然语言说的是哪个任务、哪一天、累计还是增量属于后续整理实现和效果评测。应用状态由用户确认和 App 本地事务决定。

## 进度与异常

通过请求的响应流发送 `Content-Type: text/event-stream`。每帧一行 `data: <单个 JSON 对象>` 加空行。客户端先缓冲完整 UTF-8 帧，再解析 `type` 和负载。可用 SSE 注释保活，不计入事件序号。每个 JSON 事件携带 `attempt_id` 和从 `1` 连续递增的 `seq`。

| 事件类型 | 顺序与负载 |
|---|---|
| `stage` | `received` 后，文字依次发 `structuring`、`validating`，音频在整理前增加 `recognizing`。阶段在对应工作开始时发出 |
| `result` | 最后一个事件，携带校验通过的完整 `draft`。App 只在完整解析且版本仍有效时展示此次草稿 |
| `error` | 已开始传输后发生错误时，发一次终止事件，携带稳定的 `code`。连接已断开时由客户端识别未完成 |

例如文字请求的第一帧为 `data: {"type":"stage","attempt_id":"demo_text_attempt_01","seq":1,"stage":"received"}`，紧跟一个空行。成功时在验证阶段后结束。`error` 可在 `received` 后任意处理阶段结束流程。`unusable_audio` 提示重录或用文字，`asr_failed`、`provider_failed`、`processing_timeout`、`internal_error` 允许在条件恢复后手动重试。`invalid_output` 表示输出为空、不完整或不满足契约。该请求的中间事件均不能成为草稿。

受理前的 HTTP 错误返回 JSON，包含 `code`，已知时可附 `attempt_id`。错误体、日志和追踪字段使用稳定错误码，避免回显原文、音频、校验输入值和上游异常正文。

| HTTP 状态 | `code` | 客户端处理 |
|---|---|---|
| 400 | `invalid_request` | 检查字段或刷新任务快照 |
| 401 | `unauthorized` | 修复凭据后重试 |
| 413 / 415 | `payload_too_large` / `unsupported_media_type` | 缩短输入、调整格式或使用文字 |
| 429 | `rate_limited` / `budget_exhausted` | 按限流条件等待或等待额度恢复 |
| 503 | `service_unavailable` | 服务恢复后手动重试 |

## 断连、重试与手机端保存

| 场景 | 预期行为 |
|---|---|
| 终止帧前断流、截断、取消或超时 | 本次草稿未收到。App 保留输入和原有草稿，明确提示重试。主动取消后忽略该 `attempt_id` 的结果 |
| 重复点击生成或旧请求迟到 | App 对一次提交只保留一个活跃请求。手动重试使用相同 `submission_id` 和新 `attempt_id`，只处理当前活跃请求的事件。服务端重试可能再次计费 |
| 请求期间任务或进度变化 | App 收到草稿时与最终确认时都检查 `snapshot_revision` 和相关 `task_revision`，过期则停止应用并要求重新核对 |
| 确认后保存失败 | 保留用户已编辑的同份草稿和同一个本地 `application_id`。重试本地事务，无需重新生成 |
| 重复确认或保存成功后重启 | v1 约定在同一手机档案内用 `submission_id` 作为 `application_id`。同一次确认在同一事务写入进度、历史和提交记录，键唯一。已提交的相同内容返回既有结果；已提交的不同内容需要新提交。检查已有提交记录后再对未提交操作检查版本 |

App 保存时写候选累计量。即使原话说“又做了 4 题”，也保存经确认的累计 12 题。反馈确认与后续计划确认分别执行。后端按当前请求处理，个人草稿与正式记录保留在 App。

## 样例与可执行校验

结构定义见 [feedback-v1.schema.json](feedback-v1.schema.json)。校验单项数据时引用该文件 `$defs` 中对应的根 `text_request`、`audio_context`、`http_error`、`sse_event`，保留同文件的其他定义供 `$ref` 解析。结构校验之外，日期、请求与结果关联、累计运算和事件顺序由契约校验代码执行。

样例在项目的 `tests/fixtures/feedback/`。`text-request.json` 和 `text-events.json` 是一对完整的文字请求和已解码 SSE 事件。`audio-context.json` 是音频 `metadata`，`audio-events.json` 是配合合成 WAV 的完整事件序列。`review-cases.json` 的每一项替换文字请求的 `text` 和完整样例中草稿的同名字段，保留原引用与修订号。`error-cases.json` 包含 HTTP 状态与错误体和独立的流式错误样例。所有内容均为合成数据。

HTTP 路由定义见 [OpenAPI 快照](youcalendar.openapi.json)，运行时由 `GET /openapi.json` 提供相同内容。SSE 响应的 `x-sse-event-schema` 引用每帧 `data:` 内的 JSON 结构。客户端需要按 UTF-8 流读取帧。429 保留给配置了服务限额的环境，当前本机演示只实现 400、401、413、415、503 的受理前错误。

从项目根目录用 PowerShell 7 生成和校验。

```powershell
& '.\.venv\Scripts\python.exe' -X utf8 -m server.contracts.export_feedback_schema |
    Set-Content -LiteralPath 'docs\contracts\feedback-v1.schema.json' -Encoding utf8NoBOM
& '.\.venv\Scripts\python.exe' -X utf8 -c 'import json; from server.api import app; print(json.dumps(app.openapi(), ensure_ascii=False, indent=2))' |
    Set-Content -LiteralPath 'docs\contracts\youcalendar.openapi.json' -Encoding utf8NoBOM
& '.\.venv\Scripts\python.exe' -X utf8 -m pytest -q tests/test_feedback_contract.py
```

本地验证覆盖契约、样例及真实本机 HTTP 字节流。腾讯云合成语音识别已单独试验。代理转发和 Android 真机录音、草稿编辑及事务保存待接入验收。 [音频本机验证](../verification/vf04-local-audio.md) · [腾讯云实测记录](../verification/vf04-tencent-asr.md)
