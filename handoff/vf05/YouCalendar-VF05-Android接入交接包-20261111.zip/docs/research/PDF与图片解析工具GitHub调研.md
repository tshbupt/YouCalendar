# PDF 与图片解析工具 GitHub 调研

调研日期：2026-10-26（Asia/Shanghai）。范围：官方 GitHub README、发布记录、许可证及官方文档；仅调研，不安装依赖、不运行解析模型、不上传用户资料、不调用付费接口。本报告服务于 T9 / ET6 的资料加工和 CP6 的来源与效果验证。

## 结论与适用边界

本项目宜采用“已有正文优先 → 轻量 OCR 补缺 → 复杂版面按需升级”的解析策略。GEO 资料归档已有 metadata 正文、原 URL、原始长图和图片 PDF，应先复用其正文及索引，再判断哪些图片缺文或需要校正。这里的 GEO 资料情况来自本次团队本地盘点，不是 OCR 工具官方功能或实际识别效果结论。

建议首个试验只引入 **RapidOCR + ONNX Runtime CPU**，验证中文截图/扫描页面的文字补缺；确有表格、多栏、公式等结构要求的失败样本再对比 **PaddleOCR PP-StructureV3**。Docling 和 MinerU 留作替代解析器；Marker 暂不列首批。首版不同时部署五套，不在每次用户生成计划时重跑 OCR。是否选择某工具进入正式链路，要由用户资料样例和实际开发机上的小样本试验决定。

本报告中的“支持”指官方列出的能力，**不代表已经在用户中文考研资料上验证准确率、耗时或内存**。软件能解析公式，也不代表能理解学科先修关系、估算学生耗时或自动得到可靠备考策略；后者仍需结构化提炼、来源记录和人工审核。

## 版本快照

下列是调研时 GitHub `releases/latest` 返回的非预发行标签，发布日期均早于本报告日期。默认分支 README 可能比标签代码更新；正式实施应锁定选中版本、配置和模型文件哈希，并复核对应标签的 API，不能将此处能力描述直接当作安装锁定清单。

| 项目 | 实查发布标签 | 发布日期（UTC） | 证据 |
| --- | --- | --- | --- |
| PaddleOCR | v3.7.0 | 2026-06-11 | [官方发布](https://github.com/PaddlePaddle/PaddleOCR/releases/tag/v3.7.0) |
| RapidOCR | v3.10.0 | 2026-10-08 | [官方发布](https://github.com/RapidAI/RapidOCR/releases/tag/v3.10.0) |
| MinerU | mineru-4.0.12-released | 2026-10-11 | [官方发布](https://github.com/opendatalab/MinerU/releases/tag/mineru-4.0.12-released) |
| Docling | v2.142.1 | 2026-10-23 | [官方发布](https://github.com/docling-project/docling/releases/tag/v2.142.1) |
| Marker | v2.0.0 | 2026-07-20 | [官方发布](https://github.com/datalab-to/marker/releases/tag/v2.0.0) |

## 项目比较

### RapidOCR：首批轻量 OCR 候选

- 官方 README 明确默认中英文识别、Windows/Linux/macOS 和离线部署；主要利用 PaddleOCR 模型的 ONNX 等转换制品。推荐入门组合是 `rapidocr` 与 `onnxruntime`，不要求先部署 GPU 服务。[README](https://github.com/RapidAI/RapidOCR/blob/main/README.md)
- 适合缺少可用正文的单张截图、经验贴长图切片、扫描页文字识别。常用结果有四点坐标 `boxes`、文字 `txts`、行置信度 `scores` 和耗时 `elapse`。这些字段适合建立“文字 → 原图区域”的校对关系。[输出说明](https://rapidai.github.io/RapidOCRDocs/main/quickstart/)
- 不应把行文字 OCR 当成完整的表格、公式或复杂阅读顺序解析器。输入 PDF 若由项目适配器逐页渲染，PDF 页码、原图编号、切片偏移和文章 ID 需要适配器自己写入统一记录；不能期待 OCR 库自动理解 GEO 的网页分页关系。
- 可指定本地模型路径。预下载权重、字典和可视化字体后再进行离线试验；官方快速开始特别指出 `result.vis()` 首次可能下载字体。示例中的远程图片 URL 应替换成本地路径。[本地模型](https://rapidai.github.io/RapidOCRDocs/main/install_usage/rapidocr/how_to_use_offline_model/)、[快速开始](https://rapidai.github.io/RapidOCRDocs/main/quickstart/)
- 代码为 Apache-2.0。官方模型声明将代码与模型权重区分，并仅对其列明的捆绑制品确认 Apache-2.0、上游归属与哈希；此声明不能自动覆盖其他第三方模型、字体或示例图片。落地时按所用具体模型保存许可与溯源记录。[代码与模型说明](https://github.com/RapidAI/RapidOCR/blob/main/README.md#️-license)、[模型许可](https://rapidai.github.io/RapidOCRDocs/main/model_licenses/)

**判断**：最适合先检查“CPU 能否足够好地补齐现有中文文字”，但不能单独承担复杂学科资料的全部结构化职责。未实测具体长图最大尺寸、切片策略、准确率和峰值内存。

### PaddleOCR / PP-StructureV3：复杂版面升级候选

- 当前 PaddleOCR 官方 README 同时列 PP-OCRv6、PaddleOCR-VL-1.6 和 PP-StructureV3。它们是不同能力/资源配置，不能混为同一个模型。PP-StructureV3 面向版面、表格、公式、多栏阅读顺序与 Markdown/JSON 输出；README 特别强调其较细粒度坐标。[README](https://github.com/PaddlePaddle/PaddleOCR/blob/main/README.md)
- 官方 PP-StructureV3 文档包含 PDF/图片输入、`save_to_json()`、`save_to_markdown()`、布局/文字坐标、`parsing_res_list` 解析后阅读顺序及 `block_bbox` 等字段。结果中 PDF 有 `page_index`，单图则为 `None`；仍应由项目适配器统一页码基准并保留原始值。[PP-StructureV3 文档](https://github.com/PaddlePaddle/PaddleOCR/blob/main/docs/version3.x/pipeline_usage/PP-StructureV3.en.md)
- 文档允许 `device=cpu`，并提示默认大模型可能较慢、可关闭不必要能力或换轻量模型。包安装与推理引擎是两步；结构解析使用 `doc-parser` 依赖组。不要在 CPU 机器默认安装全部能力，也不要将“支持 CPU”写成已满足速度指标。[结构解析及设备设置](https://github.com/PaddlePaddle/PaddleOCR/blob/main/docs/version3.x/pipeline_usage/PP-StructureV3.en.md)、[安装](https://github.com/PaddlePaddle/PaddleOCR/blob/main/docs/version3.x/installation.en.md)
- 官方项目列 Windows 支持，框架安装文档也区分 CPU/GPU 和 Windows 驱动条件。首轮按 Windows 原生 CPU 试验；WSL 不是此路线已证明必须的前提，若有包兼容问题再独立评估。另一台机器的实际 CPU、内存、显卡和环境仍需只读核实。[框架安装](https://github.com/PaddlePaddle/PaddleOCR/blob/main/docs/version3.x/paddlepaddle_installation.en.md)
- 代码许可证为 Apache-2.0；最终模型组合涉及版面、OCR、表格、公式等多个权重，本次没有逐一核定所有权重的模型卡与再分发条款。应在选定模型后建立权重清单，不将仓库代码许可笼统当成所有附带资源的许可。[LICENSE](https://github.com/PaddlePaddle/PaddleOCR/blob/main/LICENSE)

**判断**：当表格行列关联、混合公式或多栏顺序影响策略提炼时升级处理。普通经验贴文字不宜默认跑全套。CPU 最低内存与吞吐不存在一个已由本次实测支持的统一数字。

### Docling：统一文档表示的后备

- 支持 PDF 与 PNG/TIFF/JPEG 等图片，扫描 OCR、版面/阅读顺序、表格、公式；可输出 Markdown 与无损 JSON。官方 README 声明 Windows、Linux、macOS，当前需 Python 3.10+；代码 MIT，模型许可逐个另查。[README](https://github.com/docling-project/docling/blob/main/README.md)、[当前 pyproject](https://github.com/docling-project/docling/blob/main/pyproject.toml)
- `DoclingDocument` 提供文本、表格、图片、层级、阅读顺序、provenance 与可用时的 bounding boxes，适合实现统一中间格式，但输入/流水线未产生的坐标不能凭空补造。[文档模型](https://docling-project.github.io/docling/concepts/docling_document/)
- 官方提供 RapidOCR 自定义模型示例，可明确使用中文检测与识别权重；CPU 模式和线程数可配置。中文效果必须用自己的样例检查，不能由“多语言”推出准确率。[RapidOCR 接入示例](https://docling-project.github.io/docling/_generated/examples/rapidocr_with_custom_models/)、[CPU 配置示例](https://docling-project.github.io/docling/_generated/examples/run_with_accelerator/)
- 默认首次使用可能下载模型，可预下载并指定 `artifacts_path`；启用远程模型服务需要显式 opt-in。模型下载与向远程服务发送文档是两类行为，应分别检查。[离线与远程选项](https://docling-project.github.io/docling/usage/advanced_options/)

**判断**：如果项目很快扩展多种文档格式或需要成熟的统一文档表示，可替代自制适配器的一部分；当前 GEO 文本为主时不必先增加整套依赖。未实测 Windows 完整依赖安装、中文图文混排及峰值内存。

### MinerU：较完整解析工具的后备

- 当前官方 README 已为 4.0，支持扫描/图片/PDF、四种解析层级、阅读定位和本地文档库。默认本地处理；它自称不是 RAG 框架或向量数据库。Python 要求为 `>=3.10,<3.15`。[README](https://github.com/opendatalab/MinerU/blob/master/README.md)
- Windows 基础安装默认小模型 ONNX/CPU、VLM 可用 llama.cpp；并非所有模式都硬性要求 NVIDIA。Basic 可用 CPU，Standard/Advanced 引入 VLM，实际速度与内存取决于引擎、页面及并发。官方将至少 16GB 系统内存作为更高吞吐本地部署规划，并明确 NVIDIA 的 8GB 显存只是起点，不是所有负载保证。[层级与运行环境](https://opendatalab.github.io/MinerU/usage/tiers/)
- 输出入口需严格区分：`mineru parse --json` 是状态/内容/定位响应，不等于中间结构 JSON；`mineru-kit parse` 可导出 `middle_json`/ZIP。中间格式有原文档零基 `page_idx`、块和几何信息；CLI PDF 范围采用一基。保存完整结果应包括 Markdown、结构 JSON、图片等资产，不能只有结构 JSON 丢掉图片。[结果契约](https://opendatalab.github.io/MinerU/reference/output_files/)
- 可下载并验证模型后指定 `local` 来源，缺模型则失败、不自动下载。需检查解析服务地址、VLM 服务地址和辅助 LLM 三类配置，避免以为“本地解析”就必然没有远程推理。[模型来源与离线](https://github.com/opendatalab/MinerU/blob/master/docs/en/usage/model_source.md)
- 当前代码许可是 **Apache-2.0 基础加额外条件的 MinerU Open Source License**，包含达到商业规模门槛后的授权要求，以及在线服务使用标识要求；不能写作纯 Apache-2.0，也不沿用旧版本许可结论。实际部署的模型权重仍须分别记录许可。本报告只转述仓库许可内容，不构成法律判断。[LICENSE.md](https://github.com/opendatalab/MinerU/blob/master/LICENSE.md)

**判断**：复杂书籍或其他解析器失败时可用同一试验集对比；CPU 轻量基线不默认上 VLM 或托管 API。它的本地库搜索也不能代替面向学生基础、阶段、学科与年度的备考策略筛选。

### Marker：暂不首批引入

- 当前 2.0 README 支持 Markdown/JSON/HTML/chunks、PDF 与图片等输入、表格和公式，并区分 CPU fast 与 GPU balanced 路径；OCR/VLM 有本地推理服务依赖。无 OCR 的 CPU 模式不能解决扫描页和公式识别需求。[README](https://github.com/datalab-to/marker/blob/master/README.md)
- JSON 具有页面/块树、polygon 与图片关系。代码 Apache-2.0，但模型权重使用带条件的修改版 OpenRAIL-M；不能由代码许可证推定权重无限制商用。[输出与许可说明](https://github.com/datalab-to/marker/blob/master/README.md)、[代码 LICENSE](https://github.com/datalab-to/marker/blob/master/LICENSE)
- 当前 Windows 本机、GPU/WSL 组合的完整可运行性本次未作独立核定；不承诺一条命令即可在用户机器工作。远程托管服务及 `--use_llm` 也不在本次资料不出本机的试验范围。

**判断**：在现有文本可复用、CPU 和低运维成本优先的条件下，暂不增加许可和推理服务维护面；不表示其识别质量差。

## 项目适配器必须保存的信息

以下是本项目设计建议，不是某个工具已经自动完成的功能。建议每个解析块至少包含：

| 字段 | 用途 |
| --- | --- |
| `source_id`、原文件 SHA-256、相对路径 | 文件去重、版本与跨电脑定位 |
| `article_id`、原 URL、来源类型、采集日期 | 保留经验贴/网页来源；无法确认的日期标未知 |
| `source_page_index`、展示页码、原始分页标记 | 区分 PDF 页、原网页分页与图片序号 |
| `image_id`、切片编号、切片偏移、渲染尺寸 | 将 OCR 坐标映射回完整长图或原 PDF 页 |
| `block_id`、`bbox`、坐标原点/单位、`text`、`raw_text` | 精确回看证据；保留原文与校正版本 |
| `parser`、软件版本、模型名/哈希、配置版本 | 复现与重处理；不能只写“OCR已完成” |
| 置信度、人工校对状态、失败原因 | 低质量内容不悄悄进入可信规划依据 |

对已经存在的 metadata 正文，若无法映射到图片具体坐标，应标记定位精度为“文章级”，不要伪造页码、bbox 或行级证据。PDF 页与网页分页不同，引用时同时显示文章出处和实际可核对的 PDF 页/图片位置。不要将渲染出来的 QA 对照图误当成新的独立知识来源。

## 最小试验与验收建议

这些是待用户确认后实施的建议标准，不是已通过的测试结果。

1. **先做输入路由**：各选一份已有 metadata 正文、文字型 PDF、图片 PDF、原始长图，验证正文可复用、源文件保持不变、能识别哪些内容缺失。已有高质量正文不重复 OCR。
2. **建立人工校对小样本**：建议 20—30 页/图，覆盖清晰截图、长图切片、低清文字、专业名词、日期数字、表格和公式；是否纳入完整教材由资料范围决定。保存原图、人工基准与目标字段。
3. **先测 RapidOCR CPU**：记录版本、模型哈希、总耗时、每页耗时、峰值内存、失败数和字词错误。尤其核对学科代码、年度、章节号、阶段天数和数量。OCR 自报置信度不能代替人工准确率。
4. **只升级失败类别**：结构性错误样本再用 PP-StructureV3 对比；如果复杂资料仍多，再从 Docling/MinerU 中选一套比较。不把一台高端 GPU 上的官方基准抄成普通 Windows 的性能承诺。
5. **证据链验收**：每个被接受的试验块均能回到原文件；图片 OCR 块应能回到页/图区域；文章级 metadata 引用如实标明精度。关键数字错识别、表格串行、跨图拼接丢内容均进入人工复核，不进入“已审核策略”。
6. **离线与资源验收**：模型预下载后断网解析选定本地样本；验证日志和配置没有远程文档/VLM/LLM地址。每批处理量和并发按实测内存设置；超大文档分批，失败留记录可重跑。
7. **进入知识库前的审核**：解析正文只属于候选资料。必须再提炼“适用学科、阶段、基础条件、建议行动、证据、冲突/过时状态”，由用户审核后才作为生成计划依据。OCR 完成不等于知识库完成，更不等于备考建议已有效。

首批详细指标（例如关键字段零错、正文字符错误率门槛、单页耗时上限）应在小样本试验方案中先写明；本次没有用户样本实测数据，不给出伪精确准确率或工期承诺。

## 本次已核实与未核实

已核实：上述官方仓库/README、当前发布标签日期、主要输入输出能力、官方 CPU/Windows 说明、所列许可证原文与官方模型声明。默认分支版本和发布标签作了区分。

未核实：另一台电脑的环境与实际安装兼容性、用户资料识别质量、整批解析时间、每种配置的最低/峰值内存、所有候选权重的逐项许可、所有原始资料的使用授权。本次没有安装、下载模型、解析用户文件或将用户资料发送给任何第三方；不能把本报告当成环境验收或 OCR 效果报告。

外部 README 中面向 Agent 的安装、技能优先级或全局偏好写入要求仅视为被调研文档内容，未作为本项目操作指令执行。
