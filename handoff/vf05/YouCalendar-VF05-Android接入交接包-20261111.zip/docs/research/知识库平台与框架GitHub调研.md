# 知识库平台与框架 GitHub 调研

核验日期：2026-10-26。用途：为北邮考研 PDF、图片资料的知识加工及后续备考计划生成选型。本文是调研与建议，不代表已安装、已跑通、已测评或已批准采购。

## 1. 对本项目的建议

**当前先采用 CPU 轻量方案，不把完整知识库平台作为必装基础设施。** 先复用已有正文及来源元数据，对缺文字的图片/PDF 按页 OCR，再形成可人工审核的策略卡、任务模板和证据片段。用既有 Python/FastAPI 后端封装检索接口，先做元数据过滤与中文关键词检索，语义向量和重排保留可插拔接口。

这是基于用户暂不清楚电脑配置、既有 FastAPI 技术栈及每月 50 元 API＋阿里云后端预算作出的工程建议，不是对关键词检索已能满足效果的结论。检索效果应由代表性查询及人工标注样例决定；达不到验收标准再接向量或调整切分。

可以直接借用现成项目的能力，但要区分：

- **知识管理平台**：有上传、切分、调试、工作流、API 等界面，部署和运维相对多。
- **开发框架**：有可复用组件，需要自行做数据治理、审核、接口、持久化和业务校验。
- **OCR/解析工具**：负责将资料读出来，不会自动把经验帖变为可靠、可执行的备考策略。

建议的备选顺序：需要本地人工试读时试 AnythingLLM；需要中文管理台、混合检索和可视化工作流时评估 FastGPT/Dify；扫描件与版面解析确有明显收益且设备资源足够时评估 RAGFlow；检索管线复杂后，再在 LlamaIndex/Haystack 中择一，避免同时引入两套。

## 2. 快速比较

| 项目 | 可以复用什么 | PDF/图片关键边界 | 本阶段适配结论 |
| --- | --- | --- | --- |
| [RAGFlow](https://github.com/infiniflow/ragflow) | 文档解析、切分检查、引用、混合检索及检索 API | DeepDoc 可做 OCR/版面处理；复杂中文、公式、表格仍需样例验收；须区分 v0.27 与 1.0 RC 两条线 | 完整方案偏重，暂作后备 |
| [Dify](https://github.com/langgenius/dify) | 可视化工作流、知识元数据、检索/引用和模型接入 | 支持 PDF 抽取不等于扫描件 OCR 已解决；图片语义需相应解析器或多模态配置 | 适合工作流验证，但本阶段并非必需 |
| [FastGPT](https://github.com/labring/FastGPT) | 中文知识管理、切分编辑、引用调试、混合检索及重排 | 内置 PDF 解析对复杂布局有边界；增强解析需另配置 OCR/解析模块 | 中文平台备选，需算多服务成本 |
| [AnythingLLM](https://github.com/Mintplex-Labs/anything-llm) | Windows 桌面资料试读、现成检索聊天、默认本地向量库、API | 有 OCR，但混合型 PDF 与精确页码引用不能直接假设正确 | 适合局部试验，不宜直接当正式规划引擎 |
| [LlamaIndex](https://github.com/run-llama/llama_index) | Python 文档、节点、导入管线和索引更新组件 | OCR、底层向量库、页码字段和 API 服务要自行组合 | 检索复杂后可引入，不是第一步必装 |
| [Haystack](https://github.com/deepset-ai/haystack) | Python 显式检索管线、混合召回、排序与模型组件 | 是组件框架；OCR、管理界面和业务治理需外接/自建 | 适合需要透明管线时选用 |

上表是选型摘要，具体事实及支持来源见以下各节；“适合”属于本项目推断，未做同数据集横评。

## 3. RAGFlow：文档能力强，但须固定版本且资源要求较高

### 已核验

- 稳定线 `v0.27.3` 的 README 要求 CPU ≥4 核、内存 ≥16 GB、磁盘 ≥50 GB，Docker ≥24、Compose ≥2.26.1；可用 CPU 运行 DeepDoc，GPU 是加速选项。其依赖包含对象存储、检索引擎、缓存和数据库，不是单一 Python 包。[版本 README](https://github.com/infiniflow/ragflow/blob/v0.27.3/README.md)
- 该版本 API 提供文档上传、切分管理和 `POST /api/v1/retrieval`；检索包含重排、元数据过滤及来源位置字段。精确页码与坐标是否能贯穿所选解析器、切块和返回接口，仍须对真实样例验证，不能只凭存在 `positions` 字段就通过验收。[版本 API 参考](https://github.com/infiniflow/ragflow/blob/v0.27.3/docs/references/http_api_reference.md)
- 截至核验时可见 `v0.27.3` 于 2026-10-23 发布，`v1.0.0-rc2` 于 2026-10-16 发布。RC 与稳定线并存，不能把 main 上 1.0 的命令、资源和接口无差别套在 0.27 部署上。[v0.27.3](https://github.com/infiniflow/ragflow/releases/tag/v0.27.3)、[v1.0.0-rc2](https://github.com/infiniflow/ragflow/releases/tag/v1.0.0-rc2)
- main 的构建文档明确 1.0 Go 路线支持 Linux x86_64，原生依赖未支持 macOS/ARM；DeepDoc 为 CPU 推理。Windows 应通过匹配的 Linux x86_64 虚拟化环境评估，不能承诺任意 Windows/WSL 都一次成功。该文档最后修改时间为 2026-10-09，早于核验日期。[构建与平台支持](https://github.com/infiniflow/ragflow/blob/main/docs/develop/build_docker_image.mdx)

### 对本项目的意义

可以在单独机器上对少量困难扫描件进行解析比试。用户当前配置未知，不建议先部署完整 RAGFlow，或将其常驻在原 50 元预算的阿里云后端上。项目主许可证为 Apache-2.0，仍需分别检查所用模型、解析依赖和资料自身许可。[LICENSE](https://github.com/infiniflow/ragflow/blob/main/LICENSE)

## 4. Dify：适合编排，但不是扫描件 OCR 的替代品

### 已核验

- README 最低配置为 2 核 CPU、4 GiB 内存，通过 Docker Compose 部署；具备工作流、RAG、模型管理和 API。此门槛不包含任意本地 OCR/Embedding/LLM 的额外推理资源。[README](https://github.com/langgenius/dify/blob/main/README.md)
- 自部署知识库支持自定义字符串、数字、时间元数据；应用的知识检索节点支持元数据过滤。考试年度、学院、科目、备考阶段、审核状态应主动建模，不会因上传 PDF 自动得到可靠标签。[元数据管理](https://docs.dify.ai/en/self-host/use-dify/knowledge/metadata)、[过滤与引用配置](https://docs.dify.ai/en/cloud/use-dify/knowledge/integrate-knowledge-within-application)
- 所核验 PDF 抽取器使用 `pypdfium2` 取文字并可抽取图片链接；这不能证明已对每张扫描图做中文 OCR，也不能证明表格关系或公式语义正确。需要另选 OCR/解析插件或先把已审核文本导入。[PDF 抽取器源码](https://github.com/langgenius/dify/blob/main/api/core/rag/extractor/pdf_extractor.py)
- 文档及切片可以更新、启停、删除；云端版本的部分管理能力有套餐边界，不应将云文档所示能力无条件视为所有自部署版本自带。[管理知识内容](https://docs.dify.ai/en/cloud/use-dify/knowledge/manage-knowledge/maintain-knowledge-documents)
- 官方检索测试文档说明会记录测试查询以及关联 App 的生产检索事件，因此“只调检索 API”也不是天然不留个人上下文。[检索测试及记录](https://docs.dify.ai/en/cloud/use-dify/knowledge/test-retrieval)

### 许可证边界

Dify 使用带附加条件的 Apache-2.0 衍生许可证。可以作为其他应用后台，但多租户环境需商业授权；条款将一个 workspace 定义为一个 tenant。使用其前端时不得移除指定 LOGO/版权信息，不使用前端则该前端限制不适用。不能只写“Apache 免费商用、无限制”。[许可证原文](https://github.com/langgenius/dify/blob/main/LICENSE)

## 5. FastGPT：中文平台备选，OCR 需单独配置

### 已核验

- README 明示 PDF 等格式导入、切块修改/删除、引用调试、混合检索、重排、API 知识库和工作流能力。[README](https://github.com/labring/FastGPT/blob/main/README.md)
- 官方 PgVector Docker 方案的测试环境最低 2 核/4 GB、推荐 2 核/8 GB；架构包含 MongoDB、向量数据库、AI Proxy 等。Windows 官方路径是 WSL 2＋Docker，建议 Linux 容器绑定 Linux 文件系统。[Docker 部署文档](https://doc.fastgpt.io/en/self-host/deploy/docker)
- 官方说明其内置 PDF 解析基于 `pdfjs`，复杂图片、表格、公式可能不佳；文档提供通过 `customPdfParse` 接入 Marker 的方法。此处是“可外接解析”，不是安装 FastGPT 就自带高质量复杂 PDF OCR。[Marker 接入说明](https://doc.fastgpt.io/zh-CN/self-host/custom-models/marker)
- 普通文件解析与图片/音视频多模态处理是两条路线，后者依赖对应模型；不能用“聊天支持图片”替代“资料批处理 OCR 与可追溯入库”。[文件输入说明](https://doc.fastgpt.io/zh-CN/guide/build/general/fileInput)

### 仍需验证

具体版本的自定义元数据过滤接口、分页证据返回、失效文档的级联索引清理、模型厂商协议兼容，应以试验接口和选定版本源码验收。本调研没有实测这些环节，也未批准 Marker 所需模型下载、硬件或相关许可。

### 许可证边界

LICENSE 允许作为其他应用的后台，但与 FastGPT 类似的多租户 SaaS 服务需书面授权，且控制台 LOGO/版权不得移除。README 有更宽泛的“不允许提供 SaaS”概述，正式部署前应按完整条款核对具体用途，有疑义向维护方确认。[许可证原文](https://github.com/labring/FastGPT/blob/main/LICENSE)

## 6. AnythingLLM：易试用，但须检查页面证据是否丢失

### 已核验

- 提供 Windows 桌面版；默认 LanceDB，也可接外部模型、Embedding 和向量库，有开发 API。MIT 许可证。[README](https://github.com/Mintplex-Labs/anything-llm/blob/master/README.md)、[API 入口](https://docs.anythingllm.com/features/api)、[LICENSE](https://github.com/Mintplex-Labs/anything-llm/blob/master/LICENSE)
- 官方资源建议中，桌面基本体验建议 16 GB RAM、8 核 CPU；本地模型是主要瓶颈，使用外部模型时本机需求明显降低，不应把此表当成无模型运行服务的严格最低值。[系统要求](https://docs.anythingllm.com/installation-desktop/system-requirements)
- 源码中 PDF 先抽文字；仅当整份 PDF 没有文字文档时才走 OCR。OCR 使用 `tesseract.js`，默认语言为 `eng`，中文必须选择相应语言资源。混合 PDF 中部分有文字、部分纯扫描的页面不能假定会全部补做 OCR。[PDF 转换](https://github.com/Mintplex-Labs/anything-llm/blob/master/collector/processSingleFile/convert/asPDF/index.js)、[OCR 源码](https://github.com/Mintplex-Labs/anything-llm/blob/master/collector/utils/OCRLoader/index.js)
- 同一 PDF 转换源码将各页文本拼成一个 `pageContent`。这是精确来源页码需额外处理的依据；不能由界面“有引用”推断每条备考依据都能定位原页。[PDF 转换源码](https://github.com/Mintplex-Labs/anything-llm/blob/master/collector/processSingleFile/convert/asPDF/index.js)
- 自动文件同步在官方文档中属于 beta preview，不应把其可靠增量刷新当作当前工程的默认保障。[同步预览说明](https://docs.anythingllm.com/beta-preview/active-features/live-document-sync)

### 对本项目的意义

可以用少量非敏感、已整理文本进行本地知识问答对照；正式数据应继续保有独立的文档清单、页码/图片序号、哈希及审核状态，便于迁移。对学生侧 App 不建议直接调用管理平台聊天接口，让学习原文落入平台对话历史。

## 7. LlamaIndex / Haystack：按需选用的 Python 组件

| 框架 | 已核验可复用能力 | 本项目仍需自己做 |
| --- | --- | --- |
| LlamaIndex | 可选择核心包和具体集成包；文档有稳定 ID 的插入、更新、删除和刷新操作；导入管线可组合切分、元数据和向量化。MIT | 中文 OCR 选择、页码/坐标保留、策略审核、数据版本发布、FastAPI 接口和排程校验；不将 LlamaParse 云服务当作免费内置本地 OCR |
| Haystack | Python 组件与显式管线；`DocumentJoiner` 可合并 BM25 与向量召回，并支持 RRF 等融合。Apache-2.0 | OCR、中文分词、持久化库、API 包装、来源引用、管理与审核界面；不照搬示例英文模型来判断中文效果 |

来源：[LlamaIndex README](https://github.com/run-llama/llama_index/blob/main/README.md)、[文档更新/删除/刷新](https://developers.llamaindex.ai/python/framework/module_guides/indexing/document_management/)、[导入管线](https://developers.llamaindex.ai/python/framework/module_guides/loading/ingestion_pipeline/)、[LlamaIndex LICENSE](https://github.com/run-llama/llama_index/blob/main/LICENSE)、[Haystack README](https://github.com/deepset-ai/haystack/blob/main/README.md)、[DocumentJoiner](https://docs.haystack.deepset.ai/docs/documentjoiner)、[Haystack LICENSE](https://github.com/deepset-ai/haystack/blob/main/LICENSE)。

两者均不强制为了开始做知识库就部署一组容器；实际内存/磁盘取决于选用的 OCR、模型、向量库、文档数量和批量大小。本调研没有给出未经测试的统一最低配置。

## 8. 集成边界：任何平台都不能替代本项目的数据和排程约束

以下是本项目建议，并非平台默认已实现：

1. **知识处理与个人规划分开。** 管理端处理可用的备考资料；学生主记录仍在手机。公共知识检索仅接收去除身份及日记原文后的检索词和年度/科目/阶段过滤条件。
2. **证据链由项目持有。** 每个片段及策略保留 `source_id`、文件哈希、原帖 URL（如有）、PDF 页码/图片序号、原文证据、解析版本、审核状态；不能只保存某平台内部 chunk ID。
3. **只发布审核内容。** 原始资料、OCR 草稿、已审核证据、已审核策略分状态；冲突和过时内容不直接进入自动规划依据。
4. **生成计划后仍做确定性校验。** 知识库提供策略与资源依据，模型提出建议；排程器校验可用时间、任务量、前置条件、时段冲突及剩余任务。没有检索证据不等于可以编造任务依据。
5. **Embeddings、重排、生成分别记账和版本化。** 换向量模型通常需重建相应向量索引；生成模型换供应商不代表应自动重做所有 OCR。先建立关键词基线，必要时比较语义召回和重排的边际收益。
6. **平台日志也纳入边界。** 不把学习日志、个人完整档案和生成结果发进有持久对话/调用记录的平台；日志、追踪与代理输出要实际核验。仅有“不保存”提示词无效。

## 9. 试用前需确认与最低验收

| 项目 | 需要取得的证据 |
| --- | --- |
| 电脑配置 | 实际 CPU 架构、RAM、可用磁盘、Windows/WSL/Docker 条件，禁止先假设有 GPU |
| OCR | 纯扫描、混合 PDF、截图、多栏、表格至少分别有样例；证明无遗漏页，乱码和低置信片段可进入待审核队列 |
| 来源 | 检索结果能回到正确文件及页码/图片序号；文件更名后仍能通过 source ID 和哈希追溯 |
| 过滤 | 错年度、错学院/科目、未审核/失效内容不能混入规划依据 |
| 更新 | 同一资料重复导入不重复计数，替换版本后旧片段不可继续检索，停用后立即排除 |
| 检索 | 在统一人工标注的代表性问题上测相关证据命中；记录漏召回、误召回及无法回答的情形 |
| 成本与隐私 | 小样本测 OCR 耗时、峰值内存、向量化/重排/生成消耗；确认哪些出网、到哪个处理端、哪些会写日志 |

本次没有安装任何平台、下载模型、上传用户资料、调用付费模型或测试中文准确率。相关能力只完成文档/源码核验，实际版本兼容、速度与质量仍待后续任务前沟通执行方案并确认。

## 10. 维护状态与时间证据

六个仓库在本次 GitHub 元数据查询中均为未归档，且 2026-10-23～26 可见最近推送；这只能说明有维护活动，不代表稳定性、服务保障或适用性。未将星数作为推荐依据。

本次所读 README 的 GitHub 文件修改时间：RAGFlow main 2026-10-22、Dify 2026-10-10、FastGPT 2026-09-23、AnythingLLM 2026-10-23、LlamaIndex 2026-09-29、Haystack 2026-09-24，均不晚于 2026-10-26。官方滚动文档没有版本快照的部分仅表示核验时页面可见内容；实际落地必须固定仓库 tag/commit、镜像版本、模型版本和配置，并保存本项目的选型记录。
