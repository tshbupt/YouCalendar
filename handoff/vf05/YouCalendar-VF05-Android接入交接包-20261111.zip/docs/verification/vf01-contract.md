# VF-01 接口契约与样例验证记录

2026-11-10 · 已交付并完成本地契约验证 · T4/T5/T8 · ET1/ET2/ET5

- [接口契约](../contracts/feedback-v1.md)定义文字请求、音频封装、共用草稿、HTTP 与 SSE 错误、确认及本地重试规则。
- [Pydantic 模型](../../server/contracts/feedback.py)校验字段、快照引用、数量规则、原文片段及已解码事件序列。[JSON Schema](../contracts/feedback-v1.schema.json)由模型生成。
- [合成样例](../../tests/fixtures/feedback/)包含文字成功、音频元数据、歧义、纠正原打卡、未匹配、日期待确认及失败流。[契约测试](../../tests/test_feedback_contract.py)执行这些样例并检验不可应用的结果。

## 已验证

在 Windows、Python 3.12.14、Pydantic 2.14.1、pytest 9.1.1 环境运行。

```powershell
& '.\.venv\Scripts\python.exe' -X utf8 -m pytest -q --tb=short tests/test_feedback_contract.py
& '.\.venv\Scripts\python.exe' -X utf8 -m pytest -q --tb=short
```

| 检查 | 结果 |
|---|---|
| 契约专项 | 33 项通过。验证 Schema 导出一致，样例通过 Pydantic 校验，非法类型、日期、引用、数量和事件顺序按预期被拒绝 |
| 全量回归 | 115 项通过，包含上述 33 项及已有的 82 项。已有 Starlette `TestClient` 对 `httpx` 的弃用提示，共 1 条警告 |

首次测试暴露了严格日期类型在 JSON 和已解码对象中的校验差异。契约改用 ISO 日期字符串和实际日期检查，并覆盖了无效日期及布尔值伪装版本号的场景。修正后两组测试均通过。

## 后续验收

VF-02 验证文字 HTTP 路由、真实 SSE 字节传输、鉴权、限额和断连。VF-03 验证真实模型能否正确理解任务、日期和数量。VF-04 验证音频格式、识别效果和数据处理边界。Android 接入后验证本机快照过期、重复确认、保存失败重试和重启读回。

本次用 Pydantic 执行样例校验并检查生成文件一致性。其他语言的 JSON Schema 校验和 Android 端兼容性在交接集成时验证。数据均为合成文本，本次新增云服务及供应商 API 费用为零。
