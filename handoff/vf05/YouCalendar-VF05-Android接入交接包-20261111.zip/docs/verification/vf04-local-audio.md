# VF-04 本机语音入口验证

2026-11-10 · 本机接入已完成 · T4/T8 · ET2/ET4

2026-11-11 已完成独立的[腾讯云合成语音实测](vf04-tencent-asr.md)。本文保留本机演示与候选筛选记录。

## 已实现

`POST /v1/feedback/audio` 接收 VF-01 的 `metadata` 和 `audio`，用独立反馈令牌鉴权。流式 multipart 解析使用 `python-multipart==0.0.33`，按字节将每部分直接写入有界内存，不调用表单临时文件机制。元数据上限 1 MiB，音频上限 2 MiB，完整上传上限 3 MiB 加 8 KiB。通过 WAV 文件头及样本校验实际采样参数。 [音频接收](../../server/speech/upload.py) · [解析器发布信息](https://pypi.org/project/python-multipart/0.0.33/)

音频经模拟识别后复用文字草稿的上下文、原话证据、数量和状态校验。SSE 依次报告受理、识别、整理、校验和结果。空识别、全零样本、超时和识别失败返回稳定错误码。客户端断连时取消正在等待的工作。 [音频路由](../../server/speech/route.py) · [共用反馈流程](../../server/feedback/stream.py)

当前 `FEEDBACK_MODE=demo` 使用固定合成信号演示。测试信号没有真实人声，模拟器只对这段信号返回预设的“上午高数一共做了12题”。 [演示命令](../../README.md#运行语音反馈本机演示)

## 实际验证

在 Windows 及 Python 3.12.14 环境执行。

```powershell
& '.\.venv\Scripts\python.exe' -X utf8 -m pytest -q --tb=short tests/test_feedback_audio.py tests/test_feedback_http.py
& '.\.venv\Scripts\python.exe' -X utf8 -m pytest -q --tb=short
```

| 检查 | 结果 |
|---|---|
| 接口与本机 HTTP 专项 | 28 项通过，其中 25 项为新增音频检查。覆盖正常草稿、令牌、静音、损坏及截断 WAV、错误采样参数、部分字段缺失或重复、超限、超时、空识别及无依据草稿 |
| 实际 TCP 与 SSE | 识别器仍在等待时收到 `recognizing`。关闭连接后在 2 秒内观察到识别器取消，整理器未进入。没有 `Content-Length` 的分块上传超过音频上限时返回 413 |
| 文件与日志边界 | 在阻止 Starlette 临时文件缓冲的测试条件下，演示成功。错误响应及测试日志未回显合成隐私标记 |
| 独立 Uvicorn 进程 | `curl.exe` 提交 8044 字节合成 WAV 和现有元数据样例，收到四个阶段和一个草稿，累计 12 题、剩余 8 题 |
| 全量回归 | 186 项通过，有 1 条既有 Starlette `TestClient` 依赖弃用提示 |

首次专项运行中，超长转写测试自动生成的用例名称超过 Windows 临时路径能力。改用短的用例名后重跑通过。

本机阶段外部识别调用为 0，费用为 0 元。手机录音格式、供应商取消与扣费行为、生产代理缓冲和数据留存分别在后续阶段验收。 [云端合成语音实测](vf04-tencent-asr.md)

## 云端候选核验

以下依据 2026-11-10 查阅的官方接口和公开条款。各家实际开通条件、费用和留存以所用产品、账号及接口适用条款为准。

| 候选 | 技术适配 | 数据处理待核实 |
|---|---|---|
| 腾讯云 ASR 一句话识别 | `SentenceRecognition` 和 `16k_zh` 支持短音频。用 `SourceType=1` 将 WAV 的 Base64 放入请求体，最长 60 秒，编码后不超过 3 MB，可选上海或广州接入域名 | 服务条款明确受托数据在中国大陆处理。产品 FAQ 说明传入语音供当次识别使用。服务条款另说明故障排查可能使用问题数据和相关音频，可联系售后撤回相应授权。真实用户接入前核实账号的排查授权、转写保留和适用范围。 [接口](https://cloud.tencent.com/document/api/1093/35646) · [接入域名](https://cloud.tencent.com/document/product/1093/35639) · [服务条款](https://cloud.tencent.com/document/product/301/94121) · [音频 FAQ](https://main.qcloudimg.com/raw/document/product/pdf/1093_35801_cn.pdf) |
| 阿里云智能语音交互一句话识别 | 支持上海、北京或深圳公网端点，PCM WAV、16 位单声道、16 kHz、最长一分钟。可直接上传 WAV 字节 | 接口文档未明确原音保留期限。商用开通说明要求确认用语音数据优化模型的授权，说明授权后三个月内不可取消。需先核对该账号适用条款。 [接口](https://help.aliyun.com/zh/isi/user-guide/restful-api-2) · [商用开通](https://help.aliyun.com/zh/isi/upgrade-speech-services-and-purchase-resource-plans) |
| 火山引擎豆包录音文件识别极速版 | `audio.data` 支持 Base64，支持 WAV，返回同步转写，需开通相应资源 ID | 本次查阅的接口说明未确定该调用的实际处理地区和原音保留条件。需进一步核实。 [极速版接口](https://docs.volcengine.com/docs/doubao-voice/large-model-recording-file-lite-recognition-api?lang=zh) |

建议优先试验腾讯云 `SentenceRecognition`。它的 16 kHz 中文短音频接口可以沿用当前 WAV 并在请求体中直接提交，且服务条款明确了大陆处理范围。第一批限 6 条在本机合成的中文语音，每条最多一次。按公开最低用量档的后付费单价 3.20 元/千次计算，6 次识别约 0.0192 元，实际以账户计费为准。建议本批费用上限 1 元，运行前核对凭据、计费与排查授权。真实用户录音另行核对使用范围及留存。 [腾讯云计费](https://cloud.tencent.com/document/product/1093/35686)
