# VF-02 文字反馈服务验证记录

2026-11-10 · 已实现并完成本机验证 · T4/T5/T8 · ET2/ET4

- `POST /v1/feedback/text` 接收 VF-01 文字请求，独立校验 Bearer 令牌、媒体类型和 1 MiB 请求体上限。受理前的失败返回 HTTP 错误码。服务配置通过 `FEEDBACK_MODE` 和 `FEEDBACK_API_TOKEN` 提供。见[文字路由](../../server/feedback/text.py)和[启动说明](../../README.md#启动文字反馈演示)。
- 受理后逐段发送 SSE。整理默认限时 15 秒，超时和断开都会取消正在等待的模拟整理器。返回的草稿由 VF-01 校验结构、快照、数量和原文片段。无法校验的草稿以 `invalid_output` 结束。见[接口契约](../contracts/feedback-v1.md)。
- 本地模拟器覆盖明确累计、明确新增、数量歧义和纠正原打卡四种固定句子。其他输入进入待匹配。预设结果用于验证服务行为。见[模拟整理器](../../server/providers/feedback.py)。

## 实际验证

在 Windows、Python 3.12.14、FastAPI 0.162.0、Starlette 1.10.0、Uvicorn 0.54.0 环境运行。

```powershell
& '.\.venv\Scripts\python.exe' -X utf8 -m pytest -q --tb=short tests/test_feedback_api.py tests/test_feedback_http.py
& '.\.venv\Scripts\python.exe' -X utf8 -m pytest -q --tb=short
```

| 检查 | 结果 |
|---|---|
| 接口与本机 HTTP 专项 | 17 项通过。覆盖独立令牌、未配置状态、请求格式、正常与待补草稿、非法或矛盾输出、整理器失败、超时和合成敏感文本检查 |
| 实际 TCP 与 SSE | 整理器被测试控制保持等待时，客户端先收到 `received` 和 `structuring`，释放整理器后收到验证与完整结果。关闭连接后，在 2 秒等待窗口内观察到取消。无 `Content-Length` 的分块上传超过 1 MiB 返回 413 |
| 独立 Uvicorn 进程 | 用环境开关和令牌启动 `server.api:app`。知识库未配置时返回 3 个阶段和 1 个结果，累计 12 题、剩余 8 题。无令牌返回 401。非法请求返回稳定错误码，合成隐私标记未出现在进程输出中 |
| 全量回归 | 132 项通过，包含已有 115 项。有 1 条既有 Starlette `TestClient` 使用 `httpx` 的弃用提示 |

## 后续验收

VF-03 验证真实模型能否正确识别任务、数量与日期，核对供应商调用的取消和计费边界。VF-04 验证真实音频格式、识别效果及数据处理。代理转发中的逐段到达、Android 前后台切换和本地保存，分别在部署与真机接入时验证。本阶段使用本机模拟器，新增供应商 API 费用为零。
