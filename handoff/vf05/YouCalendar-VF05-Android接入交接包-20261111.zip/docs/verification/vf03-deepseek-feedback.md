# VF-03 DeepSeek 文字反馈验证记录

2026-11-10 · 已完成本机实现及固定合成集真实评测 · T4/T8 · ET2/ET4/ET6

## 服务和费用核验

- 两轮均以 `deepseek-flash` 请求 `https://api.deepseek.com/chat/completions`，使用非思考模式和 JSON 输出。官方文档列出的对应版本是 `DeepSeek-V4.1-Flash-1017`。评测日志保存了请求模型和文档版本，适配器校验响应模型字段，日志未单独记录该字段。 [模型与价格](https://api-docs.deepseek.com/zh-cn/quick_start/pricing/) · [请求规范](https://api-docs.deepseek.com/api/create-chat-completion/) · [JSON 输出](https://api-docs.deepseek.com/guides/json_mode/)
- 公开政策说明境内运营收集和产生的个人信息在境内存储。公开资料未明确列出该端点每次 API 请求正文的固定留存天数，也不能据此确认处理路径。当前评测只发送固定合成数据。真实学习资料的使用范围须在后续接入前核实。 [隐私政策](https://cdn.deepseek.com/policies/zh-CN/deepseek-privacy-policy.html) · [开放平台协议](https://cdn.deepseek.com/policies/zh-CN/deepseek-open-platform-terms-of-service.html)
- 用户批准本轮费用上限为 **3 元**。脚本先核验账户可用且币种为人民币。按 2026-11-10 官方峰价，以输入未命中缓存 2 元/百万 token、输出 8 元/百万 token 计算上界。 [查询余额](https://api-docs.deepseek.com/zh-cn/api/get-user-balance/) · [模型与价格](https://api-docs.deepseek.com/zh-cn/quick_start/pricing/)

## 实现与样例

模型仅接收反馈文本、选定学习日和相关任务字段。供应商请求用临时任务别名，原任务 ID、提交 ID、版本和旧打卡原因保留在本地。模型输出提取结果，后端核对原话和任务，再计算累计与剩余量并套用 VF-01 草稿规则。已知数量歧义、同名任务缺少时段依据、单位不符、超量和相对日期进入待确认。自动确认资格当前使用保守的明确数字措辞规则，其他表达会要求补充。 [适配器](../../server/providers/deepseek_feedback.py) · [契约](../contracts/feedback-v1.md)

评测集固定 12 条合成文本。评分检查任务匹配、累计与新增、数量、待补项、原因和未提及任务。语义不符但仍为 `ready_for_confirmation` 的结果标为 `reviewable_mismatch`，作为评测阻塞项。模拟输入及预期通过只表明本地规则可执行。 [评测集](../../evals/feedback/cases.json)

单次请求限制模型输出为 2048 token，提示内容最多 16 KiB，响应最多 128 KiB，调用超时 15 秒。同一评测版本每条样例至多发送一次，修复版复测与首轮共用预算账本。发送前按公布的上下文长度和最大输出量保守预留 **2.113536 元**，收到可校验用量后按峰价上界结算。超时、未知版本或用量缺失保留预留额，结束本轮。账本记录评测版本、样例编号和额度状态，跨进程重启仍有效。 [评测脚本](../../evals/feedback/run.py)

## 实际验证

Windows 本地运行，使用既有 Python 3.12.14 和锁定的 httpx 0.28.1。

```powershell
& '.\.venv\Scripts\python.exe' -X utf8 -m evals.feedback.run
& '.\.venv\Scripts\python.exe' -X utf8 -m pytest -q --tb=short tests/test_deepseek_feedback.py
& '.\.venv\Scripts\python.exe' -X utf8 -m pytest -q --tb=short
```

| 检查 | 结果 |
|---|---|
| 评测集预检 | 12 条通过请求结构检查。此前缺密钥时真实模式在请求前退出，配置 Windows 用户级变量后完成实测 |
| 专项 | 29 项通过。新增了原因片段误用、同名提示去重及跨日草稿的回归校验 |
| 全量回归 | 161 项通过，有 1 条既有 Starlette `TestClient` 使用 `httpx` 的弃用提示 |

| 真实评测 | 通过 | 可确认状态下的偏差 | 输入 / 输出 token | 单条中位耗时 | 费用上界 |
|---|---:|---:|---:|---:|---:|
| 首轮 | 7/12 | 2 | 6071 / 861 | 1.000 秒 | 0.019030 元 |
| 修复后复测 | 12/12 | 0 | 7139 / 867 | 1.102 秒 | 0.021214 元 |

首轮发现的五个偏差及复测结果如下。

| 场景 | 首轮行为 | 修复后结果 |
|---|---|---|
| “做了 12 题”缺累计或新增依据 | 模型猜为累计，后端已阻止确认 | 模型输出含义不明，草稿待确认 |
| 只说“没做” | 模型用原话片段填出无依据的原因，草稿可确认 | 后端要求有明确因果措辞和原文原因，缺原因时提示补充 |
| 同名任务缺时段 | 同一句话出现两条待匹配记录 | 合并同一证据及相同候选集合，只提示一次 |
| 更正原打卡 | 累计量正确，但更正措辞被当成学习原因 | 保留 8→6 题的变更和剩余 14 题，原因留空 |
| 反馈涉及昨天 | 标为日期待确认，但仍携带当天任务的候选变更 | 日期待确认，暂不附当天任务变更 |

两轮 24 次请求的用量均入账，逐条日志和本地账本核对一致。按官方峰价和输入全未命中计算，**费用合计上界为 0.040244 元**，低于批准的 3 元。供应商实际扣款待对照账户账单。修复版单条耗时在 0.687 至 7.844 秒之间。日志在本机 `output/vf03-live-20261110-1755.jsonl` 和 `output/vf03-live-20261110-v2.jsonl`。 [官方费率](https://api-docs.deepseek.com/zh-cn/quick_start/pricing/)

本轮完成标准是固定合成集全部匹配且没有可确认状态下的偏差。第二轮使用同一组样例验证修复，真实用户语句的泛化、真实音频与 Android 保存留待后续验证。原因校验目前依赖明确因果措辞，口语省略原因连接词时可能要求用户补充。

## 复现与额度记录

在 PowerShell 7 可从 Windows 用户级变量读取密钥到当前进程。已有同版本评测结果时，脚本会从账本识别已经发送的样例。

```powershell
$env:DEEPSEEK_API_KEY = [Environment]::GetEnvironmentVariable('DEEPSEEK_API_KEY', 'User')
& '.\.venv\Scripts\python.exe' -X utf8 -m evals.feedback.run --live
```

脚本按北京时间检查费率核验日期。跨日重跑前，复核官方模型与价格，再更新脚本的价格快照。复用 `data/feedback-vf03-budget.sqlite` 以保留该轮已发生和未结算的预留额。评测输出包含逐条判定、耗时、token 和费用上界，供核对失败样例与账单。面向 App 的实时模型模式须依据真实评测和用户数据范围再启用。
