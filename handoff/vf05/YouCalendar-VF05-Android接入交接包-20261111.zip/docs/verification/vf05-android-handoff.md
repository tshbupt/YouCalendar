# VF-05 后端交付与 Android 接入指南

2026-11-11 · T4/T5/T8/T10 · ET2/ET5/ET7

本包供已有 Android 前端 Demo 的开发者接入学习反馈。服务接收文字或音频和当天任务快照，返回可编辑的草稿。App 在用户确认后把任务进度和历史写入手机。日、周、月计划生成有独立任务。 [实施方案](../designs/YouCalendar-当前电脑开发方案-语音反馈先行-20261110.md) · [接口契约](../contracts/feedback-v1.md)

## 接手顺序

1. 在现有 Demo 目录之外解压交接包，从解压后的根目录按 README 安装依赖、启动并运行文字和音频样例。演示仅需一个自行设置的本机令牌，可用 Windows、PowerShell、Python 3.12 和 `curl.exe`。 [运行命令](../../README.md#运行条件与安装)
2. 只读检查现有 Demo 的框架、任务和打卡数据结构、录音能力、网络与本地保存方式。对照下方变更清单拟定增量接入方案，列出修改文件和真机验收步骤，得到用户确认后实施。已有后端时先做差异比较，并核对依赖锁、路由和数据模型的冲突。
3. 先接文字路由和结构化草稿编辑，验证确认后保存及重启读回。接着用合成 WAV 验证音频上传和进度。App 真实录音的格式兼容及真实识别需要各自验证。

## 运行与对接要点

| 要点 | 实现约定 |
|---|---|
| 本机基线 | `FEEDBACK_MODE=demo`，服务监听 `127.0.0.1:8000`。客户端发送 `Authorization: Bearer <本机演示令牌>`。演示令牌用于开发配置。供应商凭据保留在服务端，反馈与知识库使用各自的令牌。 |
| 文字与音频 | 文字上传 UTF-8 JSON。音频上传 `multipart/form-data`，`metadata` 部分为 `application/json`，`audio` 部分为 `audio/wav` 或 `audio/x-wav`。WAV 实际编码为 16 kHz、16 位、单声道 PCM，最长 60 秒。将录音改为 `.wav` 后缀无法转换编码。 |
| 样例 | `tests/fixtures/feedback/text-request.json` 和 `text-events.json` 是一组成功样例。音频使用 `audio-context.json`、README 生成的合成 WAV 和 `audio-events.json`。`review-cases.json`、`error-cases.json` 提供需编辑和失败分支。演示识别器只接受固定信号，用实际录音测试时应单独核对识别模式。 |
| 接收进度 | 按 UTF-8 SSE 读取 POST 的响应体，累积到完整空行分隔帧再解码 `data:` JSON。文字为 `received → structuring → validating → result`，音频在整理前增加 `recognizing`。终止 `error` 或终止帧前断流时保留输入并提供手动重试。 [OpenAPI](../contracts/youcalendar.openapi.json) |
| 编辑与确认 | 从 `result.draft` 直接显示结构化内容，标出 `before` 和 `candidate` 差异。编辑后检查数量、状态和原因。保存前处理 `issues`、未匹配项和日期确认，校验 `snapshot_revision` 和涉及任务的 `task_revision`。 |
| 版本与去重 | 同次操作重试保留 `submission_id`，生成新 `attempt_id`，只接受当前尝试的事件。用 `submission_id` 作为 App 本地 `application_id`，同一事务写入任务、历史和提交记录。保存失败时重试同一笔本地事务。 |

在另一台 Windows 连接已授权 USB 调试的 Android 真机后，可用 `adb reverse tcp:8000 tcp:8000` 把手机的 `127.0.0.1:8000` 转发给开发机。确认现有 Demo 的调试网络设置允许这一地址，发布配置使用正式 HTTPS 端点。本机复验尚未执行这一步。 [Android 本地服务调试说明](https://developer.android.com/develop/ui/views/layout/webapps/access-local-server)

## 真机验收

| 场景 | 预期结果 |
|---|---|
| 文本成功、合成 WAV 成功 | 从真实 HTTP 服务收到阶段，显示累计 12 题、剩余 8 题。 |
| 修改草稿并确认 | App 标出差异。确认后任务和历史各写入一次，退出重开仍能读回。 |
| 重试、重复确认和快照过期 | 忽略旧请求迟到结果。重复确认不增加历史。快照变化后提示刷新与重核。 |
| 拒绝麦克风权限、断连、失败恢复 | 给出恢复入口，允许文字反馈。保存失败保留草稿及同一应用 ID，并可本地重试。 |
| Android 实录 | 核对实际录音参数。用经批准的样例分别记录转写、草稿和 App 保存结果，再验证所选 ASR 与文字模型的串联。 |

## VF-05 文件变更清单

| 文件 | 本次内容 |
|---|---|
| `server/api.py`、`server/contracts/feedback_openapi.py`、`server/contracts/export_feedback_schema.py` | 补齐服务 OpenAPI 的两条反馈路由的请求、流式响应和错误定义。事件和请求复用现有契约模型。 |
| `docs/contracts/youcalendar.openapi.json`、`docs/contracts/feedback-v1.md` | 提供离线 OpenAPI 快照、生成命令及与请求和 SSE 样例的对应关系。 |
| `tests/fixtures/feedback/text-events.json`、`tests/fixtures/feedback/audio-events.json`、`tests/test_feedback_contract.py` | 固定成功响应样例，校验音频事件序列和 OpenAPI 与运行时的一致性。 |
| `requirements.lock.txt`、`README.md` | 锁定构建依赖，更新全新 Windows 环境的安装及复现命令。 |
| 本指南、`docs/designs/YouCalendar-当前电脑开发方案-语音反馈先行-20261110.md` | 记录交付范围、进度、验证及真机接入条件。 |

交接包包含运行所需源码、依赖清单、契约、测试、合成评测样例和相关说明。现有 Demo 保持在原目录，按实际差异合并。环境、密钥、资料、数据库、学习记录和供应商调用账本留在原机器。

## 本机验证记录

在 Windows 11、PowerShell 7.6.5 和 Python 3.12.14 上，将交接副本解压到独立目录，用 Python 3.12 解释器的完整路径创建新 `.venv`。按 README 安装锁定依赖和项目后，`pip check` 通过。使用独立 Uvicorn 进程和 `curl.exe` 通过本机 TCP 复验。

| 检查 | 实际结果 |
|---|---|
| `GET /openapi.json` | 与包内快照一致，通过 FastAPI OpenAPI 模型校验，全部本地 `$ref` 可解析。 |
| `POST /v1/feedback/text` | HTTP 200，4 个 UTF-8 SSE 事件与文字样例逐帧一致。 |
| `POST /v1/feedback/audio` | HTTP 200，5 个 UTF-8 SSE 事件与音频样例逐帧一致。文字和音频都给出累计 12 题、剩余 8 题的草稿。 |
| 受理前错误 | 两条路由缺令牌均返回 `401 unauthorized`，损坏 JSON 返回 `400 invalid_request`，音频部分 MIME 类型错误返回 `415 unsupported_media_type`。 |
| 全量回归 | `python -X utf8 -m pytest -q --tb=short`，199 项通过。包含阶段逐帧到达、断连取消、合成样例和知识库回归。2 条依赖弃用提示来自 jieba 的 `pkg_resources` 和 Starlette 的 `TestClient`。 |

本轮使用本机模拟器，供应商调用 0 次，费用 0 元。Android 接入、录音格式和重启读回待在另一台电脑与真机上完成。真实 ASR 和文字模型的串联、云端代理转发与上线另行验收。 [VF-03 模型记录](vf03-deepseek-feedback.md) · [VF-04 识别记录](vf04-tencent-asr.md)
